#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import re
if sys.version_info[0] >= 3:
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import cgitb
cgitb.enable()
import cgi
import mysql.connector
import html

form = cgi.FieldStorage()
db_name = form.getfirst("db", "").strip()
studid_param = form.getfirst("studid", "").strip()
subjid_param = form.getfirst("subjid", "").strip()
comment = form.getfirst("comment", "")
submit_action = form.getfirst("submit_comment", "")

# ================= COOKIE FUNCTION =================
def get_cookie_value(cookie_name):
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith(cookie_name + '='):
                return cookie.split('=', 1)[1]
    return ""

db_user = get_cookie_value('db_user')
user_role = get_cookie_value('user_role')

# Validate parameters
if not db_name or not studid_param or not subjid_param:
    print("Content-Type: text/html; charset=utf-8\n")
    print("<h2>Error: Missing required parameters.</h2>")
    print(f"<a href='studrec.py?db={html.escape(db_name)}'>Back to Student Record</a>")
    sys.exit()

# Handle comment submission
comment_submitted = False
if submit_action and comment:
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database=db_name,
            charset='utf8mb4',
            use_unicode=True
        )
        cur = conn.cursor()
        
        # Get enrollment ID
        cur.execute("""
        SELECT eid FROM enroll WHERE studid = %s AND subjid = %s
        """, (int(studid_param), int(subjid_param)))
        enroll_result = cur.fetchone()
        
        if enroll_result:
            eid = enroll_result[0]
            # Update evaluation field
            cur.execute("""
            UPDATE enroll SET evaluation = %s WHERE eid = %s
            """, (comment, eid))
            conn.commit()
            comment_submitted = True
        
        cur.close()
        conn.close()
    except Exception as e:
        pass

# Fetch student and subject information
student_info = None
subject_info = None
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database=db_name,
        charset='utf8mb4',
        use_unicode=True
    )
    cur = conn.cursor()
    
    # Get student info
    cur.execute("""
    SELECT studid, studname, studcrs, yrlvl
    FROM students
    WHERE studid = %s
    """, (int(studid_param),))
    student_info = cur.fetchone()
    
    # Get subject info
    cur.execute("""
    SELECT subjid, subjcode, subjdesc, subjunits, subjsched
    FROM subjects
    WHERE subjid = %s
    """, (int(subjid_param),))
    subject_info = cur.fetchone()
    
    # Get existing evaluation
    cur.execute("""
    SELECT evaluation FROM enroll WHERE studid = %s AND subjid = %s
    """, (int(studid_param), int(subjid_param)))
    eval_result = cur.fetchone()
    existing_comment = eval_result[0] if eval_result and eval_result[0] else ""
    
    cur.close()
    conn.close()
except Exception as e:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<h2>Database Error:</h2><pre>{html.escape(str(e))}</pre>")
    sys.exit()

# ================= RENDER PAGE (YALE THEME) =================
print("Content-Type: text/html; charset=utf-8\n")
print(f'''<!DOCTYPE html>
<html>
<head>
    <title>Student Evaluation Portal - Yale University</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Georgia', serif; background: #f8f9fa; }}
        
        /* Yale Header - Matches index.py/students.py */
        .header {{
            background: linear-gradient(135deg, #00356B 0%, #00274C 100%);
            color: white;
            padding: 20px 40px;
            display: flex;
            align-items: center;
            gap: 20px;
        }}
        .logo {{
            width: 60px;
            height: 60px;
            background: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid #FFD700;
        }}
        .logo img {{
            width: 100%;
            height: 100%;
            object-fit: contain;
            border-radius: 4px;
        }}
        .header-text h1 {{
            font-size: 28px;
            margin: 0;
            letter-spacing: 0.5px;
        }}
        .header-text p {{
            font-size: 16px;
            opacity: 0.9;
        }}
        
        /* Main Content */
        .main-content {{
            padding: 40px;
            max-width: 1000px;
            margin: 0 auto;
        }}
        
        .page-title {{
            color: #00356B;
            font-size: 32px;
            margin-bottom: 30px;
            font-family: 'Georgia', serif;
        }}
        
        .back-button {{
            background: #00356B;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            margin-bottom: 20px;
            text-decoration: none;
            display: inline-block;
            font-family: 'Helvetica', sans-serif;
        }}
        .back-button:hover {{
            background: #00274C;
        }}
        
        .success-message {{
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 15px 20px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-weight: bold;
            font-family: 'Helvetica', sans-serif;
        }}
        
        .section-title {{
            color: #00356B;
            font-size: 20px;
            margin: 30px 0 15px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #F0AB00;
            font-family: 'Helvetica', sans-serif;
        }}
        
        .info-table {{
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            font-family: 'Helvetica', sans-serif;
        }}
        .info-table th, .info-table td {{
            border: 1px solid #dee2e6;
            padding: 12px 15px;
            text-align: left;
        }}
        .info-table th {{
            background: #00356B;
            color: white;
            font-weight: bold;
            width: 150px;
        }}
        .info-table tr:nth-child(even) {{
            background: #f8f9fa;
        }}
        .info-table tr:hover {{
            background: #e9ecef;
        }}
        
        .evaluation-textarea {{
            width: 100%;
            min-height: 200px;
            padding: 15px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-family: 'Georgia', serif;
            font-size: 14px;
            resize: vertical;
        }}
        .evaluation-textarea:focus {{
            outline: none;
            border-color: #00356B;
            box-shadow: 0 0 0 2px rgba(0, 53, 107, 0.1);
        }}
        
        .submit-button {{
            background: #00356B;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
            margin-top: 20px;
            font-family: 'Helvetica', sans-serif;
        }}
        .submit-button:hover {{
            background: #00274C;
        }}
        
        .footer {{
            text-align: center;
            padding: 30px;
            color: #6c757d;
            font-size: 14px;
            margin-top: 40px;
            border-top: 1px solid #dee2e6;
            font-family: 'Helvetica', sans-serif;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg" alt="Yale University Logo">
        </div>
        <div class="header-text">
            <h1>STUDENT INFORMATION SYSTEM</h1>
            <p>YALE UNIVERSITY</p>
        </div>
    </div>
    
    <div class="main-content">
        <h1 class="page-title">Student Evaluation Portal</h1>
        
        <a href="studrec.py?db={html.escape(db_name)}" class="back-button">← Back to Student Record</a>
        
        {f'<div class="success-message">✓ Comment submitted successfully!</div>' if comment_submitted else ''}
        
        <hr style="border: 0; border-top: 2px solid #dee2e6; margin: 20px 0;">
        
        <h2 class="section-title">Student Information</h2>
        <table class="info-table">
            <tr>
                <th>ID</th>
                <td>{html.escape(str(student_info[0])) if student_info else 'N/A'}</td>
                <th>Course</th>
                <td>{html.escape(str(student_info[2])) if student_info and student_info[2] else 'N/A'}</td>
            </tr>
            <tr>
                <th>Name</th>
                <td>{html.escape(str(student_info[1])) if student_info else 'N/A'}</td>
                <th>Year Level</th>
                <td>{html.escape(str(student_info[3])) if student_info and student_info[3] else 'N/A'}</td>
            </tr>
        </table>
        
        <h2 class="section-title">Subject Information</h2>
        <table class="info-table">
            <tr>
                <th>ID</th>
                <td>{html.escape(str(subject_info[0])) if subject_info else 'N/A'}</td>
            </tr>
            <tr>
                <th>Code</th>
                <td>{html.escape(str(subject_info[1])) if subject_info and subject_info[1] else 'N/A'}</td>
            </tr>
            <tr>
                <th>Description</th>
                <td>{html.escape(str(subject_info[2])) if subject_info and subject_info[2] else 'N/A'}</td>
            </tr>
            <tr>
                <th>Units</th>
                <td>{html.escape(str(subject_info[3])) if subject_info and subject_info[3] else 'N/A'}</td>
            </tr>
            <tr>
                <th>Schedule</th>
                <td>{html.escape(str(subject_info[4])) if subject_info and subject_info[4] else 'N/A'}</td>
            </tr>
        </table>
        
        <h2 class="section-title">Your Evaluation/Comments:</h2>
        <form method="post">
            <input type="hidden" name="db" value="{html.escape(db_name)}">
            <input type="hidden" name="studid" value="{html.escape(studid_param)}">
            <input type="hidden" name="subjid" value="{html.escape(subjid_param)}">
            
            <textarea name="comment" class="evaluation-textarea" placeholder="Enter your thoughts here...">{html.escape(existing_comment)}</textarea>
            
            <button type="submit" name="submit_comment" value="1" class="submit-button">Submit Comment</button>
        </form>
    </div>
    
    <div class="footer">
        <p>&copy; 2027 Yale University - Student Information System</p>
    </div>
</body>
</html>''')
