#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import re
import cgi
import html as html_mod
import io
from datetime import datetime

from pymongo import MongoClient
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.pdfgen import canvas

import cgitb
cgitb.enable()

YALE_BLUE       = colors.HexColor("#00356B")
YALE_BLUE_LIGHT = colors.HexColor("#0F4D92")
YALE_GREY       = colors.HexColor("#F9F9F9")
YALE_GOLD       = colors.HexColor("#F0AB00")

def get_cookie_value(name):
    if 'HTTP_COOKIE' in os.environ:
        for part in os.environ['HTTP_COOKIE'].split('; '):
            if part.startswith(name + '='):
                return part.split('=', 1)[1]
    return ""

form         = cgi.FieldStorage()
studid_param = form.getfirst("studid", "").strip()

if not studid_param or not studid_param.isdigit():
    print("Content-Type: text/html; charset=utf-8\n")
    print("<h2>Error: Invalid or missing student ID.</h2>")
    sys.exit()

studid_int = int(studid_param)

# ── Connect to MongoDB ──
try:
    mongo = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=5000)
    mongo.admin.command('ping')
except Exception as e:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<h2>MongoDB connection error: {html_mod.escape(str(e))}</h2>")
    sys.exit()

# ── Get all semester DBs from MongoDB ──
def get_all_semester_dbs():
    all_dbs = mongo.list_database_names()
    valid = []
    for db in all_dbs:
        if (re.match(r'^1stsy_\d{4}_\d{4}$', db) or
            re.match(r'^2ndsem_sy\d{4}_\d{4}$', db) or
            re.match(r'^summersy_\d{4}_\d{4}$', db)):
            valid.append(db)
    def sort_key(db):
        m1 = re.match(r'^1stsy_(\d{4})_\d{4}$', db)
        m2 = re.match(r'^2ndsem_sy(\d{4})_\d{4}$', db)
        m3 = re.match(r'^summersy_(\d{4})_\d{4}$', db)
        if m1: return (int(m1.group(1)), 1)
        if m2: return (int(m2.group(1)), 2)
        if m3: return (int(m3.group(1)), 3)
        return (9999, 9)
    valid.sort(key=sort_key)
    return valid

semester_dbs = get_all_semester_dbs()

# ── Fetch student info from MongoDB ──
student_info = None
for db_name in semester_dbs:
    db = mongo[db_name]
    row = db.students.find_one({"_id": studid_int})
    if not row:
        row = db.students.find_one({"studid": studid_int})
    if row:
        student_info = row
        break

if not student_info:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<h2>Error: Student ID {html_mod.escape(studid_param)} not found in MongoDB.</h2>")
    sys.exit()

stud_name   = student_info.get("studname", "")
stud_gender = student_info.get("studgender", "")
stud_course = student_info.get("studcrs", "")

# ── Fetch grades per semester from MongoDB ──
semester_records = []
total_subjects   = 0

for db_name in semester_dbs:
    db = mongo[db_name]

    enroll_docs = list(db.enroll.find({"studid": studid_int}))
    if not enroll_docs:
        continue

    rows = []
    for enroll in enroll_docs:
        eid    = enroll.get("eid") or enroll.get("_id")
        subjid = enroll.get("subjid")

        # Get subject info
        subj = db.subjects.find_one({"_id": subjid})
        if not subj:
            subj = db.subjects.find_one({"subjid": subjid})

        subjcode  = subj.get("subjcode", "")  if subj else ""
        subjdesc  = subj.get("subjdesc", "")  if subj else ""
        subjunits = subj.get("subjunits", "") if subj else ""

        # Get grade
        grade_doc   = db.grades.find_one({"enroll_eid": eid})
        final_grade = grade_doc.get("final", "—") if grade_doc else "—"
        if not final_grade:
            final_grade = "—"

        rows.append((subjid, subjcode, subjdesc, subjunits, final_grade))

    rows.sort(key=lambda x: x[0])

    if rows:
        semester_records.append((db_name, rows))
        total_subjects += len(rows)

mongo.close()

# ── Custom Canvas ──
class TORCanvas(canvas.Canvas):
    def showPage(self):
        self.saveState()
        self.setFillColor(YALE_BLUE)
        self.rect(0, A4[1] - 15, A4[0], 15, fill=True, stroke=False)
        self.setStrokeColor(YALE_GOLD)
        self.setLineWidth(2)
        self.line(0, A4[1] - 15, A4[0], A4[1] - 15)
        self.setFillColor(YALE_BLUE)
        self.rect(0, 0, A4[0], 10, fill=True, stroke=False)
        self.setStrokeColor(YALE_GOLD)
        self.setLineWidth(2)
        self.line(0, 10, A4[0], 10)
        self.setStrokeColor(YALE_BLUE_LIGHT)
        self.setLineWidth(0.5)
        self.setDash(1, 2)
        self.line(30, 0, 30, A4[1])
        self.line(A4[0] - 30, 0, A4[0] - 30, A4[1])
        self.setDash()
        self.setFont("Helvetica-Bold", 90)
        self.setFillColor(YALE_BLUE)
        self.setFillAlpha(0.03)
        self.translate(A4[0]/2, A4[1]/2)
        self.rotate(45)
        self.drawCentredString(0, 0, "OFFICIAL")
        self.setFillAlpha(1)
        self.restoreState()
        canvas.Canvas.showPage(self)

# ── Build PDF ──
buffer = io.BytesIO()
doc = SimpleDocTemplate(buffer, pagesize=A4,
    topMargin=70, bottomMargin=50, leftMargin=55, rightMargin=55)
styles   = getSampleStyleSheet()

title_style = ParagraphStyle('TORTitle', parent=styles['Heading1'],
    fontSize=16, textColor=YALE_BLUE, alignment=TA_CENTER,
    spaceAfter=4, fontName='Helvetica-Bold', leading=20)
subtitle_style = ParagraphStyle('TORSubtitle', parent=styles['Normal'],
    fontSize=11, textColor=YALE_BLUE_LIGHT, alignment=TA_CENTER,
    spaceAfter=2, fontName='Helvetica')
sem_label_style = ParagraphStyle('SemLabel', parent=styles['Normal'],
    fontSize=10, textColor=YALE_BLUE, fontName='Helvetica-Bold',
    spaceBefore=10, spaceAfter=3)
note_style = ParagraphStyle('Note', parent=styles['Normal'],
    fontSize=8, textColor=colors.grey, fontName='Helvetica')

elements = []

# Header
try:
    from reportlab.platypus import Image as RLImage
    import urllib.request
    logo_data = urllib.request.urlopen(
        "https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg", timeout=3).read()
    logo_img = RLImage(io.BytesIO(logo_data), width=0.7*inch, height=0.7*inch)
    htbl = Table([[logo_img,
                   [Paragraph("YALE UNIVERSITY", title_style),
                    Paragraph("Office of the University Registrar", subtitle_style)],
                   logo_img]], colWidths=[0.9*inch, 5.2*inch, 0.9*inch])
    htbl.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN',  (0,0), (0,0),   'CENTER'),
        ('ALIGN',  (2,0), (2,0),   'CENTER'),
    ]))
    elements.append(htbl)
except Exception:
    elements.append(Paragraph("YALE UNIVERSITY", title_style))
    elements.append(Paragraph("Office of the University Registrar", subtitle_style))

elements.append(Spacer(1, 6))
elements.append(HRFlowable(width="40%", thickness=3, color=YALE_GOLD, spaceAfter=8, hAlign='CENTER'))
elements.append(Paragraph("Official Transcript of Records", ParagraphStyle('DocTitle',
    parent=styles['Heading2'], fontSize=14, textColor=YALE_BLUE,
    alignment=TA_CENTER, fontName='Helvetica-Bold', spaceAfter=12)))

# Student info table
info_tbl = Table([
    [Paragraph("<b>Student ID:</b>",     styles['Normal']), str(studid_int),
     Paragraph("<b>Student Name:</b>",   styles['Normal']), str(stud_name)],
    [Paragraph("<b>Student Course:</b>", styles['Normal']), str(stud_course),
     Paragraph("<b>Gender:</b>",         styles['Normal']), str(stud_gender)],
], colWidths=[1.4*inch, 2.0*inch, 1.4*inch, 2.2*inch])
info_tbl.setStyle(TableStyle([
    ('FONTSIZE',      (0,0), (-1,-1), 10),
    ('TOPPADDING',    (0,0), (-1,-1), 5),
    ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ('LEFTPADDING',   (0,0), (-1,-1), 4),
    ('RIGHTPADDING',  (0,0), (-1,-1), 4),
    ('ROWBACKGROUNDS',(0,0), (-1,-1), [YALE_GREY, colors.white]),
    ('BOX',           (0,0), (-1,-1), 1, YALE_BLUE),
    ('INNERGRID',     (0,0), (-1,-1), 0.5, colors.lightgrey),
]))
elements.append(info_tbl)
elements.append(Spacer(1, 14))

# Grades
if semester_records:
    for db_label, rows in semester_records:
        elements.append(Paragraph(db_label, sem_label_style))
        tdata = [["SubjID", "Subj Code", "Descriptive Title", "Final", "Credit"]]
        for (subjid, code, desc, units, final_grade) in rows:
            tdata.append([str(subjid), str(code or ""), str(desc or ""),
                          str(final_grade) if final_grade else "—", str(units or "—")])
        gtbl = Table(tdata, colWidths=[0.7*inch, 0.9*inch, 3.2*inch, 0.7*inch, 0.7*inch], repeatRows=1)
        gtbl.setStyle(TableStyle([
            ('BACKGROUND',    (0,0), (-1,0),  YALE_BLUE),
            ('TEXTCOLOR',     (0,0), (-1,0),  colors.white),
            ('FONTNAME',      (0,0), (-1,0),  'Helvetica-Bold'),
            ('FONTSIZE',      (0,0), (-1,-1), 9),
            ('ALIGN',         (0,0), (-1,0),  'CENTER'),
            ('FONTNAME',      (0,1), (-1,-1), 'Helvetica'),
            ('ROWBACKGROUNDS',(0,1), (-1,-1), [colors.white, YALE_GREY]),
            ('ALIGN',         (3,1), (4,-1),  'CENTER'),
            ('GRID',          (0,0), (-1,-1), 0.5, colors.lightgrey),
            ('BOX',           (0,0), (-1,-1), 1.5, YALE_BLUE),
            ('LINEBELOW',     (0,0), (-1,0),  1.5, YALE_GOLD),
            ('TOPPADDING',    (0,0), (-1,-1), 5),
            ('BOTTOMPADDING', (0,0), (-1,-1), 5),
            ('LEFTPADDING',   (0,0), (-1,-1), 4),
            ('RIGHTPADDING',  (0,0), (-1,-1), 4),
        ]))
        elements.append(gtbl)
        elements.append(Spacer(1, 4))

    elements.append(Spacer(1, 10))
    elements.append(Paragraph(f"<b>Number of Subjects Listed: {total_subjects}</b>",
        ParagraphStyle('SubjCount', parent=styles['Normal'],
                       fontSize=10, textColor=YALE_BLUE, fontName='Helvetica-Bold')))
else:
    elements.append(Paragraph("No enrollment records found for this student.",
        ParagraphStyle('NoRec', parent=styles['Normal'],
                       fontSize=11, textColor=colors.grey, alignment=TA_CENTER)))

# Legend
elements.append(Spacer(1, 14))
elements.append(HRFlowable(width="100%", thickness=0.5, color=colors.lightgrey, spaceAfter=6))

def legend_para(text):
    paras = []
    for i, line in enumerate(text.split('\n')):
        paras.append(Paragraph(line, ParagraphStyle(f'leg{i}', parent=styles['Normal'],
            fontSize=9 if i==0 else 8,
            fontName='Helvetica-Bold' if i==0 else 'Helvetica', leading=11)))
    return paras

leg_tbl = Table([[ 
    legend_para("Grading System up to SY 1981-82\n95-100 = 1.0 = Excellent\n90-94  = 1.5 = Very Good\n85-89  = 2.0 = Good\n80-84  = 2.5 = Fair\n75-79  = 3.0 = Passed\nBelow 75 = 5.0 = Failed"),
    legend_para("New Grading System (1st Sem. SY1982-83 & up)\n95-100 = 1.0 = Excellent\n90-94  = 1.5 = Very Good\n85-89  = 2.0 = Good\n80-84  = 2.5 = Fair\n75-79  = 3.0 = Passed\nBelow 75 = 5.0 = Failed")
]], colWidths=[3.5*inch, 3.5*inch])
leg_tbl.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0)]))
elements.append(leg_tbl)
elements.append(Spacer(1, 6))
elements.append(Paragraph("FOR FCF Grades: O - Outstanding, HS - Highly Satisfactory, MS - Moderately Satisfactory, S - Satisfactory, F - Fair, P - Poor", note_style))
elements.append(Paragraph("Quality Point Equivalent: 1.0 = 4.0, 1.5 = 3.5, 2.0 = 3.0, 2.5 = 2.5, 3.0 = 2.0", note_style))
elements.append(Spacer(1, 10))
elements.append(Paragraph("NOT VALID WITHOUT SCHOOL SEAL", ParagraphStyle('Seal',
    parent=styles['Normal'], fontSize=11, fontName='Helvetica-Bold', textColor=YALE_BLUE)))

# Signatures
elements.append(Spacer(1, 30))
today_str = datetime.now().strftime("%m/%d/%Y")
sig_tbl = Table([
    ["Prepared By: MARY ANN D. MATURAN", "", "Checked By: MYRNA VILLACOSA"],
    ["", "", ""],
    [f"Date: {today_str}", "", "Registrar: ATTY. EDGAR ESCALANTE"],
], colWidths=[2.8*inch, 1.4*inch, 2.8*inch])
sig_tbl.setStyle(TableStyle([('FONTSIZE',(0,0),(-1,-1),9),('FONTNAME',(0,0),(-1,-1),'Helvetica'),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
elements.append(sig_tbl)

# Output PDF
doc.build(elements, canvasmaker=TORCanvas)
pdf_bytes = buffer.getvalue()
buffer.close()

sys.stdout.write("Content-Type: application/pdf\r\n")
sys.stdout.write(f"Content-Disposition: inline; filename=TOR_{studid_param}.pdf\r\n")
sys.stdout.write(f"Content-Length: {len(pdf_bytes)}\r\n")
sys.stdout.write("\r\n")
sys.stdout.flush()
sys.stdout.buffer.write(pdf_bytes)
sys.stdout.buffer.flush()
