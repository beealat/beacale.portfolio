#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import re
if sys.version_info[0] >= 3:
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import cgitb
cgitb.enable()
import cgi
import mysql.connector
import html
import json

form = cgi.FieldStorage()

# Get parameters
tid_param = form.getfirst("tid", "").strip()
subjid_param = form.getfirst("subjid", "").strip()
eid_param = form.getfirst("eid", "").strip()
save_action = form.getfirst("save_grades", "")
logout = form.getfirst("logout", "")

# Grade fields
prelim = form.getfirst("prelim", "")
midterm = form.getfirst("midterm", "")
prefinal = form.getfirst("prefinal", "")
final = form.getfirst("final", "")

def get_cookie_value(cookie_name):
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith(cookie_name + '='):
                return cookie.split('=', 1)[1]
    return ""

# Get database and user role from cookies
db_name = get_cookie_value('enrolled_db')
db_user = get_cookie_value('db_user')
user_role = get_cookie_value('user_role')

# Handle logout
if logout == "1":
    print("Set-Cookie: enrolled_db=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Set-Cookie: db_user=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Set-Cookie: user_role=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Location: index.py\n")
    sys.exit()

import re as _re
def get_valid_databases():
    try:
        _conn = mysql.connector.connect(host="localhost", user="root", password="root", charset="utf8mb4", use_unicode=True)
        _cur = _conn.cursor()
        _cur.execute("SHOW DATABASES")
        all_dbs = [row[0] for row in _cur.fetchall()]
        _cur.close()
        _conn.close()
        return [d for d in all_dbs if (_re.match(r"^1stsy_\d{4}_\d{4}$", d) or _re.match(r"^2ndsem_sy\d{4}_\d{4}$", d) or _re.match(r"^summersy_\d{4}_\d{4}$", d))]
    except:
        return []

# Validate database
VALID_DATABASES = get_valid_databases()
if not db_name or db_name not in VALID_DATABASES:
    print("Location: index.py\n")
    sys.exit()

# Validate teacher role
if user_role != "teacher":
    print("Location: index.py\n")
    sys.exit()

# === SHOW GRANTS for teacher (background verification) ===
teacher_grants = []
try:
    if db_user:
        conn_grants = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root"
        )
        cur_grants = conn_grants.cursor()
        try:
            cur_grants.execute(f"SHOW GRANTS FOR '{db_user}'@'localhost'")
            teacher_grants = [row[0] for row in cur_grants.fetchall()]
        except mysql.connector.Error:
            pass
        cur_grants.close()
        conn_grants.close()
except mysql.connector.Error:
    pass

# Extract teacher ID from db_user if not in URL
if not tid_param and db_user:
    match = re.match(r'^(\d+)', db_user)
    if match:
        tid_param = match.group(1)

if not tid_param or not tid_param.isdigit():
    print("Content-Type: text/html; charset=utf-8\n")
    print("<h2>Error: Invalid teacher ID.</h2>")
    sys.exit()

tid_int = int(tid_param)

# Handle grade saving
saved_successfully = False
if save_action and eid_param and eid_param.isdigit():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database=db_name,
            charset='utf8mb4',
            use_unicode=True
        )
        cur = conn.cursor()
        
        # Check if grades record exists
        cur.execute("SELECT gradeid FROM grades WHERE enroll_eid = %s", (int(eid_param),))
        existing = cur.fetchone()
        
        # Get grade values from form
        clean_prelim = prelim if prelim and prelim != "NG" else None
        clean_midterm = midterm if midterm and midterm != "NG" else None
        clean_prefinal = prefinal if prefinal and prefinal != "NG" else None
        clean_final = final if final and final != "NG" else None
        
        if existing:
            # Update existing record
            cur.execute("""
            UPDATE grades
            SET prelim = %s, midterm = %s, prefinal = %s, final = %s
            WHERE enroll_eid = %s
            """, (clean_prelim, clean_midterm, clean_prefinal, clean_final, int(eid_param)))
        else:
            # Insert new record
            cur.execute("""
            INSERT INTO grades (enroll_eid, prelim, midterm, prefinal, final)
            VALUES (%s, %s, %s, %s, %s)
            """, (int(eid_param), clean_prelim, clean_midterm, clean_prefinal, clean_final))
        
        conn.commit()
        cur.close()
        conn.close()
        saved_successfully = True
    except Exception as e:
        pass

# Fetch assigned subjects and enrolled students
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database=db_name,
        charset='utf8mb4',
        use_unicode=True
    )
    cur = conn.cursor()
    
    # Get assigned subjects for this teacher
    cur.execute("""
    SELECT s.subjid, s.subjcode, s.subjdesc, s.subjunits, s.subjsched,
    (SELECT COUNT(*) FROM enroll e WHERE e.subjid = s.subjid) as num_students
    FROM subjects s
    INNER JOIN assign a ON s.subjid = a.SubjID
    WHERE a.TID = %s
    ORDER BY s.subjid
    """, (tid_int,))
    assigned_subjects = cur.fetchall()
    
    # Get enrolled students if a subject is selected
    enrolled_students = []
    if subjid_param and subjid_param.isdigit():
        cur.execute("""
        SELECT e.eid, st.studid, st.studname,
        g.prelim, g.midterm, g.prefinal, g.final
        FROM enroll e
        INNER JOIN students st ON e.studid = st.studid
        LEFT JOIN grades g ON e.eid = g.enroll_eid
        WHERE e.subjid = %s
        ORDER BY st.studid
        """, (int(subjid_param),))
        enrolled_students = cur.fetchall()
    
    cur.close()
    conn.close()
except Exception as e:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<h2>Database Error:</h2><pre>{html.escape(str(e))}</pre>")
    sys.exit()

# === RENDER PAGE ===
print("Content-Type: text/html; charset=utf-8\n")
print(f'''<!DOCTYPE html>
<html>
<head>
<title>Encode Grades - Teacher</title>
<link rel="stylesheet" href="style.css">
<style>
.grade-dropdown {{
    width: 80px;
    padding: 6px 4px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 13px;
    background: white;
}}
.grade-dropdown:focus {{
    outline: none;
    border-color: #00356B;
    box-shadow: 0 0 0 2px rgba(0, 53, 107, 0.1);
}}
#enrolledStudentsTable td {{
    padding: 8px;
}}
.save-button {{
    margin-top: 20px;
    background: #00356B;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
    font-size: 14px;
}}
.save-button:hover {{
    background: #00274C;
}}
.success-modal {{
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 30px 40px;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    z-index: 1000;
    text-align: center;
}}
.success-modal.show {{
    display: block;
}}
.modal-overlay {{
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 999;
}}
.modal-overlay.show {{
    display: block;
}}
.success-icon {{
    width: 60px;
    height: 60px;
    background: #28a745;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    color: white;
    font-size: 32px;
    font-weight: bold;
}}
.success-title {{
    font-size: 24px;
    font-weight: bold;
    color: #28a745;
    margin-bottom: 10px;
}}
.success-message {{
    font-size: 16px;
    color: #333;
    margin-bottom: 20px;
}}
.close-modal-btn {{
    background: #00356B;
    color: white;
    border: none;
    padding: 10px 30px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: bold;
}}
.close-modal-btn:hover {{
    background: #00274C;
}}
.studeval-link {{
    color: #00356B;
    text-decoration: underline;
    font-weight: bold;
}}
.studeval-link:hover {{
    color: #00274C;
}}
</style>
</head>
<body>
<div class="header">
    <div class="logo">
        <img src="https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg" alt="University Logo">
    </div>
    <div class="header-text">
        <h1>STUDENT INFORMATION SYSTEM</h1>
        <p>UNIVERSITY NAME</p>
    </div>
</div>
<div class="nav-bar">
    <button id="logout-btn" onclick="window.location.href='encodegrades.py?tid={tid_param}&logout=1';">Logout</button>
</div>
''')

# Always show the table structure
print('''
<div class="main-content">
    <h2>Assigned Subjects</h2>
    <table id="assignedSubjectsTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Code</th>
                <th>Description</th>
                <th>Units</th>
                <th>Schedule</th>
                <th>#Stud</th>
                <th>StudEval</th>
            </tr>
        </thead>
        <tbody>
''')

if assigned_subjects:
    # Show assigned subjects rows
    for subj in assigned_subjects:
        subjid, code, desc, units, sched, num_stud = subj
        selected_class = ' class="selected"' if str(subjid) == subjid_param else ''
        print(f'''
        <tr{selected_class} onclick="selectSubject({subjid})">
            <td>{subjid}</td>
            <td>{html.escape(str(code or ''))}</td>
            <td>{html.escape(str(desc or ''))}</td>
            <td>{units or ''}</td>
            <td>{html.escape(str(sched or ''))}</td>
            <td align="center">{num_stud}</td>
            <td align="center"><a href="sentiment.py?db={html.escape(db_name)}&subjid={subjid}" class="studeval-link" onclick="event.stopPropagation()">Open</a></td>
        </tr>
''')

print('''
        </tbody>
    </table>
''')

if assigned_subjects:
    # Show enrolled students table if subject is selected
    if subjid_param and enrolled_students:
        print(f'''
    <h2 style="margin-top: 30px;">Enrolled Students</h2>
    <p style="color: #6c757d; margin-bottom: 15px;">Click a student row to edit grades. Save button is below the table.</p>
    <form method="post" id="gradeForm">
        <input type="hidden" name="tid" id="tid" value="{tid_param}">
        <input type="hidden" name="subjid" id="subjid" value="{subjid_param}">
        <input type="hidden" name="eid" id="eid" value="">
        <table id="enrolledStudentsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Prelim</th>
                    <th>Midterm</th>
                    <th>Prefinal</th>
                    <th>Final</th>
                </tr>
            </thead>
            <tbody>
''')
        for student in enrolled_students:
            eid, studid, studname, prelim_val, midterm_val, prefinal_val, final_val = student
            selected_class = ' class="selected"' if str(eid) == eid_param else ''
            
            # Prepare current values
            current_prelim = prelim_val or 'NG'
            current_midterm = midterm_val or 'NG'
            current_prefinal = prefinal_val or 'NG'
            current_final = final_val or 'NG'
            
            # Create grade options
            grade_options = ['NG', 'A', 'B+', 'B', 'C+', 'C', 'D', 'F', 'FD']
            
            def make_select(name, current_value, row_eid):
                options_html = ''
                for grade in grade_options:
                    selected = ' selected' if grade == current_value else ''
                    options_html += f'<option value="{grade}"{selected}>{grade}</option>'
                return f'<select class="grade-dropdown" data-field="{name}" data-eid="{row_eid}" id="{name}_{row_eid}" onchange="enableSaveForRow({row_eid})" onclick="event.stopPropagation()">{options_html}</select>'
            
            prelim_select = make_select('prelim', current_prelim, eid)
            midterm_select = make_select('midterm', current_midterm, eid)
            prefinal_select = make_select('prefinal', current_prefinal, eid)
            final_select = make_select('final', current_final, eid)
            
            print(f'''
            <tr{selected_class} onclick="selectStudent({eid}, {studid}, '{html.escape(studname)}')">
                <td>{studid}</td>
                <td>{html.escape(studname)}</td>
                <td>{prelim_select}</td>
                <td>{midterm_select}</td>
                <td>{prefinal_select}</td>
                <td>{final_select}</td>
            </tr>
''')
        
        print('''
            </tbody>
        </table>
        <button type="submit" name="save_grades" value="1" class="save-button" id="saveButton" style="display:none;">Save</button>
    </form>
''')
    elif subjid_param and not enrolled_students:
        print('''
    <p style="margin-top: 30px; color: #6c757d; text-align: center;">No students enrolled in this subject.</p>
''')

print('''
</div>
<!-- Success Modal -->
<div class="modal-overlay" id="modalOverlay" onclick="closeModal()"></div>
<div class="success-modal" id="successModal">
    <div class="success-icon">✓</div>
    <div class="success-title">SUCCESS</div>
    <div class="success-message">Grades saved successfully.</div>
    <button class="close-modal-btn" onclick="closeModal()">Close</button>
</div>
<script>
function selectSubject(subjid) {
    window.location.href = 'encodegrades.py?tid=''' + tid_param + '''&subjid=' + subjid;
}

function selectStudent(eid, studid, studname) {
    // Update URL
    const url = new URL(window.location.href);
    url.searchParams.set('eid', eid);
    window.history.pushState({}, '', url);
    
    // Set the eid in the hidden form field
    document.getElementById('eid').value = eid;
    
    // Show save button
    document.getElementById('saveButton').style.display = 'block';
    
    // Highlight selected row
    document.querySelectorAll('#enrolledStudentsTable tbody tr').forEach(row => {
        row.classList.remove('selected');
    });
    event.currentTarget.classList.add('selected');
}

function enableSaveForRow(eid) {
    // Set the eid for saving
    document.getElementById('eid').value = eid;
    
    // Show save button
    document.getElementById('saveButton').style.display = 'block';
    
    // Highlight the row
    document.querySelectorAll('#enrolledStudentsTable tbody tr').forEach(row => {
        row.classList.remove('selected');
    });
    
    // Find and highlight the row that contains this dropdown
    const dropdown = event.target;
    const row = dropdown.closest('tr');
    if (row) {
        row.classList.add('selected');
        
        // Update URL
        const url = new URL(window.location.href);
        url.searchParams.set('eid', eid);
        window.history.pushState({}, '', url);
    }
}

function closeModal() {
    document.getElementById('successModal').classList.remove('show');
    document.getElementById('modalOverlay').classList.remove('show');
}

// Intercept form submission to add the selected row's grades
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('gradeForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const eid = document.getElementById('eid').value;
            if (!eid) {
                e.preventDefault();
                alert('Please select a student row first.');
                return false;
            }
            
            // Get the values from the dropdowns for this specific eid
            const prelimDropdown = document.getElementById('prelim_' + eid);
            const midtermDropdown = document.getElementById('midterm_' + eid);
            const prefinalDropdown = document.getElementById('prefinal_' + eid);
            const finalDropdown = document.getElementById('final_' + eid);
            
            if (prelimDropdown && midtermDropdown && prefinalDropdown && finalDropdown) {
                // Create hidden inputs with the correct names
                const createHiddenInput = (name, value) => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = name;
                    input.value = value;
                    return input;
                };
                
                // Remove any existing hidden grade inputs
                form.querySelectorAll('input[name="prelim"], input[name="midterm"], input[name="prefinal"], input[name="final"]').forEach(inp => inp.remove());
                
                // Add new ones with current values
                form.appendChild(createHiddenInput('prelim', prelimDropdown.value));
                form.appendChild(createHiddenInput('midterm', midtermDropdown.value));
                form.appendChild(createHiddenInput('prefinal', prefinalDropdown.value));
                form.appendChild(createHiddenInput('final', finalDropdown.value));
            }
        });
    }
});
''')

if saved_successfully:
    print('''
// Show success modal
document.getElementById('successModal').classList.add('show');
document.getElementById('modalOverlay').classList.add('show');
''')

print('''
</script>
</body>
</html>
''')
