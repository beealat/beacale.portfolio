#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MySQL to MongoDB Migration Script
Copies all semester databases from MySQL to MongoDB
"""
import sys
import os
import re

if sys.version_info[0] >= 3:
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import cgitb
cgitb.enable()
import cgi
import html
import pymysql
from pymongo import MongoClient

form = cgi.FieldStorage()
action = form.getvalue("action", "")

print("Content-Type: text/html; charset=utf-8\n")
print("<!DOCTYPE html>")
print("<html><head><title>MySQL to MongoDB Migration</title>")
print("<style>")
print("body { font-family: 'Georgia', serif; background: #f8f9fa; padding: 40px; }")
print(".header { background: #00356B; color: white; padding: 20px; margin-bottom: 30px; }")
print(".success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; margin: 10px 0; }")
print(".error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; margin: 10px 0; }")
print(".info { background: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; padding: 15px; margin: 10px 0; }")
print(".warning { background: #fff3cd; border: 1px solid #ffeeba; color: #856404; padding: 15px; margin: 10px 0; }")
print("table { border-collapse: collapse; width: 100%; background: white; margin: 20px 0; }")
print("th, td { border: 1px solid #dee2e6; padding: 12px; text-align: left; }")
print("th { background: #00356B; color: white; }")
print("tr:nth-child(even) { background: #f8f9fa; }")
print(".btn { background: #00356B; color: white; border: none; padding: 12px 24px; cursor: pointer; margin: 10px 5px; }")
print(".btn:hover { background: #00274C; }")
print("pre { background: #f1f1f1; padding: 10px; overflow-x: auto; font-size: 12px; }")
print("</style></head><body>")

print("<div class='header'>")
print("<h1>&#x1F504; MySQL to MongoDB Migration</h1>")
print("<p>Copy all semester databases from MySQL to MongoDB</p>")
print("</div>")

def get_primary_key(table_name, doc):
    """Safely get the _id value for a document based on table name."""
    pk_map = {
        'students': 'studid',
        'subjects': 'subjid',
        'teachers': 'tid',
        'enroll':   'eid',
        'grades':   'gradeid',
    }
    # assign table — try both casings
    if table_name == 'assign':
        for key in ['subjid', 'SubjID', 'SUBJID', 'assign_id', 'id']:
            if key in doc:
                return doc[key]
        return None

    pk_field = pk_map.get(table_name)
    if pk_field and pk_field in doc:
        return doc[pk_field]
    return None

# === START MIGRATION ===
if action == "migrate":
    print("<h2>Migration Started...</h2>")

    try:
        # Connect to MySQL
        print("<div class='info'>&#128204; Connecting to MySQL...</div>")
        mysql_conn = pymysql.connect(
            host="localhost",
            user="root",
            password="root",
            cursorclass=pymysql.cursors.DictCursor,
            charset='utf8mb4'
        )
        print("<div class='success'>&#9989; MySQL Connected</div>")

        # Connect to MongoDB
        print("<div class='info'>&#128204; Connecting to MongoDB...</div>")
        mongo_client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=5000)
        mongo_client.admin.command('ping')
        print("<div class='success'>&#9989; MongoDB Connected</div>")

        # Get all semester databases from MySQL
        print("<div class='info'>&#128204; Fetching semester databases...</div>")
        with mysql_conn.cursor() as cursor:
            cursor.execute("SHOW DATABASES")
            all_mysql_dbs = [row['Database'] for row in cursor.fetchall()]

        # Filter valid semester databases (matches your actual DB naming format)
        semester_dbs = []
        for db in all_mysql_dbs:
            if (re.match(r'^1stsy_\d{4}_\d{4}$', db) or
                re.match(r'^2ndsem_sy\d{4}_\d{4}$', db) or
                re.match(r'^summersy_\d{4}_\d{4}$', db)):
                semester_dbs.append(db)

        if not semester_dbs:
            print("<div class='error'><strong>&#10060; No matching semester databases found!</strong><br>")
            print("Found these databases in MySQL:<br><pre>")
            for db in all_mysql_dbs:
                print(html.escape(db))
            print("</pre>")
            print("Expected format: 1stsy_YYYY_YYYY, 2ndsem_syYYYY_YYYY, or summersy_YYYY_YYYY</div>")
        else:
            print(f"<div class='success'>&#128202; Found {len(semester_dbs)} semester database(s): {', '.join(html.escape(d) for d in semester_dbs)}</div>")

        # Tables to migrate
        tables = ['students', 'subjects', 'teachers', 'assign', 'enroll', 'grades']

        migration_summary = []

        for mysql_db_name in semester_dbs:
            print(f"<h3>Migrating: {html.escape(mysql_db_name)}</h3>")
            db_summary = {'db': mysql_db_name, 'tables': [], 'status': 'success'}

            try:
                mysql_conn.select_db(mysql_db_name)
                mongo_db = mongo_client[mysql_db_name]

                for table_name in tables:
                    table_summary = {'table': table_name, 'records': 0, 'status': 'success', 'errors': []}

                    try:
                        with mysql_conn.cursor() as cursor:
                            # Check if table exists first
                            cursor.execute("SHOW TABLES LIKE %s", (table_name,))
                            if not cursor.fetchone():
                                table_summary['status'] = 'skipped (table not found)'
                                db_summary['tables'].append(table_summary)
                                print(f"<div class='warning'>&#9888;&#65039; {table_name}: table does not exist in {html.escape(mysql_db_name)}, skipping.</div>")
                                continue

                            cursor.execute(f"SELECT * FROM `{table_name}`")
                            rows = cursor.fetchall()

                        if rows:
                            collection = mongo_db[table_name]

                            for row in rows:
                                doc = dict(row)

                                pk_value = get_primary_key(table_name, doc)

                                if pk_value is None:
                                    # No recognized PK — show warning and skip
                                    table_summary['errors'].append(f"No primary key found in row: {list(doc.keys())}")
                                    continue

                                doc['_id'] = pk_value

                                collection.update_one(
                                    {"_id": doc["_id"]},
                                    {"$set": doc},
                                    upsert=True
                                )
                                table_summary['records'] += 1

                            if table_summary['errors']:
                                table_summary['status'] = f"partial ({len(table_summary['errors'])} skipped)"
                            else:
                                table_summary['status'] = 'success'
                        else:
                            table_summary['status'] = 'empty (no rows in MySQL)'

                    except Exception as e:
                        import traceback
                        table_summary['status'] = f'error'
                        table_summary['errors'].append(str(e) + "\n" + traceback.format_exc())

                    db_summary['tables'].append(table_summary)

                    is_success = table_summary['status'] == 'success'
                    is_empty = 'empty' in table_summary['status']
                    div_class = 'success' if is_success else ('warning' if is_empty else 'error')
                    icon = '&#9989;' if is_success else ('&#8505;&#65039;' if is_empty else '&#9888;&#65039;')
                    print(f"<div class='{div_class}'>{icon} <strong>{table_name}</strong>: {table_summary['records']} records — {table_summary['status']}</div>")

                    if table_summary['errors']:
                        for err in table_summary['errors'][:3]:  # show max 3 errors
                            print(f"<pre>{html.escape(err)}</pre>")

                print(f"<div class='success'>&#9989; {html.escape(mysql_db_name)} done!</div>")

            except Exception as e:
                import traceback
                db_summary['status'] = f'error: {str(e)}'
                print(f"<div class='error'>&#10060; Error migrating {html.escape(mysql_db_name)}: {html.escape(str(e))}</div>")
                print(f"<pre>{html.escape(traceback.format_exc())}</pre>")

            migration_summary.append(db_summary)

        # Final Summary
        print("<h2>&#128202; Migration Summary</h2>")
        print("<table>")
        print("<thead><tr><th>Database</th><th>Table</th><th>Records</th><th>Status</th></tr></thead>")
        print("<tbody>")

        total_records = 0
        for db_sum in migration_summary:
            for tbl_sum in db_sum['tables']:
                total_records += tbl_sum['records']
                icon = '&#9989;' if tbl_sum['status'] == 'success' else '&#9888;&#65039;'
                print(f"<tr><td>{html.escape(db_sum['db'])}</td><td>{tbl_sum['table']}</td>"
                      f"<td>{tbl_sum['records']}</td><td>{icon} {tbl_sum['status']}</td></tr>")

        print("</tbody></table>")
        print(f"<div class='success'><h3>&#9989; Migration Complete!</h3>")
        print(f"<p>Total Records Migrated: <strong>{total_records}</strong></p>")
        print(f"<p>Total Databases: <strong>{len(migration_summary)}</strong></p></div>")

        mysql_conn.close()
        mongo_client.close()

        print("<div class='info'>&#128204; Refresh MongoDB Compass to see your data!</div>")
        print("<p><a href='index.py' class='btn'>Go to Login Page</a></p>")

    except Exception as e:
        import traceback
        print(f"<div class='error'><h3>&#10060; Migration Failed</h3>")
        print(f"<pre>{html.escape(str(e))}</pre>")
        print(f"<pre>{html.escape(traceback.format_exc())}</pre></div>")

# === SHOW MIGRATION FORM ===
else:
    print("<h2>Ready to Migrate?</h2>")
    print("<div class='info'>")
    print("<p><strong>What this script does:</strong></p>")
    print("<ul>")
    print("<li>Connects to MySQL (localhost, root, root)</li>")
    print("<li>Connects to MongoDB (mongodb://localhost:27017/)</li>")
    print("<li>Finds all semester databases matching your naming format</li>")
    print("<li>Copies all tables to MongoDB collections</li>")
    print("</ul>")
    print("</div>")

    print("<div class='info'>")
    print("<p><strong>Before you start:</strong></p>")
    print("<ul>")
    print("<li>&#9989; MySQL is running</li>")
    print("<li>&#9989; MongoDB is running (net start MongoDB)</li>")
    print("<li>&#9989; pymongo installed (pip install pymongo)</li>")
    print("<li>&#9989; pymysql installed (pip install pymysql)</li>")
    print("</ul>")
    print("</div>")

    print("<form method='post'>")
    print("<input type='hidden' name='action' value='migrate'>")
    print("<button type='submit' class='btn'>&#128640; Start Migration</button>")
    print("</form>")

    print("<h3>&#128203; What Will Be Migrated:</h3>")
    print("<table>")
    print("<thead><tr><th>MySQL Table</th><th>MongoDB Collection</th><th>Primary Key</th></tr></thead>")
    print("<tbody>")
    print("<tr><td>students</td><td>students</td><td>studid &rarr; _id</td></tr>")
    print("<tr><td>subjects</td><td>subjects</td><td>subjid &rarr; _id</td></tr>")
    print("<tr><td>teachers</td><td>teachers</td><td>tid &rarr; _id</td></tr>")
    print("<tr><td>assign</td><td>assign</td><td>SubjID &rarr; _id</td></tr>")
    print("<tr><td>enroll</td><td>enroll</td><td>eid &rarr; _id</td></tr>")
    print("<tr><td>grades</td><td>grades</td><td>gradeid &rarr; _id</td></tr>")
    print("</tbody></table>")

print("</body></html>")
