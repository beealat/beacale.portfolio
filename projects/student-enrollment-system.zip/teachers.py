#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
from datetime import datetime
import re
if sys.version_info[0] >= 3:
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import cgitb
cgitb.enable()
import cgi
import mysql.connector
import html
import json

# === CONFLICT DETECTION (Pure Python) ===
def check_teacher_assignment_conflict(conn, tid, subjid):
    cur = conn.cursor()
    try:
        # 1. Check if subject already assigned to another teacher
        cur.execute("SELECT TID FROM assign WHERE SubjID=%s AND TID!=%s", (subjid, tid))
        if cur.fetchone():
            return True, "Subject already assigned to another teacher"
        
        # 2. Get new subject schedule
        cur.execute("SELECT subjsched FROM subjects WHERE subjid=%s", (subjid,))
        result = cur.fetchone()
        new_sched = result[0] if result else None
        if not new_sched or not new_sched.strip():
            return False, None

        new_sched = new_sched.strip()
        parts = new_sched.split(' ', 1)
        if len(parts) < 2: return False, None
        new_days = parts[0].upper()
        time_part = parts[1]
        if '-' not in time_part: return False, None
        start_str, end_str = time_part.split('-', 1)
        try:
            new_start = datetime.strptime(start_str, '%H:%M').time()
            new_end = datetime.strptime(end_str, '%H:%M').time()
        except ValueError:
            return False, None

        # 3. Check teacher's existing subject schedules
        cur.execute("""
            SELECT s.subjsched FROM subjects s
            INNER JOIN assign a ON s.subjid = a.SubjID
            WHERE a.TID = %s AND s.subjsched != ''
        """, (tid,))
        for (old_sched,) in cur.fetchall():
            old_parts = old_sched.split(' ', 1)
            if len(old_parts) < 2: continue
            old_days = old_parts[0].upper()
            old_time_part = old_parts[1]
            if '-' not in old_time_part: continue
            try:
                old_start_str, old_end_str = old_time_part.split('-', 1)
                old_start = datetime.strptime(old_start_str, '%H:%M').time()
                old_end = datetime.strptime(old_end_str, '%H:%M').time()
            except ValueError:
                continue
            day_overlap = bool(set(new_days) & set(old_days))
            if day_overlap and new_start < old_end and old_start < new_end:
                return True, old_sched
        return False, None
    finally:
        cur.close()

# === MAIN ===
form = cgi.FieldStorage()

assign_action = form.getfirst("assign_action", "") or ""
assign_tid = form.getfirst("assign_tid", "") or ""
assign_subjid = form.getfirst("assign_subjid", "") or ""

enroll_action = form.getfirst("enroll_action", "") or ""
enroll_studid = form.getfirst("enroll_studid", "") or ""
enroll_subjid = form.getfirst("enroll_subjid", "") or ""

action = form.getfirst("action", "") or ""
tid = form.getfirst("tid", "") or ""
name = form.getfirst("name", "") or ""
department = form.getfirst("department", "") or ""
address = form.getfirst("address", "") or ""
contact = form.getfirst("contact", "") or ""
status = form.getfirst("status", "") or ""
subjid = form.getfirst("subjid", "") or ""
logout = form.getfirst("logout", "") or ""
create_db = form.getfirst("create_db", "") or ""

def get_cookie_value(cookie_name):
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith(cookie_name + '='):
                return cookie.split('=', 1)[1]
    return ""

user_role = get_cookie_value('user_role')
db_user = get_cookie_value('db_user')

if user_role == "student":
    print("Location: index.py\n")
    sys.exit()
elif user_role == "teacher":
    print("Location: index.py\n")
    sys.exit()
    
access_denied_msg = ""
if user_role == "student":
    if action:
        access_denied_msg = "ACCESS DENIED: Students cannot modify teachers."
        action = ""
    if assign_action:
        access_denied_msg = "ACCESS DENIED: Students cannot assign teachers."
        assign_action = ""
    if enroll_action:
        access_denied_msg = "ACCESS DENIED: Students cannot manage enrollments here."
        enroll_action = ""
    if create_db:
        access_denied_msg = "ACCESS DENIED: Students cannot create databases."
        create_db = ""
elif user_role == "teacher" and create_db:
    access_denied_msg = "ACCESS DENIED: Teachers cannot create databases."
    create_db = ""

if logout == "1":
    print("Set-Cookie: enrolled_db=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Set-Cookie: db_user=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Set-Cookie: user_role=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Location: index.py\n\n")
    sys.exit()

db_name = form.getfirst("db", "").strip()
if not db_name:
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith('enrolled_db='):
                db_name = cookie[12:]
                break

def get_all_valid_databases():
    import re as _re
    try:
        _conn = mysql.connector.connect(
            host="localhost", user="root", password="root",
            charset='utf8mb4', use_unicode=True
        )
        _cur = _conn.cursor()
        _cur.execute("SHOW DATABASES")
        all_dbs = [row[0] for row in _cur.fetchall()]
        _cur.close()
        _conn.close()
        return [d for d in all_dbs if (
            _re.match(r'^1stsy_\d{4}_\d{4}$', d) or
            _re.match(r'^2ndsem_sy\d{4}_\d{4}$', d) or
            _re.match(r'^summersy_\d{4}_\d{4}$', d)
        )]
    except:
        return []

VALID_DATABASES = get_all_valid_databases()
if not db_name or db_name not in VALID_DATABASES:
    print("Location: index.py\n\n")
    sys.exit()

# Handle enrollment (NOT USED in teachers.py - kept for compatibility)
if enroll_action in ["enroll_student", "drop_student"]:
    if enroll_studid.isdigit() and enroll_subjid.isdigit():
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database=db_name,
                charset='utf8mb4',
                use_unicode=True
            )
            cur = conn.cursor()
            if enroll_action == "enroll_student":
                cur.execute("SELECT 1 FROM enroll WHERE studid=%s AND subjid=%s",
                            (int(enroll_studid), int(enroll_subjid)))
                if not cur.fetchone():
                    cur.execute("INSERT INTO enroll (studid, subjid) VALUES (%s,%s)",
                                (int(enroll_studid), int(enroll_subjid)))
            elif enroll_action == "drop_student":
                cur.execute("DELETE FROM enroll WHERE studid=%s AND subjid=%s",
                            (int(enroll_studid), int(enroll_subjid)))
            conn.commit()
            cur.close()
            conn.close()
        except:
            pass

# Handle assignment (admin + teacher can assign)
assigned_teacher_id = ""
if assign_action in ["assign_subject", "remove_subject"]:
    if assign_tid.isdigit() and assign_subjid.isdigit():
        # Teachers can only assign to themselves
        if user_role == "teacher":
            # Extract teacher ID from username
            user_id_match = re.match(r'^(\d+)', db_user)
            if user_id_match:
                logged_in_tid = int(user_id_match.group(1))
                # Only allow if assigning to self
                if int(assign_tid) != logged_in_tid:
                    access_denied_msg = "ACCESS DENIED: Teachers can only assign to themselves."
                    assign_action = ""
        
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database=db_name,
                charset='utf8mb4',
                use_unicode=True
            )
            cur = conn.cursor()
            if assign_action == "assign_subject":
                cur.execute("SELECT TID FROM assign WHERE SubjID=%s", (int(assign_subjid),))
                existing = cur.fetchone()
                if existing:
                    cur.execute("UPDATE assign SET TID=%s WHERE SubjID=%s",
                                (int(assign_tid), int(assign_subjid)))
                else:
                    cur.execute("INSERT INTO assign (TID, SubjID) VALUES (%s,%s)",
                                (int(assign_tid), int(assign_subjid)))
            elif assign_action == "remove_subject":
                cur.execute("DELETE FROM assign WHERE TID=%s AND SubjID=%s",
                            (int(assign_tid), int(assign_subjid)))
            conn.commit()
            cur.close()
            conn.close()
        except:
            pass

# Create DB (admin only)
if user_role == "admin" and create_db in ["1st_sem", "2nd_sem", "summer"]:
    try:
        from datetime import datetime
        import re as _re
        conn_create = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            charset='utf8mb4',
            use_unicode=True
        )
        cur_create = conn_create.cursor()
        cur_create.execute("SHOW DATABASES")
        all_existing = [row[0] for row in cur_create.fetchall()]

        current_year = datetime.now().year
        source_db = None

        if create_db == "1st_sem":
            existing = []
            for d in all_existing:
                m = _re.match(r'^1stsy_(\d{4})_(\d{4})$', d)
                if m:
                    existing.append((int(m.group(1)), int(m.group(2)), d))
            if existing:
                existing.sort()
                last_yr1, last_yr2, last_db = existing[-1]
                new_yr1 = last_yr1 + 1
                summer_candidates = [d for d in all_existing
                    if _re.match(r'^summersy_(\d{4})_(\d{4})$', d) and
                    int(_re.match(r'^summersy_(\d{4})_(\d{4})$', d).group(1)) <= last_yr1]
                source_db = sorted(summer_candidates)[-1] if summer_candidates else last_db
            else:
                new_yr1 = current_year
                source_db = None
            new_db = f"1stsy_{new_yr1}_{new_yr1 + 1}"

        elif create_db == "2nd_sem":
            existing = []
            for d in all_existing:
                m = _re.match(r'^2ndsem_sy(\d{4})_(\d{4})$', d)
                if m:
                    existing.append((int(m.group(1)), int(m.group(2)), d))
            if existing:
                existing.sort()
                last_yr1, last_yr2, last_db = existing[-1]
                new_yr1 = last_yr1 + 1
                first_candidates = [d for d in all_existing
                    if _re.match(r'^1stsy_(\d{4})_(\d{4})$', d) and
                    int(_re.match(r'^1stsy_(\d{4})_(\d{4})$', d).group(1)) <= new_yr1]
                source_db = sorted(first_candidates)[-1] if first_candidates else last_db
            else:
                new_yr1 = current_year
                source_db = None
            new_db = f"2ndsem_sy{new_yr1}_{new_yr1 + 1}"

        elif create_db == "summer":
            existing = []
            for d in all_existing:
                m = _re.match(r'^summersy_(\d{4})_(\d{4})$', d)
                if m:
                    existing.append((int(m.group(1)), int(m.group(2)), d))
            if existing:
                existing.sort()
                last_yr1, last_yr2, last_db = existing[-1]
                new_yr1 = last_yr1 + 1
                second_candidates = [d for d in all_existing
                    if _re.match(r'^2ndsem_sy(\d{4})_(\d{4})$', d) and
                    int(_re.match(r'^2ndsem_sy(\d{4})_(\d{4})$', d).group(1)) <= new_yr1]
                source_db = sorted(second_candidates)[-1] if second_candidates else last_db
            else:
                new_yr1 = current_year
                source_db = None
            new_db = f"summersy_{new_yr1}_{new_yr1 + 1}"

        cur_create.execute(f"CREATE DATABASE `{new_db}`")
        cur_create.execute(f"USE `{new_db}`")

        schema_sql = """
        CREATE TABLE students (
            studid INT NOT NULL PRIMARY KEY,
            studname TEXT NOT NULL,
            studadd TEXT NULL,
            studcrs TEXT NULL,
            studgender TEXT NULL,
            yrlvl TEXT NULL
        );
        CREATE TABLE subjects (
            subjid INT NOT NULL PRIMARY KEY,
            subjcode TEXT NULL DEFAULT NULL,
            subjdesc TEXT NULL DEFAULT NULL,
            subjunits INT NULL DEFAULT NULL,
            subjsched TEXT NULL
        );
        CREATE TABLE teachers (
            tid INT NOT NULL PRIMARY KEY,
            tname TEXT NULL DEFAULT NULL,
            tdept TEXT NULL DEFAULT NULL,
            tadd TEXT NULL,
            tcontact TEXT NULL,
            tstatus TEXT NULL
        );
        CREATE TABLE assign (
            SubjID INT NOT NULL UNIQUE,
            TID INT NOT NULL,
            FOREIGN KEY (SubjID) REFERENCES subjects(subjid) ON DELETE CASCADE,
            FOREIGN KEY (TID) REFERENCES teachers(tid) ON DELETE CASCADE
        );
        CREATE TABLE enroll (
            eid INT NOT NULL AUTO_INCREMENT,
            studid INT NOT NULL,
            subjid INT NOT NULL,
            evaluation TEXT DEFAULT NULL,
            PRIMARY KEY (eid),
            UNIQUE (studid, subjid),
            FOREIGN KEY (studid) REFERENCES students(studid) ON DELETE CASCADE,
            FOREIGN KEY (subjid) REFERENCES subjects(subjid) ON DELETE CASCADE
        );
        CREATE TABLE grades (
            gradeid INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            enroll_eid INT NOT NULL UNIQUE,
            prelim TEXT NULL DEFAULT NULL,
            midterm TEXT NULL DEFAULT NULL,
            prefinal TEXT NULL DEFAULT NULL,
            final TEXT NULL DEFAULT NULL,
            FOREIGN KEY (enroll_eid) REFERENCES enroll(eid) ON DELETE CASCADE
        );
        """
        for stmt in schema_sql.strip().split(';'):
            if stmt.strip():
                cur_create.execute(stmt)

        # Copy data from source_db
        if source_db:
            try:
                conn_src = mysql.connector.connect(
                    host="localhost", user="root", password="root",
                    database=source_db, charset='utf8mb4', use_unicode=True
                )
                cur_src = conn_src.cursor()
                cur_src.execute("SELECT studid, studname, studadd, studcrs, studgender, yrlvl FROM students")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.students (studid,studname,studadd,studcrs,studgender,yrlvl) VALUES (%s,%s,%s,%s,%s,%s)", rows)
                cur_src.execute("SELECT subjid, subjcode, subjdesc, subjunits, subjsched FROM subjects")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.subjects (subjid,subjcode,subjdesc,subjunits,subjsched) VALUES (%s,%s,%s,%s,%s)", rows)
                cur_src.execute("SELECT tid, tname, tdept, tadd, tcontact, tstatus FROM teachers")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.teachers (tid,tname,tdept,tadd,tcontact,tstatus) VALUES (%s,%s,%s,%s,%s,%s)", rows)
                cur_src.execute("SELECT SubjID, TID FROM assign")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.assign (SubjID, TID) VALUES (%s,%s)", rows)
                cur_src.close()
                conn_src.close()
            except Exception:
                pass

        conn_create.commit()
        cur_create.close()
        conn_create.close()

        source_msg = f". Data copied from {source_db}." if source_db else "."
        print("Content-Type: text/html; charset=utf-8\n")
        print(f"<script>alert('Database {new_db} created successfully{source_msg}'); window.location.href='teachers.py?db={db_name}';</script>")
        sys.exit()
    except Exception as e:
        pass

# Main data fetch
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database=db_name,
        charset='utf8mb4',
        use_unicode=True
    )
    cur = conn.cursor()

    cur.execute("SELECT MAX(tid) FROM teachers")
    max_id_result = cur.fetchone()
    max_id = max_id_result[0] if max_id_result[0] is not None else 2999
    next_id = max_id + 1 if max_id >= 3000 else 3000

    # Admin CRUD for teachers (teacher role blocked from this)
    if user_role == "admin":
        if action == "insert":
            new_tid = next_id
            clean_name = re.sub(r'[^a-zA-Z]', '', name.strip()).lower()[:10]
            username_for_db = str(new_tid) + clean_name
            # ✅ UPDATED PASSWORD FORMAT
            clean_name_for_password = re.sub(r'[^a-zA-Z]', '', name.strip()).lower()
            password_for_db = "addu" + clean_name_for_password if clean_name_for_password else "adduuser"

            cur.execute(
                "INSERT INTO teachers (tid, tname, tdept, tadd, tcontact, tstatus) VALUES (%s,%s,%s,%s,%s,%s)",
                (new_tid, name, department, address, contact, status)
            )
            conn.commit()

            # ✅ Create MySQL user for teacher (only admin does this)
            try:
                cur_user = conn.cursor()
                cur_user.execute("CREATE USER IF NOT EXISTS %s@'localhost' IDENTIFIED BY %s", (username_for_db, password_for_db))
                cur_user.execute(f"GRANT SELECT ON `{db_name}`.`students` TO %s@'localhost'", (username_for_db,))
                cur_user.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON `{db_name}`.`subjects` TO %s@'localhost'", (username_for_db,))
                cur_user.execute(f"GRANT SELECT ON `{db_name}`.`teachers` TO %s@'localhost'", (username_for_db,))
                cur_user.execute(f"GRANT INSERT, DELETE ON `{db_name}`.`enroll` TO %s@'localhost'", (username_for_db,))
                cur_user.execute("FLUSH PRIVILEGES")
                cur_user.close()
            except:
                pass

            name = department = address = contact = status = ""
            tid = ""
            next_id += 1

        elif action == "update":
            if tid.isdigit():
                # Get old username before update
                cur.execute("SELECT tname FROM teachers WHERE tid = %s", (int(tid),))
                old_name_row = cur.fetchone()
                if old_name_row:
                    old_clean = re.sub(r'[^a-zA-Z]', '', old_name_row[0].strip()).lower()[:10]
                    old_username = str(tid) + old_clean

                    # Generate new username
                    new_clean = re.sub(r'[^a-zA-Z]', '', name.strip()).lower()[:10]
                    new_username = str(tid) + new_clean

                    # Only rename if name changed
                    if old_username != new_username:
                        try:
                            cur_user = conn.cursor()
                            cur_user.execute("RENAME USER %s@'localhost' TO %s@'localhost'", (old_username, new_username))
                            cur_user.execute("FLUSH PRIVILEGES")
                            cur_user.close()
                        except mysql.connector.Error as e:
                            pass  # Ignore if user doesn't exist

                cur.execute("""UPDATE teachers SET
                    tname=%s, tdept=%s, tadd=%s, tcontact=%s, tstatus=%s
                    WHERE tid=%s""", (name, department, address, contact, status, int(tid)))
                conn.commit()
                next_id = int(tid)

        elif action == "delete":
            if tid.isdigit():
                # Get username to drop
                cur.execute("SELECT tname FROM teachers WHERE tid = %s", (int(tid),))
                name_row = cur.fetchone()
                if name_row:
                    clean_name = re.sub(r'[^a-zA-Z]', '', name_row[0].strip()).lower()[:10]
                    username_to_drop = str(tid) + clean_name
                    try:
                        cur_user = conn.cursor()
                        # === NEW: REVOKE all privileges before dropping user ===
                        try:
                            cur_user.execute(f"REVOKE ALL PRIVILEGES, GRANT OPTION FROM '{username_to_drop}'@'localhost'")
                            cur_user.execute("FLUSH PRIVILEGES")
                        except mysql.connector.Error:
                            pass  # User might not have any privileges
                        # === END NEW CODE ===
                        cur_user.execute("DROP USER IF EXISTS %s@'localhost'", (username_to_drop,))
                        cur_user.execute("FLUSH PRIVILEGES")
                        cur_user.close()
                    except:
                        pass

                cur.execute("DELETE FROM teachers WHERE tid=%s", (int(tid),))
                conn.commit()
                name = department = address = contact = status = ""
                tid = ""
                cur.execute("SELECT MAX(tid) FROM teachers")
                max_id_result = cur.fetchone()
                max_id = max_id_result[0] if max_id_result[0] is not None else 2999
                next_id = max_id + 1 if max_id >= 3000 else 3000
    
    # Block teachers from modifying teacher records
    elif user_role == "teacher" and action in ["insert", "update", "delete"]:
        # Teachers cannot CRUD teacher records
        access_denied_msg = "ACCESS DENIED: Teachers cannot modify teacher records."
        action = ""

    # Fetch teachers
    cur.execute("""
        SELECT t.tid, t.tname, t.tdept, t.tadd, t.tcontact, t.tstatus,
        COUNT(DISTINCT a.SubjID) as subj_count,
        COALESCE(SUM(sub.subjunits), 0) as total_units
        FROM teachers t
        LEFT JOIN assign a ON t.tid = a.TID
        LEFT JOIN subjects sub ON a.SubjID = sub.subjid
        GROUP BY t.tid
        ORDER BY t.tid
    """)
    teachers = cur.fetchall()

    # Fetch subjects per teacher
    subjects_by_teacher = {}
    for t in teachers:
        tid_val = t[0]
        cur.execute("""
            SELECT subjid, subjcode, subjdesc, subjunits, subjsched
            FROM subjects
            WHERE subjid IN (SELECT SubjID FROM assign WHERE TID=%s)
        """, (tid_val,))
        subjects_by_teacher[tid_val] = cur.fetchall()

    safe_subjid = html.escape(subjid) if subjid else ""

    print("Content-Type: text/html; charset=utf-8\n")
    print(f'''<!DOCTYPE html>
<html>
<head>
<title>Teachers - Yale University Student Information System</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="header">
    <div class="logo">
        <img src="https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg  " alt="Yale University Logo">
    </div>
    <div class="header-text">
        <h1>STUDENT INFORMATION SYSTEM</h1>
        <p>YALE UNIVERSITY</p>
    </div>
</div>

<div class="nav-bar">
    <a href="#" onclick="goTo('students', event)">Students</a>
    <a href="#" onclick="goTo('subjects', event)">Subjects</a>
    <a href="#" onclick="goTo('teachers', event)" class="active">Teachers</a>
    <div class="create-db-dropdown">
        <button class="create-db-btn">Create DB <span style="font-size:12px">▼</span></button>
        <div class="create-db-dropdown-content">
            <a href="teachers.py?db={html.escape(db_name)}&create_db=1st_sem">1st Sem</a>
            <a href="teachers.py?db={html.escape(db_name)}&create_db=2nd_sem">2nd Sem</a>
            <a href="teachers.py?db={html.escape(db_name)}&create_db=summer">Summer</a>
        </div>
    </div>
    <button id="logout-btn" onclick="window.location.href='teachers.py?logout=1';">Logout</button>
</div>

<div class="main-content">
<div class="container">
<div class="form-section">
<h2>Teacher Form</h2>
<form method="post" id="teacherForm">
<input type="hidden" name="db" value="{html.escape(db_name)}">
<input type="hidden" name="subjid" value="{safe_subjid}">
ID:<br><input name="tid" id="tid" value="{next_id}" readonly><br>
Name:<br><input name="name" id="name" value="{html.escape(name)}"><br>
Department:<br><input name="department" id="department" value="{html.escape(department)}"><br>
Address:<br><input name="address" id="address" value="{html.escape(address)}"><br>
Contact:<br><input name="contact" id="contact" value="{html.escape(contact)}"><br>
Status:<br><input name="status" id="status" value="{html.escape(status)}"><br><br>

<!-- Buttons always visible (UI identical to admin) -->
<button type="submit" name="action" value="insert" class="btn-primary">Insert</button>
<button type="submit" name="action" value="update" class="btn-secondary">Update</button>
<button type="submit" name="action" value="delete" class="btn-danger">Delete</button>

<!-- ✅ ASSIGN SECTION (changed from enroll to assign for teachers) -->
<div class="enroll-section">
<form method="post" id="assignForm">
<input type="hidden" name="db" value="{html.escape(db_name)}">
<input type="hidden" name="assign_subjid" id="hidden_subjid" value="{safe_subjid}">
<input type="hidden" name="assign_tid" id="assign_tid" value="">
<button type="submit" name="assign_action" value="assign_subject" class="btn-primary" id="assignButton" style="display:none;">
Assign Teacher ID ? to Subject ID: {safe_subjid}
</button>
<button type="submit" name="assign_action" value="remove_subject" class="btn-danger" id="removeButton" style="display:none;">
Remove
</button>
<div id="conflictMessage" class="conflict-message" style="display:none;"></div>
</form>
</div>
</form>
</div>

<div class="table-section">
<h2>Teachers Table for: {html.escape(db_name)}</h2>
<table border="1" id="teachersTable">
<thead>
<tr>
<th width="70">ID</th>
<th width="150">Name</th>
<th width="120">Department</th>
<th width="150">Address</th>
<th width="100">Contact</th>
<th width="80">Status</th>
<th width="80">#Subj</th>
<th width="90">TotUnits</th>
</tr>
</thead>
<tbody>
''')

    for t in teachers:
        subjects_list = subjects_by_teacher.get(t[0], [])
        subjects_json = json.dumps(subjects_list).replace('"', '&quot;')
        teacher_assigned = False
        conflict_schedule = ""
        
        if subjid and subjid.isdigit():
            cur.execute("SELECT 1 FROM assign WHERE TID=%s AND SubjID=%s", (t[0], int(subjid)))
            teacher_assigned = cur.fetchone() is not None
            
            if not teacher_assigned:
                conflict_exists, conflict_msg = check_teacher_assignment_conflict(conn, t[0], int(subjid))
                if conflict_exists:
                    conflict_schedule = conflict_msg

        dept_val = t[2] if t[2] else ""
        addr_val = t[3] if t[3] else ""
        cont_val = t[4] if t[4] else ""
        stat_val = t[5] if t[5] else ""
        
        print(f'''
<tr data-tid="{t[0]}" 
    data-name="{html.escape(str(t[1]))}" 
    data-department="{html.escape(dept_val)}"
    data-address="{html.escape(addr_val)}" 
    data-contact="{html.escape(cont_val)}" 
    data-status="{html.escape(stat_val)}"
    data-subjects="{subjects_json}"
    data-assigned="{str(teacher_assigned).lower()}"
    data-conflict="{html.escape(conflict_schedule)}"
    onclick="selectTeacherRow(this)">
<td>{t[0]}</td>
<td>{html.escape(str(t[1]))}</td>
<td>{html.escape(dept_val)}</td>
<td>{html.escape(addr_val)}</td>
<td>{html.escape(cont_val)}</td>
<td>{html.escape(stat_val)}</td>
<td align="center">{t[6]}</td>
<td align="center">{t[7]}</td>
</tr>
''')

    print('''
</tbody>
</table>

<h2 id="assignedTitle">Assigned Subjects</h2>
<table border="1" id="assignedSubjectsTable">
<thead>
<tr>
<th width="70">Subject ID</th>
<th width="100">Code</th>
<th width="250">Description</th>
<th width="70">Units</th>
<th width="130">Schedule</th>
</tr>
</thead>
<tbody id="assignedSubjectsBody">
</tbody>
</table>
</div></div></div>

<script>
let currentSelectedRow = null;

function selectTeacherRow(row){
    const id = row.getAttribute('data-tid');
    const name = row.getAttribute('data-name');
    const department = row.getAttribute('data-department');
    const address = row.getAttribute('data-address');
    const contact = row.getAttribute('data-contact');
    const status = row.getAttribute('data-status');
    const subjects = JSON.parse(row.getAttribute('data-subjects').replace(/&quot;/g, '"'));
    const isAssigned = row.getAttribute('data-assigned') === 'true';
    const conflictSchedule = row.getAttribute('data-conflict');

    const url = new URL(window.location.href);
    url.searchParams.set('tid', id);
    url.searchParams.set('db', \'''' + html.escape(db_name) + '''\');
    const currentSubjid = document.getElementById('hidden_subjid').value;
    if(currentSubjid) url.searchParams.set('subjid', currentSubjid);
    window.history.pushState({},'',url.toString());

    document.getElementById('tid').value = id;
    document.getElementById('name').value = name;
    document.getElementById('department').value = department;
    document.getElementById('address').value = address;
    document.getElementById('contact').value = contact;
    document.getElementById('status').value = status;
    document.getElementById('assign_tid').value = id;

    // Update assign button
    const assignBtn = document.getElementById('assignButton');
    const removeBtn = document.getElementById('removeButton');
    const conflictMsg = document.getElementById('conflictMessage');
    
    if(!currentSubjid) {
        assignBtn.style.display = 'none';
        removeBtn.style.display = 'none';
        conflictMsg.style.display = 'none';
    } else {
        removeBtn.style.display = 'none';
        
        if(isAssigned) {
            assignBtn.style.display = 'none';
            conflictMsg.style.display = 'none';
        } else if(conflictSchedule) {
            assignBtn.style.display = 'none';
            conflictMsg.style.display = 'block';
            conflictMsg.textContent = "Conflict: " + conflictSchedule;
        } else {
            assignBtn.style.display = '';
            assignBtn.textContent = `Assign Teacher ID ${id} to Subject ID: ${currentSubjid}`;
            conflictMsg.style.display = 'none';
        }
    }

    const tbody = document.getElementById('assignedSubjectsBody');
    const title = document.getElementById('assignedTitle');
    tbody.innerHTML = '';
    if(subjects.length > 0) {
        title.textContent = 'Assigned Subjects';
        subjects.forEach(sub => {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${sub[0]}</td><td>${sub[1]}</td><td>${sub[2]}</td><td>${sub[3]}</td><td>${sub[4]}</td>`;
            tbody.appendChild(tr);
        });
    } else {
        title.textContent = 'Assigned Subjects';
    }

    if(currentSelectedRow) currentSelectedRow.classList.remove('selected');
    row.classList.add('selected');
    currentSelectedRow = row;
}

// Preserve subjid
function goTo(page, e) {
    e.preventDefault();
    const url = new URL(window.location);
    const db = url.searchParams.get('db') || '';
    const subjid = url.searchParams.get('subjid') || '';
    let target = '';
    if (page === 'students') target = `students.py?db=${encodeURIComponent(db)}`;
    else if (page === 'subjects') target = `subjects.py?db=${encodeURIComponent(db)}`;
    else if (page === 'teachers') target = `teachers.py?db=${encodeURIComponent(db)}`;
    if (subjid) target += `&subjid=${encodeURIComponent(subjid)}`;
    window.location.href = target;
}

window.onload = function(){
    const urlParams = new URLSearchParams(window.location.search);
    const tidParam = urlParams.get('tid');
    const subjidParam = urlParams.get('subjid');

    if (subjidParam) {
        document.getElementById('hidden_subjid').value = subjidParam;
        // ✅ Show button with question mark when subjid is present
        const assignBtn = document.getElementById('assignButton');
        if (assignBtn) {
            assignBtn.style.display = '';
            assignBtn.textContent = `Assign Teacher ID ? to Subject ID: ${subjidParam}`;
        }
    }

    if(tidParam){
        document.querySelectorAll('#teachersTable tbody tr').forEach(row=>{
            if(row.getAttribute('data-tid')===tidParam){
                selectTeacherRow(row);
            }
        });
    }
    
    // Show access denied message
    const accessMsg = "''' + access_denied_msg.replace('"', '\\"') + '''";
    if (accessMsg) alert(accessMsg);
    
    // Show success message for database creation
    const createdbParam = urlParams.get('createdb');
    const semesterParam = urlParams.get('semester');
    if (createdbParam === 'success' && semesterParam) {
        alert('Database ' + semesterParam + ' created successfully.');
    }
};
</script>
</body>
</html>
''')

except Exception as e:
    print("Content-Type: text/html; charset=utf-8\n")
    print("<h2>Database Error:</h2><pre>" + html.escape(str(e)) + "</pre>")
finally:
    try: conn.close()
    except: pass
