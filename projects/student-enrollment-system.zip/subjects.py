#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
if sys.version_info[0] >= 3:
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import cgitb
cgitb.enable()
import cgi
import mysql.connector
import html
import json

form = cgi.FieldStorage()

# === ADD ENROLL ACTION HANDLING ===
enroll_action = form.getfirst("enroll_action", "") or ""
enroll_studid = form.getfirst("enroll_studid", "") or ""
enroll_subjid = form.getfirst("enroll_subjid", "") or ""

action = form.getfirst("action", "") or ""
subjid = form.getfirst("subjid", "") or ""
code = form.getfirst("code", "") or ""
desc = form.getfirst("desc", "") or ""
units = form.getfirst("units", "") or ""
sched = form.getfirst("sched", "") or ""
logout = form.getfirst("logout", "")
create_db = form.getfirst("create_db", "")

def get_cookie_value(cookie_name):
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith(cookie_name + '='):
                return cookie.split('=', 1)[1]
    return ""

user_role = get_cookie_value('user_role')

# ✅ MOVE db_name ASSIGNMENT HERE (BEFORE PERMISSION CHECKS)
db_name = form.getfirst("db", "").strip()
if not db_name:
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith('enrolled_db='):
                db_name = cookie[12:]
                break

def get_all_valid_databases():
    """Dynamically fetch all valid SIS databases from MySQL."""
    import re as _re
    try:
        _conn = mysql.connector.connect(
            host="localhost", user="root", password="root",
            charset='utf8mb4', use_unicode=True
        )
        _cur = _conn.cursor()
        _cur.execute("SHOW DATABASES")
        all_dbs = [row[0] for row in _cur.fetchall()]
        _cur.close()
        _conn.close()
        return [d for d in all_dbs if (
            _re.match(r'^1stsy_\d{4}_\d{4}$', d) or
            _re.match(r'^2ndsem_sy\d{4}_\d{4}$', d) or
            _re.match(r'^summersy_\d{4}_\d{4}$', d)
        )]
    except:
        return []

VALID_DATABASES = get_all_valid_databases()
if not db_name or db_name not in VALID_DATABASES:
    print("Location: index.py\n\n")
    sys.exit()

# === REDIRECT NON-ADMIN USERS ===
if user_role == "student":
    # Students should only access studrec.py
    print("Location: index.py\n\n")
    sys.exit()
elif user_role == "teacher":
    # Teachers should only access encodegrades.py
    print("Location: index.py\n\n")
    sys.exit()

# === PERMISSION CHECKS (NOW SAFE) ===
if user_role == "student" and action:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<script>alert('Access denied: You don\\'t have permission to perform this action.'); window.location.href='subjects.py?db={html.escape(db_name)}';</script>")
    sys.exit()
if user_role == "student" and enroll_action:
    # Students can't manage enrollments in subjects.py — silently ignore
    pass
if user_role == "student" and create_db:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<script>alert('Access denied: You don\\'t have permission to perform this action.'); window.location.href='subjects.py?db={html.escape(db_name)}';</script>")
    sys.exit()
if user_role == "teacher" and create_db:
    # Teachers can't create DB — silently ignore (handled later)
    pass

if logout == "1":
    print("Set-Cookie: enrolled_db=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Set-Cookie: db_user=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Set-Cookie: user_role=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Location: index.py\n\n")
    sys.exit()

# Handle enrollment
if enroll_action in ["enroll_student", "drop_student"]:
    if enroll_studid.isdigit() and enroll_subjid.isdigit():
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database=db_name,
                charset='utf8mb4',
                use_unicode=True
            )
            cur = conn.cursor()
            if enroll_action == "enroll_student":
                cur.execute("SELECT 1 FROM enroll WHERE studid=%s AND subjid=%s",
                            (int(enroll_studid), int(enroll_subjid)))
                if not cur.fetchone():
                    cur.execute("INSERT INTO enroll (studid, subjid) VALUES (%s,%s)",
                                (int(enroll_studid), int(enroll_subjid)))
            elif enroll_action == "drop_student":
                cur.execute("DELETE FROM enroll WHERE studid=%s AND subjid=%s",
                            (int(enroll_studid), int(enroll_subjid)))
            conn.commit()
            cur.close()
            conn.close()
        except:
            pass

if user_role == "admin" and create_db in ["1st_sem", "2nd_sem", "summer"]:
    try:
        from datetime import datetime
        import re as _re
        conn_create = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            charset='utf8mb4',
            use_unicode=True
        )
        cur_create = conn_create.cursor()
        cur_create.execute("SHOW DATABASES")
        all_existing = [row[0] for row in cur_create.fetchall()]

        current_year = datetime.now().year
        source_db = None

        if create_db == "1st_sem":
            existing = []
            for d in all_existing:
                m = _re.match(r'^1stsy_(\d{4})_(\d{4})$', d)
                if m:
                    existing.append((int(m.group(1)), int(m.group(2)), d))
            if existing:
                existing.sort()
                last_yr1, last_yr2, last_db = existing[-1]
                new_yr1 = last_yr1 + 1
                summer_candidates = [d for d in all_existing
                    if _re.match(r'^summersy_(\d{4})_(\d{4})$', d) and
                    int(_re.match(r'^summersy_(\d{4})_(\d{4})$', d).group(1)) <= last_yr1]
                source_db = sorted(summer_candidates)[-1] if summer_candidates else last_db
            else:
                new_yr1 = current_year
                source_db = None
            new_db = f"1stsy_{new_yr1}_{new_yr1 + 1}"

        elif create_db == "2nd_sem":
            existing = []
            for d in all_existing:
                m = _re.match(r'^2ndsem_sy(\d{4})_(\d{4})$', d)
                if m:
                    existing.append((int(m.group(1)), int(m.group(2)), d))
            if existing:
                existing.sort()
                last_yr1, last_yr2, last_db = existing[-1]
                new_yr1 = last_yr1 + 1
                first_candidates = [d for d in all_existing
                    if _re.match(r'^1stsy_(\d{4})_(\d{4})$', d) and
                    int(_re.match(r'^1stsy_(\d{4})_(\d{4})$', d).group(1)) <= new_yr1]
                source_db = sorted(first_candidates)[-1] if first_candidates else last_db
            else:
                new_yr1 = current_year
                source_db = None
            new_db = f"2ndsem_sy{new_yr1}_{new_yr1 + 1}"

        elif create_db == "summer":
            existing = []
            for d in all_existing:
                m = _re.match(r'^summersy_(\d{4})_(\d{4})$', d)
                if m:
                    existing.append((int(m.group(1)), int(m.group(2)), d))
            if existing:
                existing.sort()
                last_yr1, last_yr2, last_db = existing[-1]
                new_yr1 = last_yr1 + 1
                second_candidates = [d for d in all_existing
                    if _re.match(r'^2ndsem_sy(\d{4})_(\d{4})$', d) and
                    int(_re.match(r'^2ndsem_sy(\d{4})_(\d{4})$', d).group(1)) <= new_yr1]
                source_db = sorted(second_candidates)[-1] if second_candidates else last_db
            else:
                new_yr1 = current_year
                source_db = None
            new_db = f"summersy_{new_yr1}_{new_yr1 + 1}"

        cur_create.execute(f"CREATE DATABASE `{new_db}`")
        cur_create.execute(f"USE `{new_db}`")

        schema_sql = """
        CREATE TABLE students (
            studid INT NOT NULL PRIMARY KEY,
            studname TEXT NOT NULL,
            studadd TEXT NULL,
            studcrs TEXT NULL,
            studgender TEXT NULL,
            yrlvl TEXT NULL
        );
        CREATE TABLE subjects (
            subjid INT NOT NULL PRIMARY KEY,
            subjcode TEXT NULL DEFAULT NULL,
            subjdesc TEXT NULL DEFAULT NULL,
            subjunits INT NULL DEFAULT NULL,
            subjsched TEXT NULL
        );
        CREATE TABLE teachers (
            tid INT NOT NULL PRIMARY KEY,
            tname TEXT NULL DEFAULT NULL,
            tdept TEXT NULL DEFAULT NULL,
            tadd TEXT NULL,
            tcontact TEXT NULL,
            tstatus TEXT NULL
        );
        CREATE TABLE assign (
            SubjID INT NOT NULL UNIQUE,
            TID INT NOT NULL,
            FOREIGN KEY (SubjID) REFERENCES subjects(subjid) ON DELETE CASCADE,
            FOREIGN KEY (TID) REFERENCES teachers(tid) ON DELETE CASCADE
        );
        CREATE TABLE enroll (
            eid INT NOT NULL AUTO_INCREMENT,
            studid INT NOT NULL,
            subjid INT NOT NULL,
            evaluation TEXT DEFAULT NULL,
            PRIMARY KEY (eid),
            UNIQUE (studid, subjid),
            FOREIGN KEY (studid) REFERENCES students(studid) ON DELETE CASCADE,
            FOREIGN KEY (subjid) REFERENCES subjects(subjid) ON DELETE CASCADE
        );
        CREATE TABLE grades (
            gradeid INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            enroll_eid INT NOT NULL UNIQUE,
            prelim TEXT NULL DEFAULT NULL,
            midterm TEXT NULL DEFAULT NULL,
            prefinal TEXT NULL DEFAULT NULL,
            final TEXT NULL DEFAULT NULL,
            FOREIGN KEY (enroll_eid) REFERENCES enroll(eid) ON DELETE CASCADE
        );
        """
        for stmt in schema_sql.strip().split(';'):
            if stmt.strip():
                cur_create.execute(stmt)

        # Copy data from source_db
        if source_db:
            try:
                conn_src = mysql.connector.connect(
                    host="localhost", user="root", password="root",
                    database=source_db, charset='utf8mb4', use_unicode=True
                )
                cur_src = conn_src.cursor()
                cur_src.execute("SELECT studid, studname, studadd, studcrs, studgender, yrlvl FROM students")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.students (studid,studname,studadd,studcrs,studgender,yrlvl) VALUES (%s,%s,%s,%s,%s,%s)", rows)
                cur_src.execute("SELECT subjid, subjcode, subjdesc, subjunits, subjsched FROM subjects")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.subjects (subjid,subjcode,subjdesc,subjunits,subjsched) VALUES (%s,%s,%s,%s,%s)", rows)
                cur_src.execute("SELECT tid, tname, tdept, tadd, tcontact, tstatus FROM teachers")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.teachers (tid,tname,tdept,tadd,tcontact,tstatus) VALUES (%s,%s,%s,%s,%s,%s)", rows)
                cur_src.execute("SELECT SubjID, TID FROM assign")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.assign (SubjID, TID) VALUES (%s,%s)", rows)
                cur_src.close()
                conn_src.close()
            except Exception:
                pass

        conn_create.commit()
        cur_create.close()
        conn_create.close()

        source_msg = f". Data copied from {source_db}." if source_db else "."
        print("Content-Type: text/html; charset=utf-8\n")
        print(f"<script>alert('Database {new_db} created successfully{source_msg}'); window.location.href='subjects.py?db={db_name}';</script>")
        sys.exit()

    except Exception as e:
        pass

just_inserted_id = None

try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database=db_name,
        charset='utf8mb4',
        use_unicode=True
    )
    cur = conn.cursor()

    cur.execute("SELECT MAX(subjid) FROM subjects")
    max_id_result = cur.fetchone()
    max_id = max_id_result[0] if max_id_result[0] is not None else 1999
    next_id = max_id + 1 if max_id >= 2000 else 2000

    if user_role in ["admin", "teacher"]:
        if action == "insert":
            new_subjid = next_id
            cur.execute(
                "INSERT INTO subjects (subjid, subjcode, subjdesc, subjunits, subjsched) VALUES (%s,%s,%s,%s,%s)",
                (new_subjid, code, desc, units, sched)
            )
            conn.commit()
            
            just_inserted_id = new_subjid
            
            code = desc = units = sched = ""
            subjid = ""
            cur.execute("SELECT MAX(subjid) FROM subjects")
            max_id = cur.fetchone()[0] or 1999
            next_id = max_id + 1

        elif action == "update":
            if subjid and subjid.isdigit():
                cur.execute("""
                    UPDATE subjects 
                    SET subjcode=%s, subjdesc=%s, subjunits=%s, subjsched=%s 
                    WHERE subjid=%s
                """, (code, desc, units, sched, int(subjid)))
                conn.commit()
                next_id = int(subjid)

        elif action == "delete":
            if subjid and subjid.isdigit():
                cur.execute("DELETE FROM subjects WHERE subjid=%s", (int(subjid),))
                conn.commit()
                code = desc = units = sched = ""
                subjid = ""
                cur.execute("SELECT MAX(subjid) FROM subjects")
                max_id = cur.fetchone()[0] or 1999
                next_id = max_id + 1 if max_id >= 2000 else 2000

    cur.execute("""
        SELECT s.subjid, s.subjcode, s.subjdesc, s.subjunits, s.subjsched, COUNT(e.studid)
        FROM subjects s
        LEFT JOIN enroll e ON s.subjid = e.subjid
        GROUP BY s.subjid
        ORDER BY s.subjid
    """)
    subjects = cur.fetchall()

    students_by_subject = {}
    # ✅ SHOW FOR ALL ROLES (not just admin)
    for s in subjects:
        sid = s[0]
        cur.execute("""
            SELECT studid, studname, studadd, studgender, studcrs, yrlvl
            FROM students
            WHERE studid IN (SELECT studid FROM enroll WHERE subjid = %s)
        """, (sid,))
        students_by_subject[sid] = cur.fetchall()

    safe_subjid = html.escape(subjid) if subjid else ""

    html_output = '''<!DOCTYPE html>
<html>
<head>
    <title>Subjects - Yale University Student Information System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg" alt="Yale University Logo">
        </div>
        <div class="header-text">
            <h1>STUDENT INFORMATION SYSTEM</h1>
            <p>YALE UNIVERSITY</p>
        </div>
    </div>
    
    <div class="nav-bar">
        <!-- ✅ FIXED: Highlight correct tab -->
        <a href="#" onclick="goTo('students', event)">Students</a>
        <a href="#" onclick="goTo('subjects', event)" class="active">Subjects</a>
        <a href="#" onclick="goTo('teachers', event)">Teachers</a>
'''

    # ✅ SHOW CREATE DB DROPDOWN TO ALL (identical UI)
    html_output += '''    <div class="create-db-dropdown">
        <button class="create-db-btn">Create DB <span style="font-size:12px">▼</span></button>
        <div class="create-db-dropdown-content">
            <a href="subjects.py?db=''' + html.escape(db_name) + '''&create_db=1st_sem">1st Sem</a>
            <a href="subjects.py?db=''' + html.escape(db_name) + '''&create_db=2nd_sem">2nd Sem</a>
            <a href="subjects.py?db=''' + html.escape(db_name) + '''&create_db=summer">Summer</a>
        </div>
    </div>
'''

    html_output += '''        <button id="logout-btn" onclick="window.location.href=\'subjects.py?logout=1\';">Logout</button>
    </div>
    
    <div class="main-content">
        <div class="container">
'''

    # === FORM SECTION - NO ENROLL BUTTON ===
    html_output += f'''            <div class="form-section">
                <h2>Subject Form</h2>
                <form method="post">
                    <input type="hidden" name="db" value="{html.escape(db_name)}">
                    <input type="hidden" name="subjid" value="{safe_subjid}">
                    Subject ID:<br><input name="subjid" id="subjid" value="{next_id}" readonly><br>
                    Subject Code:<br><input name="code" id="code" value="{html.escape(code)}"><br>
                    Description:<br><input name="desc" id="desc" value="{html.escape(desc)}"><br>
                    Units:<br><input name="units" id="units" value="{html.escape(units)}"><br>
                    Schedule:<br><input name="sched" id="sched" value="{html.escape(sched)}"><br><br>
                    
                    <button type="submit" name="action" value="insert" class="btn-primary">Insert</button>
                    <button type="submit" name="action" value="update" class="btn-secondary">Update</button>
                    <button type="submit" name="action" value="delete" class="btn-danger">Delete</button>
                </form>
            </div>
'''

    html_output += '''
            <div class="table-section">
                <h2>Subjects Table</h2>
                <table id="subjectsTable">
                    <thead>
                        <tr>
                            <th>ID</th><th>Code</th><th>Description</th><th>Units</th><th>Schedule</th><th>#Students</th>
                        </tr>
                    </thead>
                    <tbody>
'''

    for s in subjects:
        students_json = json.dumps(students_by_subject.get(s[0], [])).replace('"', '&quot;')
        html_output += f'''
                    <tr data-subjid="{s[0]}" 
                        data-code="{html.escape(str(s[1]))}" 
                        data-desc="{html.escape(str(s[2]))}" 
                        data-units="{s[3] if s[3] is not None else ''}" 
                        data-sched="{html.escape(str(s[4]))}" 
                        data-students="{students_json}"
                        onclick="selectSubjectRow(this)">
                        <td>{s[0]}</td>
                        <td>{html.escape(str(s[1]))}</td>
                        <td>{html.escape(str(s[2]))}</td>
                        <td>{s[3]}</td>
                        <td>{html.escape(str(s[4]))}</td>
                        <td align="center">{s[5]}</td>
                    </tr>
        '''

    html_output += '''
                    </tbody>
                </table>
                <!-- ✅ ALWAYS SHOW ASSIGNED STUDENTS TABLE -->
                <div id="enrolledSection">
                    <h2 id="enrolledTitle"></h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th><th>Name</th><th>Address</th><th>Gender</th><th>Course</th><th>Year</th>
                            </tr>
                        </thead>
                        <tbody id="enrolledStudentsBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentSelectedRow = null;

        function selectSubjectRow(row, updateUrl = true, highlightRow = true) {
            const id = row.dataset.subjid;
            const students = JSON.parse(row.dataset.students.replace(/&quot;/g,'"'));
            
            if (updateUrl) {
                const url = new URL(window.location.href);
                url.searchParams.set('subjid', id);
                url.searchParams.set('db', \'''' + html.escape(db_name) + '''\');
                history.replaceState(null,'',url);
            }
            
            document.getElementById('subjid').value = id;
            document.getElementById('code').value = row.dataset.code;
            document.getElementById('desc').value = row.dataset.desc;
            document.getElementById('units').value = row.dataset.units;
            document.getElementById('sched').value = row.dataset.sched;

            const tbody = document.getElementById('enrolledStudentsBody');
            const title = document.getElementById('enrolledTitle');
            tbody.innerHTML = '';
            document.getElementById('enrolledSection').style.display = 'block';

            if (students.length) {
                title.textContent = 'Students Enrolled in Subject ID ' + id;
                students.forEach(s => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = '<td>' + s[0] + '</td>' +
                                   '<td>' + s[1] + '</td>' +
                                   '<td>' + s[2] + '</td>' +
                                   '<td>' + s[3] + '</td>' +
                                   '<td>' + s[4] + '</td>' +
                                   '<td>' + s[5] + '</td>';
                    tbody.appendChild(tr);
                });
            } else {
                title.textContent = 'Students Enrolled in Subject ID ' + id;
            }

            if (highlightRow) {
                if (currentSelectedRow) currentSelectedRow.classList.remove('selected');
                row.classList.add('selected');
                currentSelectedRow = row;
            }
        }

        // 🔑 Preserve subjid when navigating
        function goTo(page, e) {
            e.preventDefault();
            const url = new URL(window.location);
            const db = url.searchParams.get('db') || '';
            const subjid = url.searchParams.get('subjid') || '';
            let target = '';

            if (page === 'students') target = `students.py?db=${encodeURIComponent(db)}`;
            else if (page === 'subjects') target = `subjects.py?db=${encodeURIComponent(db)}`;
            else if (page === 'teachers') target = `teachers.py?db=${encodeURIComponent(db)}`;

            if (subjid) target += `&subjid=${encodeURIComponent(subjid)}`;

            window.location.href = target;
        }

        window.onload = function() {
            const justInsertedId = "''' + (str(just_inserted_id) if just_inserted_id else "") + '''";
            
            if (justInsertedId) {
                document.querySelectorAll('#subjectsTable tbody tr').forEach(r => {
                    if (r.dataset.subjid === justInsertedId) {
                        selectSubjectRow(r, false, false);
                    }
                });
            } else {
                const urlParams = new URLSearchParams(window.location.search);
                const subjidParam = urlParams.get('subjid');
                if (subjidParam) {
                    document.querySelectorAll('#subjectsTable tbody tr').forEach(r => {
                        if (r.dataset.subjid === subjidParam) {
                            selectSubjectRow(r, false, true);
                        }
                    });
                }
                
                // Show success message for database creation
                const createdbParam = urlParams.get('createdb');
                const semesterParam = urlParams.get('semester');
                if (createdbParam === 'success' && semesterParam) {
                    alert('Database ' + semesterParam + ' created successfully.');
                }
            }
        };
    </script>
</body>
</html>
    '''

    print("Content-Type: text/html; charset=utf-8\n")
    print(html_output)

except Exception as e:
    print("Content-Type: text/html; charset=utf-8\n")
    print("<h2>Error</h2><pre>" + html.escape(str(e)) + "</pre>")
finally:
    try:
        conn.close()
    except:
        pass
