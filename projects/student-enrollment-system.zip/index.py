#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import re
if sys.version_info[0] >= 3:
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import cgitb
cgitb.enable()
import cgi
import mysql.connector
import html

form = cgi.FieldStorage()

username = form.getfirst("username", "").strip()
password = form.getfirst("password", "").strip()
db_name = form.getfirst("db_name", "").strip()
action = form.getfirst("action", "")

error_msg = ""
show_db_selection = False
valid_dbs = []

# === STEP 1: Authenticate MySQL credentials ===
if action == "login":
    if not username or not password:
        error_msg = "Username and password are required."
    else:
        # Validate password format for students/teachers
        if username == "root":
            expected_password = password
        else:
            # Format: studid_firstname (case-insensitive) e.g. 1000_Aaron or 1000_aaron
            # Password: addu + firstname lowercase e.g. adduaaron
            match = re.match(r'^(\d+)_([a-zA-Z]+)$', username)
            if match:
                first_name_part = match.group(2).lower()
                expected_password = "addu" + first_name_part
            else:
                expected_password = None
        
        if expected_password is None or password != expected_password:
            error_msg = "unrecognized"
        else:
            try:
                # Step 1: Verify the user exists in the DB tables.
                # We do NOT require a MySQL user account — this allows manually
                # inserted students/teachers (via cmd/phpMyAdmin) to log in too.
                # Authentication is based on: password formula + DB record existence.
                if username != "root":
                    uname_match = re.match(r'^(\d+)_([a-zA-Z]+)$', username)
                    if not uname_match:
                        raise mysql.connector.Error("Bad credentials")

                    check_id = int(uname_match.group(1))
                    typed_first = uname_match.group(2).lower()

                    # Find this user in any semester DB
                    found_user = False
                    try:
                        conn_pre = mysql.connector.connect(
                            host="localhost", user="root", password="root",
                            charset='utf8mb4', use_unicode=True
                        )
                        cur_pre = conn_pre.cursor()
                        cur_pre.execute("SHOW DATABASES")
                        all_dbs_pre = [r[0] for r in cur_pre.fetchall()]
                        conn_pre.close()
                    except:
                        all_dbs_pre = []

                    for db_pre in all_dbs_pre:
                        if not (re.match(r'^1stsy_\d{4}_\d{4}$', db_pre) or
                                re.match(r'^2ndsem_sy\d{4}_\d{4}$', db_pre) or
                                re.match(r'^summersy_\d{4}_\d{4}$', db_pre)):
                            continue
                        try:
                            conn_v = mysql.connector.connect(
                                host="localhost", user="root", password="root",
                                database=db_pre, charset='utf8mb4', use_unicode=True
                            )
                            cur_v = conn_v.cursor()

                            # Check students table — first name is the first word of studname
                            cur_v.execute(
                                "SELECT studname FROM students WHERE studid = %s", (check_id,)
                            )
                            s_row = cur_v.fetchone()
                            if s_row:
                                actual_first = s_row[0].strip().split()[0].lower()
                                if typed_first == actual_first:
                                    found_user = True
                                    cur_v.close()
                                    conn_v.close()
                                    break

                            # Check teachers table — strip Dr./Prof./Mr./Ms./Mrs. first
                            cur_v.execute(
                                "SELECT tname FROM teachers WHERE tid = %s", (check_id,)
                            )
                            t_row = cur_v.fetchone()
                            if t_row:
                                tname_clean = re.sub(
                                    r'(?i)^(dr\.|prof\.|mr\.|ms\.|mrs\.)\s*', '', t_row[0].strip()
                                )
                                actual_first = tname_clean.split()[0].lower()
                                if typed_first == actual_first:
                                    found_user = True
                                    cur_v.close()
                                    conn_v.close()
                                    break

                            cur_v.close()
                            conn_v.close()
                        except:
                            pass

                    if not found_user:
                        raise mysql.connector.Error("Bad credentials")

                # Step 2: Use root to list all databases (student users can't run SHOW DATABASES)
                conn = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="root",
                    charset='utf8mb4',
                    use_unicode=True
                )
                cur = conn.cursor()
                cur.execute("SHOW DATABASES")
                all_databases = [row[0] for row in cur.fetchall()]
                conn.close()

                # Filter valid databases
                for db in all_databases:
                    if (re.match(r'^1stsy_\d{4}_\d{4}$', db) or
                        re.match(r'^2ndsem_sy\d{4}_\d{4}$', db) or
                        re.match(r'^summersy_\d{4}_\d{4}$', db)):
                        if re.match(r'^\d+_[a-zA-Z]+$', username):
                            try:
                                user_id_match = re.match(r'^(\d+)_', username)
                                if user_id_match:
                                    user_id = int(user_id_match.group(1))
                                    conn_check = mysql.connector.connect(
                                        host="localhost",
                                        user="root",
                                        password="root",
                                        database=db,
                                        charset='utf8mb4',
                                        use_unicode=True
                                    )
                                    cur_check = conn_check.cursor()
                                    cur_check.execute("SELECT 1 FROM students WHERE studid = %s", (user_id,))
                                    is_student = cur_check.fetchone() is not None
                                    if not is_student:
                                        cur_check.execute("SELECT 1 FROM teachers WHERE tid = %s", (user_id,))
                                        is_teacher = cur_check.fetchone() is not None
                                    else:
                                        is_teacher = False
                                    if is_student or is_teacher:
                                        valid_dbs.append(db)
                                    cur_check.close()
                                    conn_check.close()
                            except:
                                pass
                        else:
                            valid_dbs.append(db)
                
                show_db_selection = True
                
            except mysql.connector.Error:
                error_msg = "unrecognized"

# === STEP 2: Select school year database ===
elif action == "select_db":
    if not db_name:
        error_msg = "Please select a school year database."
    else:
        try:
            conn_check = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database=db_name,
                charset='utf8mb4',
                use_unicode=True
            )
            cur_check = conn_check.cursor()
            
            if username == "root":
                user_role = "admin"
            else:
                user_id = None
                match = re.match(r'^(\d+)_', username)
                if match:
                    user_id = int(match.group(1))
                
                if user_id is not None:
                    cur_check.execute("SELECT 1 FROM students WHERE studid = %s", (user_id,))
                    if cur_check.fetchone():
                        user_role = "student"
                    else:
                        cur_check.execute("SELECT 1 FROM teachers WHERE tid = %s", (user_id,))
                        if cur_check.fetchone():
                            user_role = "teacher"
                        else:
                            user_role = "student"
                else:
                    user_role = "student"
                    
            cur_check.close()
            conn_check.close()
        except:
            user_role = "student"

        print(f"Set-Cookie: enrolled_db={db_name}; Path=/; Max-Age=3600")
        print(f"Set-Cookie: db_user={username}; Path=/; Max-Age=3600")
        print(f"Set-Cookie: user_role={user_role}; Path=/; Max-Age=3600")

        # Redirect based on user role
        if user_role == "teacher":
            # Extract tid from username (e.g., "3000_john" → 3000)
            tid_match = re.match(r'^(\d+)_', username)
            if tid_match:
                tid_val = tid_match.group(1)
                print(f"Location: encodegrades.py?tid={tid_val}\n")
            else:
                print("Location: students.py\n")
        elif user_role == "student":
            # Redirect students to their grade sheet
            print(f"Location: studrec.py?db={db_name}\n")
        else:
            # Admin or other roles go to students.py
            print("Location: students.py\n")
        sys.exit()

# === RENDER PAGE ===
print("Content-Type: text/html; charset=utf-8\n\n")

print('''<!DOCTYPE html>
<html>
<head>
    <title>Student Information System</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: 'Georgia', serif; background:#f8f9fa; }
        .header { 
            background: linear-gradient(135deg, #00356B 0%, #00274C 100%); 
            color: white; 
            padding: 20px 40px; 
            display: flex; 
            align-items: center; 
            gap: 20px;
        }
        .logo { 
            width: 60px; 
            height: 60px; 
            background: white; 
            border-radius: 8px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            border: 2px solid #FFD700;
        }
        .logo img { 
            width: 100%; 
            height: 100%; 
            object-fit: contain; 
            border-radius: 4px;
        }
        .header-text h1 { 
            font-size: 28px; 
            margin: 0; 
            letter-spacing: 0.5px;
        }
        .header-text p { 
            font-size: 16px; 
            opacity: 0.9;
        }
        .main-content { 
            padding: 40px; 
            display: flex; 
            gap: 40px;
        }
        .login-panel {
            flex: 0 0 280px;
            background: #f8f9fa;
            padding: 25px;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }
        .welcome-panel {
            flex: 1;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .login-panel h2 { 
            color: #00356B; 
            margin-bottom: 20px; 
            font-size: 20px;
        }
        .login-panel label {
            display: block;
            margin-top: 15px;
            font-weight: 600;
            color: #333;
        }
        .login-panel input, .login-panel select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ced4da;
            border-radius: 4px;
        }
        .btn-primary {
            background: #00356B;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
            margin-top: 10px;
        }
        .btn-primary:hover {
            background: #00274C;
        }
        .error-box {
            margin-top: 20px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
            padding: 16px;
        }
        .error-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        .error-title {
            color: #721c24;
            font-weight: bold;
            font-size: 14px;
        }
        .error-close {
            color: #721c24;
            font-weight: bold;
            cursor: pointer;
            font-size: 14px;
        }
        .error-body {
            display: flex;
            align-items: center;
            color: #721c24;
            font-size: 14px;
        }
        .error-icon {
            margin-right: 8px;
            font-weight: bold;
        }
        .db-selection {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid #e9ecef;
        }
    </style>
</head>
<body>
<div class="header">
    <div class="logo">
        <img src="https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg" alt="Yale Logo">
    </div>
    <div class="header-text">
        <h1>STUDENT INFORMATION SYSTEM</h1>
        <p>YALE UNIVERSITY</p>
    </div>
</div>

<div class="main-content">
    <div class="login-panel">
        <h2>Login</h2>
        <form method="post">
            <input type="hidden" name="action" value="login">
            <label>Username:</label>
            <input type="text" name="username" value="''' + html.escape(username) + '''" required>
            
            <label>Password:</label>
            <input type="password" name="password" value="''' + html.escape(password) + '''" required>
            
            <button type="submit" class="btn-primary">Login</button>
        </form>
''')

# Show database selection if login successful
if show_db_selection:
    print('''
        <div class="db-selection">
            <form method="post">
                <input type="hidden" name="action" value="select_db">
                <input type="hidden" name="username" value="''' + html.escape(username) + '''">
                <input type="hidden" name="password" value="''' + html.escape(password) + '''">
                
                <label>School Year:</label>
                <select name="db_name" required>
                    <option value="">-- Select --</option>''')
    
    for db in valid_dbs:
        selected = ' selected' if db == db_name else ''
        print(f'                    <option value="{db}"{selected}>{db}</option>')
    
    print('''
                </select>
                
                <button type="submit" class="btn-primary">Continue</button>
            </form>
        </div>''')

print('''
    </div>

    <div class="welcome-panel">
        <h2>Welcome to Student System</h2>
        <p>Please login to continue.</p>''')

if error_msg:
    print('''
        <div class="error-box">
            <div class="error-header">
                <div class="error-title">ERROR</div>
                <div class="error-close" onclick="this.parentElement.parentElement.style.display='none';">CLOSE ×</div>
            </div>
            <div class="error-body">
                <span class="error-icon">×</span>
                <span>Sorry, unrecognized username or password.</span>
            </div>
        </div>''')

print('''    </div>
</div>
</body>
</html>''')
