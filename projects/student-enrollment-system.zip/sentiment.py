#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
import json
import warnings
import re
import html
import cgi
import mysql.connector
from datetime import datetime, timedelta

# ===== CRITICAL: Set UTF-8 encoding for Windows IIS =====
if sys.version_info[0] >= 3:
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Silence output before headers
class _NullWriter:
    def write(self, *_args, **_kwargs): pass
    def flush(self): pass

_ORIG_STDOUT = sys.stdout
_ORIG_STDERR = sys.stderr
sys.stdout = _NullWriter()
sys.stderr = _NullWriter()

warnings.filterwarnings("ignore")

# Cache directory
CACHE_DIR = r"C:\inetpub\wwwroot\hf_cache"
os.makedirs(CACHE_DIR, exist_ok=True)

os.environ["HF_HOME"] = CACHE_DIR
os.environ["HF_HUB_CACHE"] = os.path.join(CACHE_DIR, "hub")
os.environ["TRANSFORMERS_CACHE"] = os.path.join(CACHE_DIR, "transformers")
os.environ["XDG_CACHE_HOME"] = CACHE_DIR
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
os.environ["TRANSFORMERS_VERBOSITY"] = "error"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["TQDM_DISABLE"] = "1"

# Restore stdout/stderr
sys.stdout = _ORIG_STDOUT
sys.stderr = _ORIG_STDERR

# ================= COOKIE FUNCTION =================
def get_cookie_value(cookie_name):
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith(cookie_name + '='):
                return cookie.split('=', 1)[1]
    return ""

# ================= GET PARAMETERS =================
form = cgi.FieldStorage()
db_name = form.getfirst("db", "").strip()
if not db_name:
    db_name = get_cookie_value('enrolled_db')
subjid_param = form.getfirst("subjid", "").strip()
sentiment_filter = form.getfirst("sentiment", "ALL").upper()
category_filter = form.getfirst("category", "ALL").upper()

VALID_DATABASES = ["1stsy_2026_2027", "2ndsem_sy2026_2027", "summersy_2026_2027"]
if not db_name or db_name not in VALID_DATABASES:
    print("Content-Type: text/html; charset=utf-8\n")
    print("<h2>Error: Invalid database.</h2>")
    sys.exit()

if not subjid_param or not subjid_param.isdigit():
    print("Content-Type: text/html; charset=utf-8\n")
    print("<h2>Error: Missing subject ID.</h2>")
    sys.exit()

subjid_int = int(subjid_param)

# ================= CHECK CACHE FIRST =================
evaluations_data = []
needs_processing = False
evaluations = []

try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database=db_name,
        charset='utf8mb4',
        use_unicode=True
    )
    cur = conn.cursor()
    
    # Create cache table if not exists
    cur.execute("""
    CREATE TABLE IF NOT EXISTS sentiment_cache (
        cache_id INT AUTO_INCREMENT PRIMARY KEY,
        studid INT,
        subjid INT,
        clause TEXT,
        sentiment VARCHAR(20),
        categories TEXT,
        full_evaluation TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_subjid (subjid),
        INDEX idx_created (created_at)
    )
    """)
    conn.commit()
    
    # Check for cached results (last 24 hours)
    cur.execute("""
    SELECT cache_id, studid, subjid, clause, sentiment, categories, full_evaluation
    FROM sentiment_cache
    WHERE subjid = %s AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ORDER BY studid DESC, cache_id
    """, (subjid_int,))
    
    cached_results = cur.fetchall()
    
    if cached_results:
        # Use cached results (FAST - < 1 second!)
        for row in cached_results:
            cache_id, studid, subjid, clause, sentiment, categories, full_eval = row
            if sentiment_filter != 'ALL' and sentiment != sentiment_filter:
                continue
            if category_filter != 'ALL' and category_filter not in categories.upper():
                continue
            evaluations_data.append({
                'studid': studid,
                'subjid': subjid,
                'clause': clause,
                'sentiment': sentiment,
                'categories': categories.split(',') if categories else ['General'],
                'full_evaluation': full_eval
            })
        needs_processing = False
    else:
        # No cache - need to process with AI
        needs_processing = True
        
        # Fetch evaluations ordered by highest studid first
        cur.execute("""
        SELECT e.studid, e.eid, e.evaluation
        FROM enroll e
        WHERE e.subjid = %s AND e.evaluation IS NOT NULL AND e.evaluation != ''
        ORDER BY e.studid DESC
        """, (subjid_int,))
        
        evaluations = cur.fetchall()
        
        if not evaluations:
            needs_processing = False
    
    cur.close()
    conn.close()
    
except Exception as e:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<h2>Database Error:</h2><pre>{html.escape(str(e))}</pre>")
    sys.exit()

# ================= PROCESS AI IF NEEDED =================
if needs_processing and evaluations:
    # Suppress output during model loading
    sys.stdout = _NullWriter()
    sys.stderr = _NullWriter()
    
    try:
        from transformers import pipeline
        
        # MULTILINGUAL SENTIMENT MODEL
        sentiment_pipeline = pipeline(
            "sentiment-analysis",
            model="lxyuan/distilbert-base-multilingual-cased-sentiments-student",
            cache_dir=CACHE_DIR,
            device=-1
        )
        
        # ZERO-SHOT CLASSIFICATION FOR CATEGORIES
        zero_shot_pipeline = pipeline(
            "zero-shot-classification",
            model="facebook/bart-large-mnli",
            cache_dir=CACHE_DIR,
            device=-1
        )
        
    except Exception as e:
        sentiment_pipeline = None
        zero_shot_pipeline = None
    finally:
        sys.stdout = _ORIG_STDOUT
        sys.stderr = _ORIG_STDERR
    
    # CLAUSE SPLITTING PATTERNS
    CONTRAST_CONJUNCTIONS = [
        r'\s+but\s+', r'\s+however\s+', r'\s+although\s+',
        r'\s+though\s+', r'\s+yet\s+', r'\s+nevertheless\s+',
        r'\s+nonetheless\s+', r'\s+whereas\s+', r'\s+while\s+',
        r'\s+despite\s+', r'\s+in spite of\s+', r';\s+', r'\.\s+'
    ]
    
    def split_into_clauses(text):
        if not text:
            return []
        
        clauses = [text]
        
        for pattern in CONTRAST_CONJUNCTIONS:
            new_clauses = []
            for clause in clauses:
                parts = re.split(pattern, clause, flags=re.IGNORECASE)
                if len(parts) > 1:
                    for i, part in enumerate(parts):
                        part = part.strip()
                        if part:
                            if i > 0:
                                match = re.search(pattern, clause, flags=re.IGNORECASE)
                                if match:
                                    conj = match.group().strip()
                                    part = conj + " " + part
                            new_clauses.append(part)
                else:
                    if clause.strip():
                        new_clauses.append(clause)
            clauses = new_clauses
        
        return [c.strip() for c in clauses if c.strip() and len(c.strip()) > 10] if clauses else [text]
    
    def clean_clause(clause):
        """Remove leading conjunctions and trailing punctuation"""
        if not clause:
            return clause
        
        # Remove leading conjunctions
        clause = re.sub(r'^(but|however|although|though|yet|nevertheless|nonetheless|whereas|while|despite|in spite of)\s+', '', clause, flags=re.IGNORECASE)
        
        # Remove leading punctuation and spaces
        clause = re.sub(r'^[\s\.\,\;\:]+', '', clause)
        
        # Capitalize first letter
        clause = clause.strip()
        if clause:
            clause = clause[0].upper() + clause[1:]
        
        # Remove trailing comma
        clause = re.sub(r',\s*$', '', clause)
        
        return clause.strip()
    
    def analyze_sentiment(text):
        """AI sentiment - NO NEUTRAL, force POSITIVE or NEGATIVE"""
        if sentiment_pipeline is None:
            return 'POSITIVE'
        try:
            result = sentiment_pipeline(text[:512])[0]
            label = result['label'].upper()
            score = result['score']
            
            # NO NEUTRAL - force binary classification
            if label in ['POSITIVE', 'POS', '3 stars', '4 stars', '5 stars']:
                # Check confidence - if low, verify with context
                if score < 0.7:
                    # Low confidence - check for improvement/need indicators
                    text_lower = text.lower()
                    need_words = ['needed', 'needs', 'need', 'require', 'requires', 'should', 'could', 'would', 'improve', 'improvement', 'lack', 'lacking', 'insufficient']
                    if any(word in text_lower for word in need_words):
                        return 'NEGATIVE'
                return 'POSITIVE'
            elif label in ['NEGATIVE', 'NEG', '1 star', '2 stars']:
                return 'NEGATIVE'
            else:
                # For NEUTRAL labels from model
                text_lower = text.lower()
                need_words = ['needed', 'needs', 'need', 'require', 'requires', 'should', 'could', 'would', 'improve', 'improvement', 'lack', 'lacking', 'insufficient', 'outdated', 'overcrowded', 'limited', 'unclear', 'poor']
                if any(word in text_lower for word in need_words):
                    return 'NEGATIVE'
                return 'POSITIVE'
        except:
            return 'POSITIVE'
    
    def categorize_text(text):
        """AI categorization using Zero-Shot - NO STRING SEARCH"""
        if zero_shot_pipeline is None:
            return ['General']
        try:
            result = zero_shot_pipeline(
                text[:512],
                candidate_labels=["Laboratory", "Facility", "Instruction", 
                                 "Curriculum", "Assessment", "Management"],
                multi_label=True,
                hypothesis_template="This text is about {}."
            )
            
            # Get categories sorted by confidence score (matches professor's pattern)
            categories = []
            labeled_scores = list(zip(result['labels'], result['scores']))
            labeled_scores.sort(key=lambda x: x[1], reverse=True)
            
            # Dynamic threshold - take top categories above 0.35 confidence
            # but limit to max 4 categories (matches professor's output)
            for label, score in labeled_scores[:4]:  # Max 4 categories
                if score > 0.35:  # Lowered threshold to capture more relevant tags
                    categories.append(label)
            
            return categories if categories else ['General']
        except:
            return ['General']
    
    # PROCESS AND CACHE EVALUATIONS
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database=db_name,
        charset='utf8mb4',
        use_unicode=True
    )
    cur = conn.cursor()
    
    # Track previous full evaluation for "(same as above)"
    prev_full_eval = None
    
    for studid, eid, full_text in evaluations:
        if not full_text or not full_text.strip():
            continue
        
        clauses = split_into_clauses(full_text)
        
        for clause in clauses:
            # Clean the clause
            cleaned_clause = clean_clause(clause)
            
            # AI analyzes sentiment (NO NEUTRAL)
            sentiment = analyze_sentiment(cleaned_clause)
            
            # AI categorizes (ZERO-SHOT)
            categories = categorize_text(cleaned_clause)
            
            # Apply filters
            if sentiment_filter != 'ALL' and sentiment != sentiment_filter:
                continue
            if category_filter != 'ALL' and category_filter not in [c.upper() for c in categories]:
                continue
            
            # Check if full evaluation is same as previous
            display_full_eval = full_text
            if prev_full_eval == full_text:
                display_full_eval = "(same as above)"
            prev_full_eval = full_text
            
            evaluations_data.append({
                'studid': studid,
                'subjid': subjid_int,
                'clause': cleaned_clause,
                'sentiment': sentiment,
                'categories': categories,
                'full_evaluation': display_full_eval
            })
            
            # Cache to database (store original full text)
            try:
                cur.execute("""
                INSERT INTO sentiment_cache (studid, subjid, clause, sentiment, categories, full_evaluation)
                VALUES (%s, %s, %s, %s, %s, %s)
                """, (studid, subjid_int, cleaned_clause, sentiment, ','.join(categories), full_text))
            except:
                pass
    
    conn.commit()
    cur.close()
    conn.close()

# ================= RENDER PAGE =================
print("Content-Type: text/html; charset=utf-8\n")
print(f'''<!DOCTYPE html>
<html>
<head>
    <title>Student Evaluation Analysis - Subject {subjid_param}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Georgia', serif; background: #f8f9fa; }}
        
        .header {{
            background: linear-gradient(135deg, #00356B 0%, #00274C 100%);
            color: white;
            padding: 20px 40px;
            display: flex;
            align-items: center;
            gap: 20px;
        }}
        .logo {{
            width: 60px;
            height: 60px;
            background: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid #FFD700;
        }}
        .logo img {{
            width: 100%;
            height: 100%;
            object-fit: contain;
            border-radius: 4px;
        }}
        .header-text h1 {{
            font-size: 28px;
            margin: 0;
            letter-spacing: 0.5px;
        }}
        .header-text p {{
            font-size: 16px;
            opacity: 0.9;
        }}
        
        .main-content {{
            padding: 40px;
            max-width: 1400px;
            margin: 0 auto;
        }}
        
        .page-title {{
            color: #00356B;
            font-size: 32px;
            margin-bottom: 30px;
        }}
        
        .filter-section {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }}
        
        .filter-group {{
            display: inline-block;
            margin-right: 20px;
            margin-bottom: 10px;
        }}
        
        .filter-group label {{
            font-weight: bold;
            color: #00356B;
            margin-right: 10px;
        }}
        
        .filter-group select {{
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 14px;
        }}
        
        .apply-btn {{
            background: #00356B;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }}
        
        .apply-btn:hover {{
            background: #00274C;
        }}
        
        .subject-info {{
            color: #6c757d;
            margin-bottom: 20px;
            font-style: italic;
        }}
        
        .results-table {{
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }}
        
        .results-table th, .results-table td {{
            border: 1px solid #dee2e6;
            padding: 12px;
            text-align: left;
            vertical-align: top;
        }}
        
        .results-table th {{
            background: #00356B;
            color: white;
            font-weight: bold;
            position: sticky;
            top: 0;
        }}
        
        .results-table tr:nth-child(even) {{
            background: #f8f9fa;
        }}
        
        .results-table tr:hover {{
            background: #e9ecef;
        }}
        
        .sentiment-badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }}
        
        .sentiment-positive {{
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }}
        
        .sentiment-negative {{
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }}
        
        .category-tags {{
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
        }}
        
        .category-tag {{
            background: #e9ecef;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 11px;
            color: #495057;
        }}
        
        .clause-text {{
            font-style: italic;
            color: #495057;
            line-height: 1.5;
        }}
        
        .full-eval {{
            color: #6c757d;
            font-size: 13px;
            max-width: 400px;
            word-wrap: break-word;
        }}
        
        .no-results {{
            text-align: center;
            padding: 40px;
            color: #6c757d;
            font-size: 16px;
        }}
        
        .cache-notice {{
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
            padding: 10px 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 13px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg" alt="Yale University Logo">
        </div>
        <div class="header-text">
            <h1>STUDENT INFORMATION SYSTEM</h1>
            <p>UNIVERSITY NAME</p>
        </div>
    </div>
    
    <div class="main-content">
        <h1 class="page-title">Student Evaluation</h1>
        
        {'''<div class="cache-notice">Analysis cached for 24 hours. Next load will be instant!</div>''' if needs_processing and evaluations_data else ''}
        
        <div class="filter-section">
            <form method="get">
                <input type="hidden" name="db" value="{html.escape(db_name)}">
                <input type="hidden" name="subjid" value="{subjid_param}">
                
                <div class="filter-group">
                    <label>Filter by Sentiment:</label>
                    <select name="sentiment" onchange="this.form.submit()">
                        <option value="ALL" {'selected' if sentiment_filter == 'ALL' else ''}>All</option>
                        <option value="POSITIVE" {'selected' if sentiment_filter == 'POSITIVE' else ''}>Positive</option>
                        <option value="NEGATIVE" {'selected' if sentiment_filter == 'NEGATIVE' else ''}>Negative</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Filter by Category:</label>
                    <select name="category" onchange="this.form.submit()">
                        <option value="ALL" {'selected' if category_filter == 'ALL' else ''}>All</option>
                        <option value="LABORATORY" {'selected' if category_filter == 'LABORATORY' else ''}>Laboratory</option>
                        <option value="FACILITY" {'selected' if category_filter == 'FACILITY' else ''}>Facility</option>
                        <option value="INSTRUCTION" {'selected' if category_filter == 'INSTRUCTION' else ''}>Instruction</option>
                        <option value="CURRICULUM" {'selected' if category_filter == 'CURRICULUM' else ''}>Curriculum</option>
                        <option value="ASSESSMENT" {'selected' if category_filter == 'ASSESSMENT' else ''}>Assessment</option>
                        <option value="MANAGEMENT" {'selected' if category_filter == 'MANAGEMENT' else ''}>Management</option>
                    </select>
                </div>
                
                <button type="submit" class="apply-btn">Apply</button>
            </form>
        </div>
        
        <div class="subject-info">
            Subject filter: {subjid_param}
        </div>
        
        {'''<div class="no-results">No evaluations found for this subject.</div>''' if not evaluations_data else f'''
        <table class="results-table">
            <thead>
                <tr>
                    <th width="70">StudID</th>
                    <th width="70">SubjID</th>
                    <th>Clause</th>
                    <th width="120">Sentiment</th>
                    <th width="250">Category</th>
                    <th>Full Evaluation</th>
                </tr>
            </thead>
            <tbody>
        '''}
        
        {"".join(f"""
        <tr>
            <td>{html.escape(str(e['studid']))}</td>
            <td>{html.escape(str(e['subjid']))}</td>
            <td class="clause-text">{html.escape(e['clause'])}</td>
            <td><span class="sentiment-badge sentiment-{e['sentiment'].lower()}">{e['sentiment']}</span></td>
            <td><div class="category-tags">{"".join(f'<span class="category-tag">{html.escape(cat)}</span>' for cat in e['categories'])}</div></td>
            <td class="full-eval">{html.escape(e['full_evaluation'])}</td>
        </tr>
        """ for e in evaluations_data) if evaluations_data else ''}
        
        {'''
            </tbody>
        </table>''' if evaluations_data else ''}
    </div>
</body>
</html>''')
