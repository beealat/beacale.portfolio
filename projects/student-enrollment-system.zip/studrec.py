#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import re
import cgi
import mysql.connector
import html
import io
import base64
from datetime import datetime
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, Image, PageBreak
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, cm
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
# ================= COOKIE FUNCTION =================
def get_cookie_value(cookie_name):
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith(cookie_name + '='):
                return cookie.split('=', 1)[1]
    return ""

# ================= GET PARAMETERS =================
form = cgi.FieldStorage()
db_name = form.getfirst("db", "").strip()
chat_msg = form.getfirst("chat_msg", "").strip()
if not db_name:
    db_name = get_cookie_value('enrolled_db')
db_user = get_cookie_value('db_user')
studid_param = ""

# === NEW: Get user grants using SHOW GRANTS ===
user_grants_info = ""
try:
    if db_user:
        conn_grants = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root"
        )
        cur_grants = conn_grants.cursor()
        try:
            cur_grants.execute(f"SHOW GRANTS FOR '{db_user}'@'localhost'")
            grants = cur_grants.fetchall()
            if grants:
                user_grants_info = f""
        except mysql.connector.Error:
            user_grants_info = "User Privileges: Not configured"
        cur_grants.close()
        conn_grants.close()
except mysql.connector.Error:
    pass
# === END NEW CODE ===

# Allow admin to view any student via URL param ?studid=
studid_url = form.getfirst("studid", "").strip()
if studid_url and studid_url.isdigit():
    studid_param = studid_url
elif db_user:
    match = re.match(r'^(\d+)', db_user)
    if match:
        studid_param = match.group(1)

# ================= CHAT API HANDLER =================
import json as _json
if chat_msg and studid_param and db_name:
    try:
        from openai import OpenAI
        conn_chat = mysql.connector.connect(
            host="localhost", user="root", password="root",
            database=db_name, charset='utf8mb4', use_unicode=True
        )
        cur_chat = conn_chat.cursor()
        cur_chat.execute("SELECT studid,studname,studadd,studcrs,studgender,yrlvl FROM students WHERE studid=%s", (int(studid_param),))
        stu = cur_chat.fetchone()
        cur_chat.execute("""
            SELECT s.subjid,s.subjcode,s.subjdesc,s.subjunits,s.subjsched,
                   g.prelim,g.midterm,g.prefinal,g.final,t.tname
            FROM enroll e
            JOIN subjects s ON e.subjid=s.subjid
            LEFT JOIN grades g ON e.eid=g.enroll_eid
            LEFT JOIN assign a ON s.subjid=a.SubjID
            LEFT JOIN teachers t ON a.TID=t.tid
            WHERE e.studid=%s ORDER BY s.subjid
        """, (int(studid_param),))
        chat_enrollments = cur_chat.fetchall()
        cur_chat.execute("SELECT subjid,subjcode,subjdesc,subjunits,subjsched FROM subjects ORDER BY subjid")
        chat_all_subj = cur_chat.fetchall()
        cur_chat.execute("""
            SELECT st.studid,st.studname,s.subjcode,s.subjdesc
            FROM students st JOIN enroll e ON st.studid=e.studid
            JOIN subjects s ON e.subjid=s.subjid
            WHERE st.studcrs=%s AND st.yrlvl=%s AND st.studid!=%s
        """, (stu[3] if stu else "", stu[5] if stu else "", int(studid_param)))
        chat_others = cur_chat.fetchall()
        cur_chat.close(); conn_chat.close()

        context = {
            "student": {"id": stu[0] if stu else "", "name": stu[1] if stu else "", "address": stu[2] if stu else "",
                        "course": stu[3] if stu else "", "gender": stu[4] if stu else "",
                        "year": stu[5] if stu else "", "school_year": db_name},
            "enrollments": [{"subjid":r[0],"code":r[1],"desc":r[2],"units":r[3],"sched":r[4],
                              "prelim":r[5],"midterm":r[6],"prefinal":r[7],"final":r[8],"teacher":r[9]}
                             for r in chat_enrollments],
            "all_subjects": [{"id":s[0],"code":s[1],"desc":s[2],"units":s[3],"sched":s[4]} for s in chat_all_subj],
            "other_students": [{"id":r[0],"name":r[1],"subjcode":r[2],"subjdesc":r[3]} for r in chat_others]
        }

        client = OpenAI(api_key="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")
        system_prompt = f"""You are an enrollment assistant for a student information system.
You have access to the following student data:
{_json.dumps(context, default=str)}

Answer questions about:
- The student's profile (name, course, year, gender, address)
- Their enrolled subjects (codes, descriptions, units, schedules)
- Their grades (prelim, midterm, prefinal, final) - if not yet available say 'not yet available'
- Who teaches each subject
- Other students with similar course/year and what subjects they take
- General subject information from all_subjects

Rules:
- Be concise and direct
- If asked about a subject not in enrollments, check all_subjects
- If multiple subjects match a keyword, list them and ask which one
- Always refer to the student by name when appropriate"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "system", "content": system_prompt},
                      {"role": "user", "content": chat_msg}],
            max_tokens=500
        )
        reply = response.choices[0].message.content
    except Exception as e:
        reply = f"Sorry, I encountered an error: {str(e)}"

    _resp = "Content-Type: application/json\r\n\r\n" + _json.dumps({"reply": reply})
    sys.stdout.flush()
    sys.stdout.buffer.write(_resp.encode('utf-8'))
    sys.stdout.buffer.flush()
    sys.exit()
# ================= END CHAT HANDLER =================

if not db_name or not studid_param or not studid_param.isdigit():
    sys.stdout.flush()
    sys.stdout.buffer.write(b"Content-Type: text/html; charset=utf-8\r\n\r\n<h2>Error: Missing database or student ID.</h2>")
    sys.stdout.buffer.flush()
    sys.exit()

studid_int = int(studid_param)

# ================= DATABASE =================
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database=db_name,
        charset='utf8mb4',
        use_unicode=True
    )
    cur = conn.cursor()
    
    # Get student info
    cur.execute("""
    SELECT studname, studcrs, yrlvl
    FROM students
    WHERE studid = %s
    """, (studid_int,))
    student = cur.fetchone()
    
    if not student:
        name = course = year = ""
        enrollments = []
        student_exists = False
    else:
        name, course, year = student
        student_exists = True
    
    cur.execute("""
    SELECT 
        s.subjid, s.subjcode,
        g.prelim, g.midterm, g.prefinal, g.final
    FROM enroll e
    JOIN subjects s ON e.subjid = s.subjid
    LEFT JOIN grades g ON e.eid = g.enroll_eid
    WHERE e.studid = %s
    ORDER BY s.subjid
    """, (studid_int,))
    enrollments = cur.fetchall()
    
    cur.close()
    conn.close()
except Exception as e:
    _emsg = f"Content-Type: text/html; charset=utf-8\r\n\r\n<h2>Database Error:</h2><pre>{html.escape(str(e))}</pre>"
    sys.stdout.flush()
    sys.stdout.buffer.write(_emsg.encode('utf-8'))
    sys.stdout.buffer.flush()
    sys.exit()

num_subjects = len(enrollments) if enrollments else 0

# ================= PDF OUTPUT WITH ENHANCED YALE DESIGN =================
# Yale brand colors
YALE_BLUE = colors.HexColor("#00356B")
YALE_BLUE_LIGHT = colors.HexColor("#0F4D92")
YALE_GREY = colors.HexColor("#F9F9F9")
YALE_GOLD = colors.HexColor("#F0AB00")

# Create a Yale shield/logo as vector graphics
def draw_yale_shield(canvas, x, y, size=40):
    """Draw a simplified Yale shield"""
    canvas.saveState()
    # Shield shape
    p = canvas.beginPath()
    p.moveTo(x, y + size)
    p.lineTo(x + size/2, y + size * 1.2)
    p.lineTo(x + size, y + size)
    p.lineTo(x + size, y)
    p.lineTo(x, y)
    p.close()
    # Fill shield with Yale blue
    canvas.setFillColor(YALE_BLUE)
    canvas.setStrokeColor(YALE_BLUE_LIGHT)
    canvas.setLineWidth(1.5)
    canvas.drawPath(p, fill=True, stroke=True)
    # Add open book (simplified)
    canvas.setFillColor(colors.white)
    canvas.setStrokeColor(colors.white)
    # Book pages
    book_y = y + size * 0.3
    canvas.rect(x + size * 0.3, book_y, size * 0.4, size * 0.25, fill=True, stroke=False)
    canvas.rect(x + size * 0.35, book_y - 2, size * 0.3, size * 0.15, fill=True, stroke=False)
    # Hebrew letters "Urim V'Tumim" (simplified)
    canvas.setFillColor(YALE_GOLD)
    canvas.setFont("Helvetica-Bold", size * 0.15)
    canvas.drawCentredString(x + size/2, y + size * 0.45, "\u05d0\u05d5\u05e8")
    canvas.restoreState()

# Custom page template with enhanced borders and logo
class YaleCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
    
    def showPage(self):
        self.saveState()
        # Top border with Yale blue gradient effect
        self.setFillColor(YALE_BLUE)
        self.rect(0, A4[1] - 15, A4[0], 15, fill=True, stroke=False)
        # Add gold accent line
        self.setStrokeColor(YALE_GOLD)
        self.setLineWidth(2)
        self.line(0, A4[1] - 15, A4[0], A4[1] - 15)
        # Bottom border with Yale blue
        self.setFillColor(YALE_BLUE)
        self.rect(0, 0, A4[0], 10, fill=True, stroke=False)
        # Add gold accent line
        self.setStrokeColor(YALE_GOLD)
        self.setLineWidth(2)
        self.line(0, 10, A4[0], 10)
        # Side borders - subtle
        self.setStrokeColor(YALE_BLUE_LIGHT)
        self.setLineWidth(0.5)
        self.setDash(1, 2)
        self.line(30, 0, 30, A4[1])
        self.line(A4[0] - 30, 0, A4[0] - 30, A4[1])
        self.setDash()
        # Draw Yale shields in corners
        draw_yale_shield(self, 50, A4[1] - 65, 20)
        draw_yale_shield(self, A4[0] - 70, A4[1] - 65, 20)
        # Watermark
        self.setFont("Helvetica-Bold", 90)
        self.setFillColor(YALE_BLUE)
        self.setFillAlpha(0.03)
        self.translate(A4[0]/2, A4[1]/2)
        self.rotate(45)
        self.drawCentredString(0, 0, "YALE")
        self.setFillAlpha(1)
        self.restoreState()
        canvas.Canvas.showPage(self)

buffer = io.BytesIO()
doc = SimpleDocTemplate(buffer, pagesize=A4,
                        topMargin=70, bottomMargin=50,
                        leftMargin=50, rightMargin=50)
elements = []

# Custom styles
styles = getSampleStyleSheet()

# University header style with Yale shield
university_style = ParagraphStyle(
    'UniversityName',
    parent=styles['Heading1'],
    fontSize=32,
    textColor=YALE_BLUE,
    alignment=TA_CENTER,
    spaceAfter=2,
    fontName='Helvetica-Bold',
    leading=36
)

# Subtitle style
subtitle_style = ParagraphStyle(
    'Subtitle',
    parent=styles['Normal'],
    fontSize=14,
    textColor=YALE_BLUE_LIGHT,
    alignment=TA_CENTER,
    fontName='Helvetica',
    spaceAfter=5
)

# Registrar office style
registrar_style = ParagraphStyle(
    'RegistrarOffice',
    parent=styles['Normal'],
    fontSize=16,
    textColor=YALE_GOLD,
    alignment=TA_CENTER,
    fontName='Helvetica-Bold',
    spaceAfter=25
)

# Section header style
section_style = ParagraphStyle(
    'SectionHeader',
    parent=styles['Heading2'],
    fontSize=14,
    textColor=YALE_BLUE,
    fontName='Helvetica-Bold',
    spaceAfter=10,
    spaceBefore=20
)

# ================= CREATE PDF CONTENT =================
# Header with Yale logo beside university name
elements.append(Spacer(1, 20))

# Try to load Yale logo image, otherwise use placeholder
try:
    # Yale logo URL (replace with your actual logo path or URL)
    logo_url = "https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg"
    # Create logo images
    logo_left = Image(logo_url, width=0.7*inch, height=0.7*inch)
    logo_right = Image(logo_url, width=0.7*inch, height=0.7*inch)
    # Create header table with logos on both sides
    header_data = [[
        logo_left,
        Paragraph("<b>YALE UNIVERSITY</b><br/><font size=12>Founded 1701</font>",
                  ParagraphStyle('HeaderStyle', parent=styles['Normal'],
                                 fontSize=28, textColor=YALE_BLUE,
                                 fontName='Helvetica-Bold', alignment=TA_CENTER, leading=32)),
        logo_right
    ]]
    header_table = Table(header_data, colWidths=[1*inch, 5*inch, 1*inch])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (0,0), (0,0), 'RIGHT'),
        ('ALIGN', (1,0), (1,0), 'CENTER'),
        ('ALIGN', (2,0), (2,0), 'LEFT'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
    ]))
    elements.append(header_table)
    use_logo = True
except Exception as e:
    # Fallback: if logo can't be loaded, use placeholder boxes
    header_data = [[
        Paragraph("[LOGO]", ParagraphStyle('LogoStyle', parent=styles['Normal'],
                                           fontSize=9, alignment=TA_CENTER, textColor=YALE_BLUE)),
        Paragraph("<b>YALE UNIVERSITY</b><br/><font size=12>Founded 1701</font>",
                  ParagraphStyle('HeaderStyle', parent=styles['Normal'],
                                 fontSize=28, textColor=YALE_BLUE,
                                 fontName='Helvetica-Bold', alignment=TA_CENTER, leading=32)),
        Paragraph("[LOGO]", ParagraphStyle('LogoStyle', parent=styles['Normal'],
                                           fontSize=9, alignment=TA_CENTER, textColor=YALE_BLUE))
    ]]
    header_table = Table(header_data, colWidths=[0.8*inch, 5.4*inch, 0.8*inch])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (0,0), (0,0), 'CENTER'),
        ('ALIGN', (1,0), (1,0), 'CENTER'),
        ('ALIGN', (2,0), (2,0), 'CENTER'),
        ('BOX', (0,0), (0,0), 2, YALE_BLUE),
        ('BOX', (2,0), (2,0), 2, YALE_BLUE),
        ('LEFTPADDING', (0,0), (0,0), 8),
        ('RIGHTPADDING', (0,0), (0,0), 8),
        ('TOPPADDING', (0,0), (0,0), 10),
        ('BOTTOMPADDING', (0,0), (0,0), 10),
        ('LEFTPADDING', (2,0), (2,0), 8),
        ('RIGHTPADDING', (2,0), (2,0), 8),
        ('TOPPADDING', (2,0), (2,0), 10),
        ('BOTTOMPADDING', (2,0), (2,0), 10),
    ]))
    elements.append(header_table)
    use_logo = False

elements.append(Spacer(1, 10))
elements.append(Paragraph("Registrar's Office", registrar_style))

# Decorative gold line
hr_gold = HRFlowable(width="30%", thickness=3, color=YALE_GOLD,
                     spaceAfter=25, spaceBefore=5, hAlign='CENTER')
elements.append(hr_gold)

# Add a small spacer after the gold line
elements.append(Spacer(1, 10))

# Check if there are enrollments
if student_exists and enrollments:
    # Student information section
    info_section = Paragraph("STUDENT INFORMATION", section_style)
    elements.append(info_section)
    
    # Student info table with alternating background
    info_data = [
        ["Student ID:", studid_param],
        ["School Year:", db_name],
        ["Student Name:", name],
        ["Student Course:", course if course else "—"],
        ["Student Year:", year if year else "—"],
    ]
    info_table = Table(info_data, colWidths=[2.2*inch, 4.8*inch])
    
    # Create alternating row colors
    info_style_table = TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
        ('FONTNAME', (1,0), (1,-1), 'Helvetica'),
        ('FONTSIZE', (0,0), (-1,-1), 12),
        ('TEXTCOLOR', (0,0), (0,-1), YALE_BLUE),
        ('TEXTCOLOR', (1,0), (1,-1), colors.black),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
    ])
    
    # Add alternating background for rows
    for i in range(len(info_data)):
        if i % 2 == 0:
            info_style_table.add('BACKGROUND', (0,i), (-1,i), YALE_GREY)
    
    info_table.setStyle(info_style_table)
    elements.append(info_table)
    elements.append(Spacer(1, 25))
    
    # Academic Record section
    academic_section = Paragraph("ACADEMIC RECORD", section_style)
    elements.append(academic_section)
    
        # Grades table - MODIFIED: Added clickable SubjID when grades exist
    data = [["Subject ID", "Subj Code", "Prelim", "Midterm", "Prefinal", "Final"]]
    for row in enrollments:
        subjid, code, prelim, midterm, prefinal, final = row
        
        # Check if grades are posted (any grade is not None/empty)
        has_grades = prelim or midterm or prefinal or final

        if has_grades:
            # Create clickable SubjID using Paragraph with link
            link_url = f"http://localhost/evaluate.py?db={db_name}&studid={studid_param}&subjid={subjid}"
            subjid_para = Paragraph(
                f'<a href="{link_url}" color="#0000EE" underline="true">{subjid}</a>',
                ParagraphStyle('LinkStyle', parent=styles['Normal'], fontSize=10)
            )
        else:
            subjid_para = str(subjid)
        
        data.append([
            subjid_para,  # Now with link if grades exist
            code or "—",
            str(prelim) if prelim else "—",
            str(midterm) if midterm else "—",
            str(prefinal) if prefinal else "—",
            str(final) if final else "—"
        ])
    
    # Calculate column widths
    col_widths = [1.2*inch, 1.8*inch, 0.9*inch, 0.9*inch, 0.9*inch, 0.9*inch]
    table = Table(data, colWidths=col_widths, repeatRows=1)
    table.setStyle(TableStyle([
        # Header style
        ('BACKGROUND', (0,0), (-1,0), YALE_BLUE),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 11),
        ('ALIGN', (0,0), (-1,0), 'CENTER'),
        # Grid and borders
        ('GRID', (0,0), (-1,-1), 1, colors.lightgrey),
        ('BOX', (0,0), (-1,-1), 2, YALE_BLUE),
        # Row styling
        ('FONTNAME', (0,1), (-1,-1), 'Helvetica'),
        ('FONTSIZE', (0,1), (-1,-1), 10),
        ('ALIGN', (2,1), (5,-1), 'CENTER'),  # Grade columns centered
        ('ALIGN', (0,1), (1,-1), 'LEFT'),     # ID and Code columns left-aligned
        # Padding
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        # Alternating row colors
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, YALE_GREY]),
    ]))
    elements.append(table)
    elements.append(Spacer(1, 20))
    
    # Simple subject count as text
    count_style = ParagraphStyle(
        'CountStyle',
        parent=styles['Normal'],
        fontSize=11,
        textColor=YALE_BLUE,
        fontName='Helvetica-Bold'
    )
    elements.append(Paragraph(f"Number of Subjects Listed: {num_subjects}", count_style))
else:
    # Add a small spacer before the table
    elements.append(Spacer(1, 10))
    # 3-row table with thinner rows and spacing below header
    no_records_data = [
        ["Student Grade Sheet"],
        [""],
        ["No records found."]
    ]
    no_records_table = Table(no_records_data, colWidths=[7*inch])
    no_records_table.setStyle(TableStyle([
        # First row - Student Grade Sheet (with extra bottom padding)
        ('BACKGROUND', (0,0), (-1,0), YALE_BLUE),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 16),
        ('ALIGN', (0,0), (-1,0), 'CENTER'),
        ('TOPPADDING', (0,0), (-1,0), 6),
        ('BOTTOMPADDING', (0,0), (-1,0), 10),
        # Second row - empty (very thin)
        ('BACKGROUND', (0,1), (-1,1), colors.white),
        ('TOPPADDING', (0,1), (-1,1), 4),
        ('BOTTOMPADDING', (0,1), (-1,1), 4),
        # Third row - No records found (thinner)
        ('FONTNAME', (0,2), (-1,2), 'Helvetica-Bold'),
        ('FONTSIZE', (0,2), (-1,2), 12),
        ('TEXTCOLOR', (0,2), (-1,2), YALE_BLUE),
        ('ALIGN', (0,2), (-1,2), 'CENTER'),
        ('TOPPADDING', (0,2), (-1,2), 8),
        ('BOTTOMPADDING', (0,2), (-1,2), 8),
        # Table borders
        ('BOX', (0,0), (-1,-1), 2, YALE_BLUE),
        ('LINEBELOW', (0,0), (-1,0), 2, YALE_GOLD),
        ('LINEBELOW', (0,1), (-1,1), 1, colors.lightgrey),
    ]))
    elements.append(no_records_table)
    elements.append(Spacer(1, 30))

# SIMPLIFIED FOOTER - Signature line with Registrar centered below
elements.append(Spacer(1, 60))

# Create a table with three columns - empty, signature, empty for proper centering
signature_data = [
    ["", f"{'_' * 30}", ""],
    ["", "Registrar", ""],
]

# === NEW: Add user grants info if available ===
if user_grants_info:
    signature_data.append(["", "", ""])
    signature_data.append(["", Paragraph(f"<font size=8>{user_grants_info}</font>",
                                         ParagraphStyle('GrantsInfo', parent=styles['Normal'],
                                                        fontSize=8, alignment=TA_CENTER,
                                                        textColor=colors.grey)), ""])
# === END NEW CODE ===

signature_table = Table(signature_data, colWidths=[2.5*inch, 2.5*inch, 2.5*inch])
signature_table.setStyle(TableStyle([
    ('ALIGN', (1,0), (1,-1), 'CENTER'),
    ('FONTNAME', (1,1), (1,1), 'Helvetica-Bold'),
    ('FONTSIZE', (1,0), (1,0), 12),
    ('FONTSIZE', (1,1), (1,1), 11),
    ('TOPPADDING', (1,0), (1,0), 10),
    ('TOPPADDING', (1,1), (1,1), 2),
    ('BOTTOMPADDING', (1,1), (1,1), 2),
    ('LEFTPADDING', (1,0), (1,-1), 0),
    ('RIGHTPADDING', (1,0), (1,-1), 0),
]))
elements.append(signature_table)

# Build PDF with custom canvas
doc.build(elements, canvasmaker=YaleCanvas)
pdf_data = buffer.getvalue()
buffer.close()

# ================= HTML OUTPUT WITH CHATBOT =================
import base64 as _b64
import json as _json2
pdf_b64 = _b64.b64encode(pdf_data).decode('utf-8')

# Write HTML as UTF-8 bytes directly - avoids Windows cp1252 issues
_html_out = f"""Content-Type: text/html; charset=utf-8\r\n\r\n<!DOCTYPE html>
<html>
<head>
<title>Student Record</title>
<style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family: Georgia, serif; background: #525659; height: 100vh; overflow: hidden; }}
.wrapper {{ display: flex; height: 100vh; }}
.pdf-side {{ flex: 1; overflow: auto; }}
.pdf-side iframe {{ width: 100%; height: 100%; border: none; }}
/* === FLOATING CHAT BUTTON === */
.chat-fab {{
    position: fixed; bottom: 28px; right: 28px;
    width: 60px; height: 60px; border-radius: 50%;
    background: linear-gradient(135deg, #1a73e8, #0d47a1);
    color: white; border: none; cursor: pointer;
    font-size: 26px; box-shadow: 0 4px 18px rgba(26,115,232,0.5);
    display: flex; align-items: center; justify-content: center;
    z-index: 1000; transition: transform 0.2s, box-shadow 0.2s;
}}
.chat-fab:hover {{
    transform: scale(1.1);
    box-shadow: 0 6px 24px rgba(26,115,232,0.7);
}}
.chat-fab .fab-badge {{
    position: absolute; top: -2px; right: -2px;
    width: 18px; height: 18px; background: #F0AB00;
    border-radius: 50%; font-size: 10px; font-weight: bold;
    color: #00356B; display: flex; align-items: center; justify-content: center;
}}
/* === CHAT POPUP === */
.chat-popup {{
    position: fixed; bottom: 100px; right: 28px;
    width: 340px; height: 500px;
    background: white; border-radius: 16px;
    box-shadow: 0 8px 40px rgba(0,0,0,0.22);
    display: none; flex-direction: column;
    z-index: 999; overflow: hidden;
    animation: popIn 0.25s ease;
}}
.chat-popup.open {{ display: flex; }}
@keyframes popIn {{
    from {{ opacity:0; transform: translateY(20px) scale(0.95); }}
    to   {{ opacity:1; transform: translateY(0) scale(1); }}
}}
.chat-header {{
    background: linear-gradient(135deg, #1a73e8, #0d47a1);
    color: white; padding: 12px 14px;
    display: flex; align-items: center; gap: 10px;
    flex-shrink: 0;
}}
.chat-avatar {{
    width: 36px; height: 36px; background: rgba(255,255,255,0.2);
    border-radius: 50%; display: flex; align-items: center;
    justify-content: center; font-size: 18px; flex-shrink: 0;
}}
.chat-header-info h4 {{ font-size: 13px; font-weight: bold; margin:0; }}
.chat-header-info p {{ font-size: 10px; opacity: 0.85; margin:0; }}
.chat-close {{
    margin-left: auto; cursor: pointer; font-size: 20px;
    background: none; border: none; color: white; opacity: 0.85; line-height:1;
}}
.quick-btns {{
    padding: 8px 10px; display: flex; flex-wrap: wrap; gap: 5px;
    border-bottom: 1px solid #eee; background: #fafafa; flex-shrink: 0;
}}
.quick-btn {{
    background: white; border: 1.5px solid #1a73e8; color: #1a73e8;
    padding: 4px 9px; border-radius: 12px; font-size: 11px;
    cursor: pointer; transition: all 0.2s; font-family: Georgia, serif;
}}
.quick-btn:hover {{ background: #1a73e8; color: white; }}
.chat-messages {{
    flex: 1; overflow-y: auto; padding: 12px;
    display: flex; flex-direction: column; gap: 10px;
}}
.msg {{ display: flex; gap: 7px; align-items: flex-end; }}
.msg.user {{ flex-direction: row-reverse; }}
.msg-av {{
    width: 26px; height: 26px; border-radius: 50%;
    background: #1a73e8; display: flex; align-items: center;
    justify-content: center; font-size: 13px; flex-shrink: 0;
}}
.msg.user .msg-av {{ background: #00356B; }}
.bubble {{
    max-width: 80%; padding: 8px 11px; border-radius: 14px;
    font-size: 12px; line-height: 1.45; font-family: Arial, sans-serif;
}}
.msg.bot .bubble {{ background: #f1f3f4; color: #333; border-bottom-left-radius: 3px; }}
.msg.user .bubble {{ background: #1a73e8; color: white; border-bottom-right-radius: 3px; }}
.chat-input-area {{ padding: 10px; border-top: 1px solid #eee; background: white; flex-shrink: 0; }}
.input-row {{ display: flex; gap: 6px; }}
.chat-input {{
    flex: 1; padding: 8px 12px; border: 1px solid #ddd;
    border-radius: 20px; font-size: 12px; outline: none; font-family: Arial, sans-serif;
}}
.chat-input:focus {{ border-color: #1a73e8; }}
.send-btn {{
    background: #1a73e8; color: white; border: none;
    padding: 8px 14px; border-radius: 20px; cursor: pointer; font-size: 12px; font-weight: bold;
}}
.send-btn:hover {{ background: #1557b0; }}
.chat-footer {{ text-align:center; font-size:10px; color:#999; padding:4px 10px 8px; flex-shrink:0; }}
.typing-dots {{ display:flex; gap:4px; padding:4px 0; }}
.typing-dots span {{
    width:7px; height:7px; background:#aaa; border-radius:50%; animation: bop 1s infinite;
}}
.typing-dots span:nth-child(2) {{ animation-delay:0.15s; }}
.typing-dots span:nth-child(3) {{ animation-delay:0.3s; }}
@keyframes bop {{
    0%,60%,100% {{ transform:translateY(0); }}
    30% {{ transform:translateY(-6px); }}
}}
</style>
</head>
<body>
<div class="wrapper">
    <div class="pdf-side">
        <iframe src="data:application/pdf;base64,{pdf_b64}" type="application/pdf"></iframe>
    </div>
</div>

<!-- Floating Chat Button -->
<button class="chat-fab" id="chatFab" onclick="toggleChat()" title="Open Enrollment Assistant">
    &#x1F916;
    <span class="fab-badge">AI</span>
</button>

<!-- Chat Popup -->
<div class="chat-popup" id="chatPopup">
    <div class="chat-header">
        <div class="chat-avatar">&#x1F916;</div>
        <div class="chat-header-info">
            <h4>Enrollment Assistant</h4>
            <p>Online &middot; Ask about subjects, grades, schedule, and profile</p>
        </div>
        <button class="chat-close" onclick="toggleChat()">&#x2715;</button>
    </div>
    <div class="quick-btns">
        <button class="quick-btn" onclick="quickSend('Who is my teacher?')">Teacher</button>
        <button class="quick-btn" onclick="quickSend('What is my final grade?')">Final grade</button>
        <button class="quick-btn" onclick="quickSend('What subjects am I enrolled in?')">My subjects</button>
        <button class="quick-btn" onclick="quickSend('What is my profile?')">My profile</button>
        <button class="quick-btn" onclick="quickSend('What subjects do other students like me take?')">Other Students Subjects</button>
    </div>
    <div class="chat-messages" id="chatMsgs">
        <div class="msg bot">
            <div class="msg-av">&#x1F916;</div>
            <div class="bubble">
                Hello! I am your enrollment assistant.<br><br>
                You can ask me things like:<br>
                - Who teaches CS101?<br>
                - What is my final grade in CS101?<br>
                - What subjects am I enrolled in?<br>
                - What is my profile?
            </div>
        </div>
    </div>
    <div class="chat-input-area">
        <div class="input-row">
            <input type="text" class="chat-input" id="chatIn"
                   placeholder="Type a message..."
                   onkeydown="if(event.key==='Enter')sendMsg()">
            <button class="send-btn" onclick="sendMsg()">Send</button>
        </div>
    </div>
    <div class="chat-footer">Supports questions about teacher, schedule, units, grades, evaluation, and profile.</div>
</div><script>
const DB = "{html.escape(db_name)}";
function toggleChat() {{
    const popup = document.getElementById('chatPopup');
    popup.classList.toggle('open');
    if(popup.classList.contains('open')) {{
        document.getElementById('chatIn').focus();
    }}
}}
function addMsg(text, isUser) {{
    const c = document.getElementById('chatMsgs');
    const d = document.createElement('div');
    d.className = 'msg ' + (isUser ? 'user' : 'bot');
    d.innerHTML = '<div class="msg-av">' + (isUser ? '&#x1F464;' : '&#x1F916;') + '</div><div class="bubble">' + text.replace(/\\n/g,'<br>') + '</div>';
    c.appendChild(d); c.scrollTop = c.scrollHeight;
}}
function showTyping() {{
    const c = document.getElementById('chatMsgs');
    const d = document.createElement('div');
    d.className = 'msg bot'; d.id = 'typingDiv';
    d.innerHTML = '<div class="msg-av">&#x1F916;</div><div class="bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>';
    c.appendChild(d); c.scrollTop = c.scrollHeight;
}}
function hideTyping() {{ const t = document.getElementById('typingDiv'); if(t) t.remove(); }}
async function sendMsg() {{
    const inp = document.getElementById('chatIn');
    const txt = inp.value.trim();
    if(!txt) return;
    inp.value = '';
    addMsg(txt, true);
    showTyping();
    try {{
        const fd = new FormData();
        fd.append('db', DB);
        fd.append('chat_msg', txt);
        const res = await fetch('studrec.py', {{method:'POST', body:fd}});
        const data = await res.json();
        hideTyping();
        addMsg(data.reply || 'No response.', false);
    }} catch(e) {{ hideTyping(); addMsg('Sorry, an error occurred.', false); }}
}}
function quickSend(txt) {{ document.getElementById('chatIn').value = txt; sendMsg(); }}
</script>
</body>
</html>"""
sys.stdout.flush()
sys.stdout.buffer.write(_html_out.encode('utf-8'))
sys.stdout.buffer.flush()
# ================= END HTML OUTPUT =================
