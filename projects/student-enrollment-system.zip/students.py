#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import re
if sys.version_info[0] >= 3:
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import cgitb
cgitb.enable()
import cgi
import mysql.connector
import html
import json
form = cgi.FieldStorage()
enroll_action = form.getfirst("enroll_action", "")
enroll_studid = form.getfirst("enroll_studid", "")
enroll_subjid = form.getfirst("enroll_subjid", "")
action = form.getfirst("action", "")
studid = form.getfirst("studid", "")
name = form.getfirst("name", "")
address = form.getfirst("address", "")
gender = form.getfirst("gender", "")
course = form.getfirst("course", "")
year = form.getfirst("year", "")
subjid = form.getfirst("subjid", "")
logout = form.getfirst("logout", "")
create_db = form.getfirst("create_db", "")

def get_cookie_value(cookie_name):
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith(cookie_name + '='):
                return cookie.split('=', 1)[1]
    return ""

user_role = get_cookie_value('user_role')
db_user = get_cookie_value('db_user')

if logout == "1":
    print("Set-Cookie: enrolled_db=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Set-Cookie: db_user=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Set-Cookie: user_role=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    print("Location: index.py\n")
    sys.exit()

db_name = form.getfirst("db", "").strip()
if not db_name:
    if 'HTTP_COOKIE' in os.environ:
        cookies = os.environ['HTTP_COOKIE'].split('; ')
        for cookie in cookies:
            if cookie.startswith('enrolled_db='):
                db_name = cookie[12:]
                break

def get_all_valid_databases():
    import re as _re
    try:
        _conn = mysql.connector.connect(
            host="localhost", user="root", password="root",
            charset='utf8mb4', use_unicode=True
        )
        _cur = _conn.cursor()
        _cur.execute("SHOW DATABASES")
        all_dbs = [row[0] for row in _cur.fetchall()]
        _cur.close()
        _conn.close()
        return [d for d in all_dbs if (
            _re.match(r'^1stsy_\d{4}_\d{4}$', d) or
            _re.match(r'^2ndsem_sy\d{4}_\d{4}$', d) or
            _re.match(r'^summersy_\d{4}_\d{4}$', d)
        )]
    except:
        return []

VALID_DATABASES = get_all_valid_databases()

if not db_name or db_name not in VALID_DATABASES:
    print("Location: index.py\n")
    sys.exit()

# === NEW: Get user grants using SHOW GRANTS (background verification) ===
user_grants = []
try:
    if db_user and user_role == "admin":
        conn_grants = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root"
        )
        cur_grants = conn_grants.cursor()
        try:
            cur_grants.execute(f"SHOW GRANTS FOR '{db_user}'@'localhost'")
            user_grants = [row[0] for row in cur_grants.fetchall()]
        except mysql.connector.Error:
            pass
        cur_grants.close()
        conn_grants.close()
except mysql.connector.Error:
    pass
# === END NEW CODE ===

# === REDIRECT NON-ADMIN USERS ===
if user_role == "student":
    print("Location: index.py\n")
    sys.exit()
elif user_role == "teacher":
    print("Location: index.py\n")
    sys.exit()

# === PERMISSION CHECKS WITH ALERT ===
if user_role == "student" and action in ["insert", "update", "delete"]:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<script>alert('Access denied: You don\\'t have permission to perform this action.'); window.location.href='students.py?db={html.escape(db_name)}';</script>")
    sys.exit()

if user_role == "student" and create_db:
    print("Content-Type: text/html; charset=utf-8\n")
    print(f"<script>alert('Access denied: You don\\'t have permission to perform this action.'); window.location.href='students.py?db={html.escape(db_name)}';</script>")
    sys.exit()

if create_db in ["1st_sem", "2nd_sem", "summer"]:
    try:
        from datetime import datetime
        import re as _re
        conn_create = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            charset='utf8mb4',
            use_unicode=True
        )
        cur_create = conn_create.cursor()
        cur_create.execute("SHOW DATABASES")
        all_existing = [row[0] for row in cur_create.fetchall()]

        # ── Determine new DB name and source DB ───────────────────────────────
        # Cycle rule:
        #   2nd Sem → copies from latest 1stsy,    same year: 2ndsem_sy{YYYY}_{YYYY+1}
        #   Summer  → copies from latest 2ndsem_sy, same year: summersy_{YYYY}_{YYYY+1}
        #   1st Sem → copies from latest summersy,  year+1:    1stsy_{YYYY+1}_{YYYY+2}
        source_db = None

        def latest_match(pattern, dbs):
            found = []
            for d in dbs:
                m = _re.match(pattern, d)
                if m:
                    found.append((int(m.group(1)), int(m.group(2)), d))
            return sorted(found)[-1] if found else None

        if create_db == "2nd_sem":
            src = latest_match(r'^1stsy_(\d{4})_(\d{4})$', all_existing)
            if not src:
                print("Content-Type: text/html; charset=utf-8\n")
                print("<script>alert('No 1st Semester database found. Please create a 1st Sem first.'); window.location.href='students.py?db=" + db_name + "';</script>")
                sys.exit()
            source_db = src[2]
            yr1, yr2 = src[0], src[1]
            new_db = f"2ndsem_sy{yr1}_{yr2}"

        elif create_db == "summer":
            src = latest_match(r'^2ndsem_sy(\d{4})_(\d{4})$', all_existing)
            if not src:
                print("Content-Type: text/html; charset=utf-8\n")
                print("<script>alert('No 2nd Semester database found. Please create a 2nd Sem first.'); window.location.href='students.py?db=" + db_name + "';</script>")
                sys.exit()
            source_db = src[2]
            yr1, yr2 = src[0], src[1]
            new_db = f"summersy_{yr1}_{yr2}"

        elif create_db == "1st_sem":
            src = latest_match(r'^summersy_(\d{4})_(\d{4})$', all_existing)
            if src:
                source_db = src[2]
                yr1 = src[0] + 1
            else:
                src = latest_match(r'^1stsy_(\d{4})_(\d{4})$', all_existing)
                if src:
                    source_db = src[2]
                    yr1 = src[0] + 1
                else:
                    from datetime import datetime as _dt
                    yr1 = _dt.now().year
                    source_db = None
            new_db = f"1stsy_{yr1}_{yr1 + 1}"

        # Prevent duplicate creation
        if new_db in all_existing:
            print("Content-Type: text/html; charset=utf-8\n")
            print(f"<script>alert('Database {new_db} already exists.'); window.location.href='students.py?db={db_name}';</script>")
            sys.exit()

        cur_create.execute(f"CREATE DATABASE `{new_db}`")
        cur_create.execute(f"USE `{new_db}`")
        
        schema_sql = """
        CREATE TABLE students (
        studid INT NOT NULL PRIMARY KEY,
        studname TEXT NOT NULL,
        studadd TEXT NULL,
        studcrs TEXT NULL,
        studgender TEXT NULL,
        yrlvl TEXT NULL
        );
        CREATE TABLE subjects (
        subjid INT NOT NULL PRIMARY KEY,
        subjcode TEXT NULL DEFAULT NULL,
        subjdesc TEXT NULL DEFAULT NULL,
        subjunits INT NULL DEFAULT NULL,
        subjsched TEXT NULL
        );
        CREATE TABLE teachers (
        tid INT NOT NULL PRIMARY KEY,
        tname TEXT NULL DEFAULT NULL,
        tdept TEXT NULL DEFAULT NULL,
        tadd TEXT NULL,
        tcontact TEXT NULL,
        tstatus TEXT NULL
        );
        CREATE TABLE assign (
        SubjID INT NOT NULL UNIQUE,
        TID INT NOT NULL,
        FOREIGN KEY (SubjID) REFERENCES subjects(subjid) ON DELETE CASCADE,
        FOREIGN KEY (TID) REFERENCES teachers(tid) ON DELETE CASCADE
        );
        CREATE TABLE enroll (
        eid INT NOT NULL AUTO_INCREMENT,
        studid INT NOT NULL,
        subjid INT NOT NULL,
        evaluation TEXT DEFAULT NULL,
        PRIMARY KEY (eid),
        UNIQUE (studid, subjid),
        FOREIGN KEY (studid) REFERENCES students(studid) ON DELETE CASCADE,
        FOREIGN KEY (subjid) REFERENCES subjects(subjid) ON DELETE CASCADE
        );
        CREATE TABLE grades (
        gradeid INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        enroll_eid INT NOT NULL UNIQUE,
        prelim TEXT NULL DEFAULT NULL,
        midterm TEXT NULL DEFAULT NULL,
        prefinal TEXT NULL DEFAULT NULL,
        final TEXT NULL DEFAULT NULL,
        FOREIGN KEY (enroll_eid) REFERENCES enroll(eid) ON DELETE CASCADE
        );
        """
        for stmt in schema_sql.strip().split(';'):
            if stmt.strip():
                cur_create.execute(stmt)
        
        proc1 = """
        CREATE PROCEDURE check_schedule_conflict(
        IN p_studid INT,
        IN p_subjid INT,
        OUT conflict_exists INT,
        OUT conflict_schedule VARCHAR(255)
        )
        main_block: BEGIN
        DECLARE i INT DEFAULT 1;
        DECLARE n INT DEFAULT 0;
        DECLARE old_sched VARCHAR(255);
        DECLARE new_sched VARCHAR(255);
        DECLARE days VARCHAR(50);
        DECLARE old_days VARCHAR(50);
        DECLARE stime TIME;
        DECLARE etime TIME;
        DECLARE old_stime TIME;
        DECLARE old_etime TIME;
        SET conflict_exists = 0;
        SET conflict_schedule = NULL;
        SELECT subjsched INTO new_sched FROM subjects WHERE subjid = p_subjid;
        IF new_sched IS NULL OR TRIM(new_sched) = '' THEN LEAVE main_block; END IF;
        CREATE TEMPORARY TABLE temp_table (id INT AUTO_INCREMENT PRIMARY KEY, subsched TEXT);
        INSERT INTO temp_table (subsched)
        SELECT s.subjsched FROM subjects s INNER JOIN enroll e ON s.subjid = e.subjid
        WHERE e.studid = p_studid AND s.subjsched != '';
        SET new_sched = TRIM(new_sched);
        SET days = TRIM(LEFT(new_sched, 3));
        SET @time_part = TRIM(SUBSTRING(new_sched, LOCATE(' ', new_sched) + 1));
        SET @start_str = TRIM(SUBSTRING_INDEX(@time_part, '-', 1));
        SET @end_str = TRIM(SUBSTRING_INDEX(@time_part, '-', -1));
        SET stime = STR_TO_DATE(@start_str, '%H:%i');
        SET etime = STR_TO_DATE(@end_str, '%H:%i');
        IF stime IS NULL OR etime IS NULL THEN DROP TEMPORARY TABLE temp_table; LEAVE main_block; END IF;
        SELECT COUNT(*) INTO n FROM temp_table;
        WHILE i <= n DO
        SELECT subsched INTO old_sched FROM temp_table WHERE id = i;
        IF old_sched != '' THEN
        SET old_sched = TRIM(old_sched);
        SET old_days = TRIM(LEFT(old_sched, 3));
        SET @old_time_part = TRIM(SUBSTRING(old_sched, LOCATE(' ', old_sched) + 1));
        SET @old_start_str = TRIM(SUBSTRING_INDEX(@old_time_part, '-', 1));
        SET @old_end_str = TRIM(SUBSTRING_INDEX(@old_time_part, '-', -1));
        SET old_stime = STR_TO_DATE(@old_start_str, '%H:%i');
        SET old_etime = STR_TO_DATE(@old_end_str, '%H:%i');
        IF old_stime IS NOT NULL AND old_etime IS NOT NULL THEN
        SET @day_overlap = 0;
        IF days LIKE '%M%' AND old_days LIKE '%M%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%T%' AND old_days LIKE '%T%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%W%' AND old_days LIKE '%W%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%H%' AND old_days LIKE '%H%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%F%' AND old_days LIKE '%F%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%S%' AND old_days LIKE '%S%' THEN SET @day_overlap = 1; END IF;
        IF @day_overlap = 1 AND (stime < old_etime AND old_stime < etime) THEN
        SET conflict_exists = 1;
        SET conflict_schedule = old_sched;
        DROP TEMPORARY TABLE temp_table;
        LEAVE main_block;
        END IF;
        END IF;
        END IF;
        SET i = i + 1;
        END WHILE;
        DROP TEMPORARY TABLE temp_table;
        END
        """
        cur_create.execute(proc1)
        
        proc2 = """
        CREATE PROCEDURE check_teacher_assignment_conflict(
        IN p_tid INT,
        IN p_subjid INT,
        OUT conflict_exists INT,
        OUT conflict_schedule VARCHAR(255)
        )
        main_block: BEGIN
        DECLARE i INT DEFAULT 1;
        DECLARE n INT DEFAULT 0;
        DECLARE old_sched VARCHAR(255);
        DECLARE new_sched VARCHAR(255);
        DECLARE days VARCHAR(50);
        DECLARE old_days VARCHAR(50);
        DECLARE stime TIME;
        DECLARE etime TIME;
        DECLARE old_stime TIME;
        DECLARE old_etime TIME;
        DECLARE other_teacher_id INT DEFAULT NULL;
        SET conflict_exists = 0;
        SET conflict_schedule = NULL;
        SELECT TID INTO other_teacher_id FROM assign WHERE SubjID = p_subjid AND TID != p_tid;
        IF other_teacher_id IS NOT NULL THEN
        SET conflict_exists = 1;
        SET conflict_schedule = 'Subject already assigned to another teacher';
        LEAVE main_block;
        END IF;
        SELECT subjsched INTO new_sched FROM subjects WHERE subjid = p_subjid;
        IF new_sched IS NULL OR TRIM(new_sched) = '' THEN LEAVE main_block; END IF;
        CREATE TEMPORARY TABLE temp_table (id INT AUTO_INCREMENT PRIMARY KEY, subsched TEXT);
        INSERT INTO temp_table (subsched)
        SELECT s.subjsched FROM subjects s INNER JOIN assign a ON s.subjid = a.SubjID
        WHERE a.TID = p_tid AND s.subjsched != '';
        SET new_sched = TRIM(new_sched);
        SET days = TRIM(LEFT(new_sched, 3));
        SET @time_part = TRIM(SUBSTRING(new_sched, LOCATE(' ', new_sched) + 1));
        SET @start_str = TRIM(SUBSTRING_INDEX(@time_part, '-', 1));
        SET @end_str = TRIM(SUBSTRING_INDEX(@time_part, '-', -1));
        SET stime = STR_TO_DATE(@start_str, '%H:%i');
        SET etime = STR_TO_DATE(@end_str, '%H:%i');
        IF stime IS NULL OR etime IS NULL THEN DROP TEMPORARY TABLE temp_table; LEAVE main_block; END IF;
        SELECT COUNT(*) INTO n FROM temp_table;
        WHILE i <= n DO
        SELECT subsched INTO old_sched FROM temp_table WHERE id = i;
        IF old_sched != '' THEN
        SET old_sched = TRIM(old_sched);
        SET old_days = TRIM(LEFT(old_sched, 3));
        SET @old_time_part = TRIM(SUBSTRING(old_sched, LOCATE(' ', old_sched) + 1));
        SET @old_start_str = TRIM(SUBSTRING_INDEX(@old_time_part, '-', 1));
        SET @old_end_str = TRIM(SUBSTRING_INDEX(@old_time_part, '-', -1));
        SET old_stime = STR_TO_DATE(@old_start_str, '%H:%i');
        SET old_etime = STR_TO_DATE(@old_end_str, '%H:%i');
        IF old_stime IS NOT NULL AND old_etime IS NOT NULL THEN
        SET @day_overlap = 0;
        IF days LIKE '%M%' AND old_days LIKE '%M%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%T%' AND old_days LIKE '%T%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%W%' AND old_days LIKE '%W%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%H%' AND old_days LIKE '%H%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%F%' AND old_days LIKE '%F%' THEN SET @day_overlap = 1; END IF;
        IF days LIKE '%S%' AND old_days LIKE '%S%' THEN SET @day_overlap = 1; END IF;
        IF @day_overlap = 1 AND (stime < old_etime AND old_stime < etime) THEN
        SET conflict_exists = 1;
        SET conflict_schedule = old_sched;
        DROP TEMPORARY TABLE temp_table;
        LEAVE main_block;
        END IF;
        END IF;
        END IF;
        SET i = i + 1;
        END WHILE;
        DROP TEMPORARY TABLE temp_table;
        END
        """
        cur_create.execute(proc2)
        
        # ── Copy data from source_db (students, subjects, teachers, assign) ──
        if source_db:
            try:
                conn_src = mysql.connector.connect(
                    host="localhost", user="root", password="root",
                    database=source_db, charset='utf8mb4', use_unicode=True
                )
                cur_src = conn_src.cursor()

                # students
                cur_src.execute("SELECT studid, studname, studadd, studcrs, studgender, yrlvl FROM students")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.students (studid,studname,studadd,studcrs,studgender,yrlvl) VALUES (%s,%s,%s,%s,%s,%s)",
                        rows
                    )

                # subjects
                cur_src.execute("SELECT subjid, subjcode, subjdesc, subjunits, subjsched FROM subjects")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.subjects (subjid,subjcode,subjdesc,subjunits,subjsched) VALUES (%s,%s,%s,%s,%s)",
                        rows
                    )

                # teachers
                cur_src.execute("SELECT tid, tname, tdept, tadd, tcontact, tstatus FROM teachers")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.teachers (tid,tname,tdept,tadd,tcontact,tstatus) VALUES (%s,%s,%s,%s,%s,%s)",
                        rows
                    )

                # assign (teacher-subject assignments)
                cur_src.execute("SELECT SubjID, TID FROM assign")
                rows = cur_src.fetchall()
                if rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.assign (SubjID, TID) VALUES (%s,%s)",
                        rows
                    )

                # enroll (copy enrollments — eid must match for grades FK)
                cur_src.execute("SELECT eid, studid, subjid, evaluation FROM enroll")
                enroll_rows = cur_src.fetchall()
                if enroll_rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.enroll (eid, studid, subjid, evaluation) VALUES (%s,%s,%s,%s)",
                        enroll_rows
                    )

                # grades (copy grades linked to enroll eids)
                cur_src.execute("SELECT gradeid, enroll_eid, prelim, midterm, prefinal, final FROM grades")
                grade_rows = cur_src.fetchall()
                if grade_rows:
                    cur_create.executemany(
                        f"INSERT IGNORE INTO `{new_db}`.grades (gradeid, enroll_eid, prelim, midterm, prefinal, final) VALUES (%s,%s,%s,%s,%s,%s)",
                        grade_rows
                    )

                cur_src.close()
                conn_src.close()
            except Exception:
                pass  # copy failure is non-fatal; new DB still works empty

        conn_create.commit()
        cur_create.close()
        conn_create.close()

        source_msg = f". Data copied from {source_db}." if source_db else "."
        print("Content-Type: text/html; charset=utf-8\n")
        print(f"<script>alert('Database {new_db} created successfully{source_msg}'); window.location.href='students.py?db={db_name}';</script>")
        sys.exit()
    except Exception as e:
        pass

# === TRAIN MODEL ACTION ===
if action == "traindata":
    train_db = form.getfirst("db_train", "").strip()
    if train_db:
        try:
            import pickle, os, torch, torch.nn as nn
            from collections import defaultdict
            conn_train = mysql.connector.connect(
                host="localhost", user="root", password="root",
                database=train_db, charset='utf8mb4', use_unicode=True
            )
            cur_train = conn_train.cursor()
            cur_train.execute("""
            SELECT s.studid, s.studgender, s.studcrs, s.yrlvl, e.subjid
            FROM students s
            JOIN enroll e ON s.studid = e.studid
            ORDER BY s.studid
            """)
            rows = cur_train.fetchall()
            cur_train.execute("SELECT subjid FROM subjects ORDER BY subjid")
            all_subj = [r[0] for r in cur_train.fetchall()]
            cur_train.close(); conn_train.close()
            subj_index = {sid: i for i, sid in enumerate(all_subj)}
            student_data = defaultdict(lambda: {"gender":"","course":"","year":"","subjects":[]})
            for studid, gender, course, yr, subjid in rows:
                student_data[studid]["gender"]  = (gender or "").strip().lower()
                student_data[studid]["course"]  = (course or "").strip().upper()
                student_data[studid]["year"]    = (yr    or "").strip().lower()
                student_data[studid]["subjects"].append(int(subjid))
            genders = sorted(set(v["gender"] for v in student_data.values()))
            courses = sorted(set(v["course"] for v in student_data.values()))
            years   = sorted(set(v["year"]   for v in student_data.values()))
            gender_map = {g: i for i, g in enumerate(genders)}
            course_map = {c: i for i, c in enumerate(courses)}
            year_map   = {y: i for i, y in enumerate(years)}
            input_size  = len(genders) + len(courses) + len(years)
            output_size = len(all_subj)
            X_list, Y_list = [], []
            for info in student_data.values():
                g_vec = [0.0]*len(genders); g_vec[gender_map[info["gender"]]] = 1.0
                c_vec = [0.0]*len(courses); c_vec[course_map[info["course"]]] = 1.0
                y_vec = [0.0]*len(years);   y_vec[year_map[info["year"]]]     = 1.0
                X_list.append(g_vec + c_vec + y_vec)
                label = [0.0]*output_size
                for sid in info["subjects"]:
                    if sid in subj_index:
                        label[subj_index[sid]] = 1.0
                Y_list.append(label)
            X = torch.tensor(X_list, dtype=torch.float32)
            Y = torch.tensor(Y_list, dtype=torch.float32)
            class EnrollNet(nn.Module):
                def __init__(self, inp, out):
                    super().__init__()
                    self.net = nn.Sequential(
                        nn.Linear(inp, 64), nn.ReLU(), nn.Dropout(0.2),
                        nn.Linear(64, 128), nn.ReLU(), nn.Dropout(0.2),
                        nn.Linear(128, out)
                    )
                def forward(self, x):
                    return self.net(x)
            model_net = EnrollNet(input_size, output_size)
            optimizer = torch.optim.Adam(model_net.parameters(), lr=0.01)
            loss_fn   = nn.BCEWithLogitsLoss()
            model_net.train()
            for epoch in range(500):
                optimizer.zero_grad()
                out = model_net(X)
                loss = loss_fn(out, Y)
                loss.backward()
                optimizer.step()
            model_net.eval()
            with torch.no_grad():
                preds = torch.sigmoid(model_net(X)) >= 0.5
                correct = (preds == Y.bool()).all(dim=1).sum().item()
                accuracy = correct / len(X_list)
            model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "enrollment_model.pkl")
            payload = {
                "model_state": model_net.state_dict(),
                "input_size":  input_size,
                "output_size": output_size,
                "gender_map":  gender_map,
                "course_map":  course_map,
                "year_map":    year_map,
                "all_subj":    all_subj,
                "train_db":    train_db
            }
            with open(model_path, "wb") as f:
                pickle.dump(payload, f)
            print("Content-Type: text/html; charset=utf-8\n")
            print(f"""<script>
            alert('Model Trained Successfully\\nDatabase: {train_db}\\nValidation Accuracy: {accuracy:.4f}');
            window.location.href='students.py?db={html.escape(db_name)}';
            </script>""")
            sys.exit()
        except Exception as e:
            print("Content-Type: text/html; charset=utf-8\n")
            print(f"<script>alert('Training failed: {html.escape(str(e))}'); window.location.href='students.py?db={html.escape(db_name)}';</script>")
            sys.exit()
# === END TRAIN MODEL ===

# ============================================================
#  AI ENROLL  —  run inference on trained PyTorch model
# ============================================================
if action == "ai_enroll":
    ai_studid = form.getfirst("ai_studid", "").strip()
    if ai_studid.isdigit():
        try:
            import pickle, os, torch, torch.nn as nn
            from collections import defaultdict
            model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "enrollment_model.pkl")
            if not os.path.exists(model_path):
                print("Content-Type: text/html; charset=utf-8\n")
                print(f"<script>alert('No trained model found. Please train the model first.'); window.location.href='students.py?db={html.escape(db_name)}&studid={ai_studid}';</script>")
                sys.exit()
            with open(model_path, "rb") as f:
                payload = pickle.load(f)
            class EnrollNet(nn.Module):
                def __init__(self, inp, out):
                    super().__init__()
                    self.net = nn.Sequential(
                        nn.Linear(inp, 64), nn.ReLU(), nn.Dropout(0.2),
                        nn.Linear(64, 128), nn.ReLU(), nn.Dropout(0.2),
                        nn.Linear(128, out)
                    )
                def forward(self, x):
                    return self.net(x)
            model_net = EnrollNet(payload["input_size"], payload["output_size"])
            model_net.load_state_dict(payload["model_state"])
            model_net.eval()
            conn_ai = mysql.connector.connect(
                host="localhost", user="root", password="root",
                database=db_name, charset='utf8mb4', use_unicode=True
            )
            cur_ai = conn_ai.cursor()
            cur_ai.execute("SELECT studgender, studcrs, yrlvl FROM students WHERE studid=%s", (int(ai_studid),))
            stud_row = cur_ai.fetchone()
            if not stud_row:
                print("Content-Type: text/html; charset=utf-8\n")
                print(f"<script>alert('Student not found.'); window.location.href='students.py?db={html.escape(db_name)}';</script>")
                sys.exit()
            s_gender = (stud_row[0] or "").strip().lower()
            s_course = (stud_row[1] or "").strip().upper()
            s_year   = (stud_row[2] or "").strip().lower()
            student_data = defaultdict(lambda: {"gender":"","course":"","year":"","subjects":[]})
            cur_ai.execute("""
            SELECT s.studid, s.studgender, s.studcrs, s.yrlvl, e.subjid
            FROM students s
            JOIN enroll e ON s.studid = e.studid
            ORDER BY s.studid
            """)
            rows = cur_ai.fetchall()
            for sid, gender, course, yr, subjid in rows:
                student_data[sid]["gender"]  = (gender or "").strip().lower()
                student_data[sid]["course"]  = (course or "").strip().upper()
                student_data[sid]["year"]    = (yr    or "").strip().lower()
                student_data[sid]["subjects"].append(int(subjid))
            genders = sorted(set(v["gender"] for v in student_data.values()))
            courses = sorted(set(v["course"] for v in student_data.values()))
            years   = sorted(set(v["year"]   for v in student_data.values()))
            gender_map = {g: i for i, g in enumerate(genders)}
            course_map = {c: i for i, c in enumerate(courses)}
            year_map   = {y: i for i, y in enumerate(years)}
            def _encode_input(gender, course, year, gender_map, course_map, year_map):
                import torch
                g_vec = [0.0] * len(gender_map)
                c_vec = [0.0] * len(course_map)
                y_vec = [0.0] * len(year_map)
                if gender in gender_map: g_vec[gender_map[gender]] = 1.0
                if course  in course_map: c_vec[course_map[course]]  = 1.0
                if year    in year_map:   y_vec[year_map[year]]      = 1.0
                return torch.tensor([g_vec + c_vec + y_vec], dtype=torch.float32)
            x_input = _encode_input(s_gender, s_course, s_year,
                                    payload["gender_map"],
                                    payload["course_map"],
                                    payload["year_map"])
            with torch.no_grad():
                logits = model_net(x_input)
                probs  = torch.sigmoid(logits)[0]
                predicted = (probs >= 0.5).tolist()
            all_subj = payload["all_subj"]
            recommended = [all_subj[i] for i, p in enumerate(predicted) if p]
            if not recommended:
                print("Content-Type: text/html; charset=utf-8\n")
                print(f"<script>alert('AI found no recommended subjects for this student profile. Try retraining.'); window.location.href='students.py?db={html.escape(db_name)}&studid={ai_studid}';</script>")
                sys.exit()
            cur_ai.execute("SELECT subjid FROM enroll WHERE studid=%s", (int(ai_studid),))
            already_enrolled = set(row[0] for row in cur_ai.fetchall())
            enrolled_schedules = []
            if already_enrolled:
                fmt = ','.join(['%s'] * len(already_enrolled))
                cur_ai.execute(f"SELECT subjsched FROM subjects WHERE subjid IN ({fmt})", list(already_enrolled))
                enrolled_schedules = [row[0] for row in cur_ai.fetchall() if row[0]]
            def _parse_sched(s):
                s = (s or "").strip()
                if not s: return None
                parts = s.split()
                if len(parts) < 2: return None
                days = parts[0].upper()
                times = parts[1].split('-')
                if len(times) < 2: return None
                try:
                    from datetime import time as dtime
                    def tt(x):
                        h, m = x.strip().split(':'); return dtime(int(h), int(m))
                    return (days, tt(times[0]), tt(times[1]))
                except: return None
            def _days_overlap(d1, d2):
                return any(ch in d2 for ch in d1)
            def _has_conflict(new_s, existing):
                ns = _parse_sched(new_s)
                if not ns: return False
                for es_str in existing:
                    es = _parse_sched(es_str)
                    if es and _days_overlap(ns[0], es[0]) and ns[1] < es[2] and es[1] < ns[2]:
                        return True
                return False
            enrolled_count  = 0
            skipped_conflict = []
            skipped_already  = []
            for subjid in recommended:
                if subjid in already_enrolled:
                    skipped_already.append(subjid)
                    continue
                cur_ai.execute("SELECT subjsched FROM subjects WHERE subjid=%s", (int(subjid),))
                sched_row  = cur_ai.fetchone()
                subj_sched = sched_row[0] if sched_row else ""
                if _has_conflict(subj_sched, enrolled_schedules):
                    skipped_conflict.append(subjid)
                    continue
                cur_ai.execute("SELECT 1 FROM subjects WHERE subjid=%s", (int(subjid),))
                if not cur_ai.fetchone():
                    continue
                cur_ai.execute("INSERT IGNORE INTO enroll (studid, subjid) VALUES (%s,%s)",
                              (int(ai_studid), int(subjid)))
                enrolled_schedules.append(subj_sched)
                already_enrolled.add(subjid)
                enrolled_count += 1
            conn_ai.commit()
            cur_ai.close()
            conn_ai.close()
            # ✅ REMOVED ALERT - Just redirect silently
            print(f"Location: students.py?db={html.escape(db_name)}&studid={ai_studid}\n")
            sys.exit()
        except Exception as e:
            print("Content-Type: text/html; charset=utf-8\n")
            print(f"<script>alert('AI Enroll failed: {html.escape(str(e))}'); window.location.href='students.py?db={html.escape(db_name)}';</script>")
            sys.exit()
# === END AI ENROLL ===

enrolled_student_id = ""
if enroll_action in ["enroll_student", "drop_student"]:
    if enroll_studid.isdigit() and enroll_subjid.isdigit():
        enrolled_student_id = enroll_studid
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database=db_name,
                charset='utf8mb4',
                use_unicode=True
            )
            cur = conn.cursor()
            if enroll_action == "enroll_student":
                cur.execute("SELECT 1 FROM enroll WHERE studid=%s AND subjid=%s",
                           (int(enroll_studid), int(enroll_subjid)))
                if not cur.fetchone():
                    cur.execute("INSERT INTO enroll (studid, subjid) VALUES (%s,%s)",
                               (int(enroll_studid), int(enroll_subjid)))
                    conn.commit()
                    cur.execute("SELECT eid FROM enroll WHERE studid=%s AND subjid=%s",
                               (int(enroll_studid), int(enroll_subjid)))
                    new_eid_row = cur.fetchone()
                    if new_eid_row:
                        new_eid = new_eid_row[0]
                        try:
                            from pymongo import MongoClient
                            _mc = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=3000)
                            _mdb = _mc[db_name]
                            _mdb.enroll.update_one(
                                {"_id": new_eid},
                                {"$set": {"_id": new_eid, "eid": new_eid,
                                          "studid": int(enroll_studid),
                                          "subjid": int(enroll_subjid),
                                          "evaluation": None}},
                                upsert=True
                            )
                            _mc.close()
                        except Exception:
                            pass
            elif enroll_action == "drop_student":
                cur.execute("SELECT eid FROM enroll WHERE studid=%s AND subjid=%s",
                           (int(enroll_studid), int(enroll_subjid)))
                drop_eid_row = cur.fetchone()
                drop_eid = drop_eid_row[0] if drop_eid_row else None
                cur.execute("DELETE FROM enroll WHERE studid=%s AND subjid=%s",
                           (int(enroll_studid), int(enroll_subjid)))
                conn.commit()
                if drop_eid:
                    try:
                        from pymongo import MongoClient
                        _mc = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=3000)
                        _mdb = _mc[db_name]
                        _mdb.enroll.delete_one({"_id": drop_eid})
                        _mdb.grades.delete_one({"enroll_eid": drop_eid})
                        _mc.close()
                    except Exception:
                        pass
            conn.commit()
            cur.close()
            conn.close()
        except:
            pass

try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database=db_name,
        charset='utf8mb4',
        use_unicode=True
    )
    cur = conn.cursor()
    cur.execute("SELECT MAX(studid) FROM students")
    max_id_result = cur.fetchone()
    max_id = max_id_result[0] if max_id_result[0] is not None else 999
    next_id = max_id + 1 if max_id >= 1000 else 1000
    
    if user_role == "admin":
        if action == "insert":
            new_studid = next_id
            # Format: studid_firstname (first word of name, lowercase)
            first_name = re.sub(r'[^a-zA-Z]', '', name.strip().split()[0]).lower() if name.strip() else "user"
            username_for_db = str(new_studid) + "_" + first_name
            password_for_db = "addu" + first_name if first_name else "adduuser"
            cur.execute(
                "INSERT INTO students (studid, studname, studadd, studcrs, studgender, yrlvl) VALUES (%s,%s,%s,%s,%s,%s)",
                (new_studid, name, address, course, gender, year)
            )
            conn.commit()
            try:
                cur_user = conn.cursor()
                cur_user.execute("CREATE USER IF NOT EXISTS %s@'localhost' IDENTIFIED BY %s", (username_for_db, password_for_db))
                cur_user.execute(f"GRANT SELECT ON `{db_name}`.`students` TO %s@'localhost'", (username_for_db,))
                cur_user.execute(f"GRANT SELECT ON `{db_name}`.`subjects` TO %s@'localhost'", (username_for_db,))
                cur_user.execute(f"GRANT SELECT ON `{db_name}`.`teachers` TO %s@'localhost'", (username_for_db,))
                cur_user.execute(f"GRANT INSERT, DELETE ON `{db_name}`.`enroll` TO %s@'localhost'", (username_for_db,))
                cur_user.execute("FLUSH PRIVILEGES")
                cur_user.close()
            except Exception as e:
                pass
            name = address = gender = course = year = ""
            studid = str(new_studid)
            next_id += 1
            print(f"Content-Type: text/html; charset=utf-8\n")
            print(f"<script>window.location.href='students.py?db={html.escape(db_name)}&studid={new_studid}&inserted=1';</script>")
            sys.exit()
        elif action == "update":
            if studid and studid.isdigit():
                cur.execute("SELECT studname FROM students WHERE studid = %s", (int(studid),))
                old_name_row = cur.fetchone()
                if old_name_row:
                    old_first = re.sub(r'[^a-zA-Z]', '', old_name_row[0].strip().split()[0]).lower() if old_name_row[0] else "user"
                    old_username = str(studid) + "_" + old_first
                    new_first = re.sub(r'[^a-zA-Z]', '', name.strip().split()[0]).lower() if name.strip() else "user"
                    new_username = str(studid) + "_" + new_first
                    if old_username != new_username:
                        try:
                            cur_user = conn.cursor()
                            cur_user.execute("RENAME USER %s@'localhost' TO %s@'localhost'", (old_username, new_username))
                            cur_user.execute("FLUSH PRIVILEGES")
                            cur_user.close()
                        except mysql.connector.Error as e:
                            pass
                cur.execute("""UPDATE students SET
                    studname=%s, studadd=%s, studcrs=%s, studgender=%s, yrlvl=%s
                    WHERE studid=%s""", (name, address, course, gender, year, int(studid)))
                conn.commit()
                next_id = int(studid)
        elif action == "delete":
            if studid and studid.isdigit():
                cur.execute("SELECT studname FROM students WHERE studid = %s", (int(studid),))
                name_row = cur.fetchone()
                if name_row:
                    first_name_del = re.sub(r'[^a-zA-Z]', '', name_row[0].strip().split()[0]).lower() if name_row[0] else "user"
                    username_to_drop = str(studid) + "_" + first_name_del
                    try:
                        cur_user = conn.cursor()
                        try:
                            cur_user.execute(f"REVOKE ALL PRIVILEGES, GRANT OPTION FROM '{username_to_drop}'@'localhost'")
                            cur_user.execute("FLUSH PRIVILEGES")
                        except mysql.connector.Error:
                            pass
                        cur_user.execute("DROP USER IF EXISTS %s@'localhost'", (username_to_drop,))
                        cur_user.execute("FLUSH PRIVILEGES")
                        cur_user.close()
                    except:
                        pass
                cur.execute("DELETE FROM students WHERE studid=%s", (int(studid),))
                conn.commit()
                name = address = gender = course = year = ""
                studid = ""
                cur.execute("SELECT MAX(studid) FROM students")
                max_id_result = cur.fetchone()
                max_id = max_id_result[0] if max_id_result[0] is not None else 999
                next_id = max_id + 1 if max_id >= 1000 else 1000
    
    cur.execute("""
        SELECT s.studid, s.studname, s.studadd, s.studgender, s.studcrs, s.yrlvl,
        COALESCE(SUM(sub.subjunits), 0)
        FROM students s
        LEFT JOIN enroll e ON s.studid = e.studid
        LEFT JOIN subjects sub ON e.subjid = sub.subjid
        GROUP BY s.studid
        ORDER BY s.studid
    """)
    students = cur.fetchall()
    
    subjects_by_student = {}
    for s in students:
        sid = s[0]
        cur.execute("""
            SELECT subjid, subjcode, subjdesc, subjunits, subjsched
            FROM subjects
            WHERE subjid IN (SELECT subjid FROM enroll WHERE studid=%s)
        """, (sid,))
        subjects_by_student[sid] = cur.fetchall()
    
    safe_subjid = html.escape(subjid) if subjid else ""
    
    html_output = '''<!DOCTYPE html>
<html>
<head>
<title>Students - Yale University Student Information System</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style>
.train-model-link {
color: #fff;
text-decoration: none;
padding: 6px 14px;
border: 1px solid rgba(255,255,255,0.5);
border-radius: 4px;
font-size: 14px;
margin-left: 8px;
background: rgba(255,255,255,0.1);
}
.train-model-link:hover {
background: rgba(255,255,255,0.2);
text-decoration: none;
}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img src="https://i.pinimg.com/736x/1b/50/a7/1b50a759f6e60511338a889f91226db0.jpg" alt="Yale University Logo">
</div>
<div class="header-text">
<h1>STUDENT INFORMATION SYSTEM</h1>
<p>YALE UNIVERSITY</p>
</div>
</div>
<div class="nav-bar">
<a href="students.py?db=''' + html.escape(db_name) + '''" class="active">Students</a>
<a href="subjects.py?db=''' + html.escape(db_name) + '''">Subjects</a>
<a href="teachers.py?db=''' + html.escape(db_name) + '''">Teachers</a>
'''
    html_output += '''    <div class="create-db-dropdown">
<button class="create-db-btn">Create DB <span style="font-size:12px">▼</span></button>
<div class="create-db-dropdown-content">
<a href="students.py?db=''' + html.escape(db_name) + '''&create_db=1st_sem">1st Sem</a>
<a href="students.py?db=''' + html.escape(db_name) + '''&create_db=2nd_sem">2nd Sem</a>
<a href="students.py?db=''' + html.escape(db_name) + '''&create_db=summer">Summer</a>
</div>
</div>
'''
    html_output += '''    <button id="logout-btn" onclick="window.location.href='students.py?logout=1';">Logout</button>
<a href="#" class="train-model-link" onclick="openTrainModal(); return false;">Train Model</a>
</div>
<!-- Train Model Modal -->
<div id="trainModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
background:rgba(0,0,0,0.5); z-index:9999; justify-content:center; align-items:center;">
<div style="background:#fff; border-radius:8px; padding:30px; min-width:400px; max-width:500px; box-shadow:0 4px 20px rgba(0,0,0,0.3);">
<h3 style="margin:0 0 20px 0; font-size:18px; color:#333;">Select School Year as Training Data</h3>
<form method="post" id="trainForm">
<input type="hidden" name="db" value="''' + html.escape(db_name) + '''">
<input type="hidden" name="action" value="traindata">
<select name="db_train" id="db_train_select" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px; font-size:14px; margin-bottom:20px;">
<option value="">-- select database --</option>
''' + ''.join(f'        <option value="{d}">{d}</option>' for d in VALID_DATABASES) + '''
</select>
<div style="display:flex; justify-content:flex-end; gap:10px;">
<button type="button" onclick="closeTrainModal()"
style="padding:8px 20px; border:1px solid #ccc; border-radius:4px; background:#fff; cursor:pointer;">Cancel</button>
<button type="submit"
style="padding:8px 20px; background:#00356B; color:#fff; border:none; border-radius:4px; cursor:pointer; font-weight:bold;">Train</button>
</div>
</form>
</div>
</div>
<div class="main-content">
<div class="container">
'''
    html_output += f'''<div class="form-section">
<h2>Student Form</h2>
<form method="post" id="studentForm">
<input type="hidden" name="db" value="{html.escape(db_name)}">
<input type="hidden" name="subjid" value="{safe_subjid}">
Student ID:<br><input name="studid" id="studid" value="{next_id}" readonly><br>
Name:<br><input name="name" id="name" value="{html.escape(name)}"><br>
Address:<br><input name="address" id="address" value="{html.escape(address)}"><br>
Gender:<br><input name="gender" id="gender" value="{html.escape(gender)}"><br>
Course:<br><input name="course" id="course" value="{html.escape(course)}"><br>
Year Level:<br><input name="year" id="year" value="{html.escape(year)}"><br><br>
<button type="submit" name="action" value="insert" class="btn-primary">Insert</button>
<button type="submit" name="action" value="update" class="btn-secondary">Update</button>
<button type="submit" name="action" value="delete" class="btn-danger">Delete</button>
<button type="button" id="printTorBtn" onclick="printTOR()"
style="background:#28a745; color:#fff; border:none; padding:6px 14px;
border-radius:4px; cursor:pointer; font-weight:bold; font-size:13px; margin-top:4px;">
Print TOR
</button>
<div id="aiEnrollSection" style="margin-top:10px; display:none;">
<form method="post" id="aiEnrollForm">
<input type="hidden" name="db" value="{html.escape(db_name)}">
<input type="hidden" name="action" value="ai_enroll">
<input type="hidden" name="ai_studid" id="ai_studid_input" value="">
<button type="submit" id="aiEnrollBtn"
style="background:#e67e00; color:#fff; border:none; padding:6px 14px;
border-radius:4px; cursor:pointer; font-weight:bold; font-size:13px;">
AI Enroll Student ID: <span id="aiEnrollLabel">?</span>
</button>
</form>
</div>
<div class="enroll-section">
<form method="post" id="enrollForm">
<input type="hidden" name="db" value="{html.escape(db_name)}">
<input type="hidden" name="enroll_subjid" id="hidden_subjid" value="{safe_subjid}">
<input type="hidden" name="enroll_studid" id="enroll_studid" value="">
<button type="submit" name="enroll_action" value="enroll_student" class="btn-primary" id="enrollButton">
Enroll Student ID ? to Subject ID: {safe_subjid}
</button>
<button type="submit" name="enroll_action" value="drop_student" class="btn-danger" id="dropButton" style="display:none;">
Drop
</button>
<div id="conflictMessage" class="conflict-message" style="display:none;"></div>
</form>
</div>
</form>
</div>
'''
    html_output += '''
<div class="table-section">
<h2>Students Table for: ''' + html.escape(db_name) + '''</h2>
<table border="1" id="studentsTable">
<thead>
<tr>
<th width="70">ID</th>
<th width="150">Name</th>
<th width="180">Address</th>
<th width="70">Gender</th>
<th width="100">Course</th>
<th width="70">Year</th>
<th width="90">Total Units</th>
</tr>
</thead>
<tbody>
'''
    for s in students:
        subjects_list = subjects_by_student.get(s[0], [])
        subjects_json = json.dumps(subjects_list).replace('"', '&quot;')
        student_enrolled = False
        conflict_schedule = ""
        if subjid and subjid.isdigit():
            cur.execute("SELECT 1 FROM enroll WHERE studid=%s AND subjid=%s",
                       (s[0], int(subjid)))
            student_enrolled = cur.fetchone() is not None
            if not student_enrolled:
                try:
                    cur.execute("CALL check_schedule_conflict(%s, %s, @conflict_exists, @conflict_schedule)", (s[0], int(subjid)))
                    cur.execute("SELECT @conflict_exists, @conflict_schedule")
                    conflict_result = cur.fetchone()
                    if conflict_result and conflict_result[0] == 1:
                        conflict_schedule = str(conflict_result[1]) if conflict_result[1] else ""
                    else:
                        conflict_schedule = ""
                except:
                    conflict_schedule = ""
        html_output += f'''
<tr data-studid="{s[0]}"
data-name="{html.escape(str(s[1]))}"
data-address="{html.escape(str(s[2]))}"
data-gender="{html.escape(str(s[3]))}"
data-course="{html.escape(str(s[4]))}"
data-year="{html.escape(str(s[5]))}"
data-subjects="{subjects_json}"
data-enrolled="{str(student_enrolled).lower()}"
data-conflict="{html.escape(conflict_schedule)}"
onclick="selectStudentRow(this)">
<td>{s[0]}</td>
<td>{html.escape(str(s[1]))}</td>
<td>{html.escape(str(s[2]))}</td>
<td>{html.escape(str(s[3]))}</td>
<td>{html.escape(str(s[4]))}</td>
<td>{html.escape(str(s[5]))}</td>
<td align="center">{s[6]}</td>
</tr>
'''
    html_output += '''
</tbody>
</table>
<h2 id="enrolledTitle">Enrolled Subjects</h2>
<table border="1" id="enrolledSubjectsTable">
<thead>
<tr>
<th width="70">Subject ID</th>
<th width="100">Code</th>
<th width="250">Description</th>
<th width="70">Units</th>
<th width="130">Schedule</th>
</tr>
</thead>
<tbody id="enrolledSubjectsBody">
</tbody>
</table>
</div></div></div>
<script>
let currentSelectedRow = null;
let currentEnrollSelectedRow = null;
function printTOR(){
const studid = document.getElementById('studid').value;
if(!studid || studid === '' || isNaN(studid)){
alert('Please select a student first.');
return;
}
window.open('printTor.py?studid=' + studid, '_blank');
}
function selectStudentRow(row){
const id = row.getAttribute('data-studid');
const name = row.getAttribute('data-name');
const address = row.getAttribute('data-address');
const gender = row.getAttribute('data-gender');
const course = row.getAttribute('data-course');
const year = row.getAttribute('data-year');
const subjects = JSON.parse(row.getAttribute('data-subjects').replace(/&quot;/g, '"'));
const isEnrolled = row.getAttribute('data-enrolled')==='true';
const conflictSchedule = row.getAttribute('data-conflict');
if(currentEnrollSelectedRow) {
currentEnrollSelectedRow.classList.remove('selected');
currentEnrollSelectedRow = null;
}
const url = new URL(window.location.href);
url.searchParams.set('studid', id);
url.searchParams.set('db', \'''' + html.escape(db_name) + '''\');
if(document.getElementById('hidden_subjid').value) url.searchParams.set('subjid', document.getElementById('hidden_subjid').value);
window.history.pushState({},'',url.toString());
document.getElementById('studid').value = id;
document.getElementById('name').value = name;
document.getElementById('address').value = address;
document.getElementById('gender').value = gender;
document.getElementById('course').value = course;
document.getElementById('year').value = year;
document.getElementById('enroll_studid').value=id;
document.getElementById('ai_studid_input').value = id;
document.getElementById('aiEnrollLabel').textContent = id;
document.getElementById('aiEnrollSection').style.display = 'block';
updateEnrollButton(id,isEnrolled,conflictSchedule);
const tbody=document.getElementById('enrolledSubjectsBody');
const title=document.getElementById('enrolledTitle');
tbody.innerHTML='';
if(subjects.length>0){
title.textContent='Enrolled Subjects ';
subjects.forEach(sub=>{
const tr=document.createElement('tr');
tr.innerHTML=`<td>${sub[0]}</td><td>${sub[1]}</td><td>${sub[2]}</td><td>${sub[3]}</td><td>${sub[4]}</td>`;
tr.onclick = function() { selectEnrollRow(sub[0], id, tr); };
tbody.appendChild(tr);
});
} else { title.textContent='Enrolled Subjects'; }
if(currentSelectedRow) currentSelectedRow.classList.remove('selected');
row.classList.add('selected');
currentSelectedRow=row;
}
function selectEnrollRow(subjid, studid, row){
document.getElementById('enrollButton').style.display='none';
document.getElementById('conflictMessage').style.display='none';
const dropBtn=document.getElementById('dropButton');
dropBtn.style.display='';
dropBtn.textContent=`Drop Student ID ${studid} from Subject ID: ${subjid}`;
document.getElementById('hidden_subjid').value=subjid;
document.getElementById('enroll_studid').value=studid;
if(currentEnrollSelectedRow) currentEnrollSelectedRow.classList.remove('selected');
row.classList.add('selected');
currentEnrollSelectedRow=row;
}
function updateEnrollButton(studid,isEnrolled,conflictSchedule){
const enrollBtn=document.getElementById('enrollButton');
const dropBtn=document.getElementById('dropButton');
const conflictMsg=document.getElementById('conflictMessage');
const subjid=document.getElementById('hidden_subjid').value;
if(!subjid) {
enrollBtn.style.display='none';
dropBtn.style.display='none';
conflictMsg.style.display='none';
return;
}
dropBtn.style.display='none';
if(isEnrolled){
enrollBtn.style.display='none';
conflictMsg.style.display='none';
} else if(conflictSchedule){
enrollBtn.style.display='none';
conflictMsg.style.display='block';
conflictMsg.textContent = "Conflict with " + conflictSchedule;
} else {
enrollBtn.style.display='';
conflictMsg.style.display='none';
enrollBtn.textContent=`Enroll Student ID ${studid} to Subject ID: ${subjid}`;
}
}
window.onload=function(){
window.openTrainModal = function() {
document.getElementById('trainModal').style.display = 'flex';
};
window.closeTrainModal = function() {
document.getElementById('trainModal').style.display = 'none';
};
document.getElementById('trainModal').addEventListener('click', function(e) {
if (e.target === this) closeTrainModal();
});
const urlParams=new URLSearchParams(window.location.search);
const studidParam=urlParams.get('studid');
const subjidParam=urlParams.get('subjid');
if (subjidParam) {
document.getElementById('hidden_subjid').value = subjidParam;
const enrollBtn = document.getElementById('enrollButton');
if (enrollBtn) {
enrollBtn.textContent = `Enroll Student ID ? to Subject ID: ${subjidParam}`;
}
}
const enrollBtn=document.getElementById('enrollButton');
const dropBtn=document.getElementById('dropButton');
const conflictMsg=document.getElementById('conflictMessage');
const initialSubjid=document.getElementById('hidden_subjid').value;
if(initialSubjid) {
enrollBtn.style.display='';
dropBtn.style.display='none';
conflictMsg.style.display='none';
} else {
enrollBtn.style.display='none';
dropBtn.style.display='none';
conflictMsg.style.display='none';
}
if(studidParam){
document.querySelectorAll('#studentsTable tbody tr').forEach(row=>{
if(row.getAttribute('data-studid')===studidParam){
selectStudentRow(row);
}
});
}
const createdbParam = urlParams.get('createdb');
const semesterParam = urlParams.get('semester');
if (createdbParam === 'success' && semesterParam) {
alert('Database ' + semesterParam + ' created successfully.');
}
};
</script>
</body>
</html>
'''
    print("Content-Type: text/html; charset=utf-8\n")
    print(html_output)
except Exception as e:
    print("Content-Type: text/html; charset=utf-8\n")
    print("<h2>Database Error:</h2><pre>" + html.escape(str(e)) + "</pre>")
finally:
    try: conn.close()
    except: pass
